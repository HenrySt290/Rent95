/**
 * Seed script. Populates the DB with:
 *   - An admin user + a demo buyer + a demo seller
 *   - 10 categories (matching mobile MockStore)
 *   - 6 example listings
 *
 * Run with: npm run db:seed
 */
import { PrismaClient } from '@prisma/client';
import argon2 from 'argon2';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding Rent95 database…');

  const passwordHash = await argon2.hash('demo1234', { type: argon2.argon2id });

  const [admin, buyer, seller1, seller2, seller3] = await Promise.all([
    prisma.user.upsert({
      where: { email: 'admin@rent95.dev' },
      update: {},
      create: {
        fullName: 'Rent95 Admin',
        email: 'admin@rent95.dev',
        passwordHash,
        role: 'admin',
        isEmailVerified: true,
      },
    }),
    prisma.user.upsert({
      where: { email: 'alex@example.com' },
      update: {},
      create: {
        fullName: 'Alex Rivera',
        email: 'alex@example.com',
        phone: '+15550102222',
        passwordHash,
        role: 'buyer',
        isEmailVerified: true,
        isPhoneVerified: true,
      },
    }),
    prisma.user.upsert({
      where: { email: 'amir@example.com' },
      update: {},
      create: {
        fullName: 'Amir K.',
        email: 'amir@example.com',
        passwordHash,
        role: 'seller',
        isEmailVerified: true,
      },
    }),
    prisma.user.upsert({
      where: { email: 'priya@example.com' },
      update: {},
      create: {
        fullName: 'Priya S.',
        email: 'priya@example.com',
        passwordHash,
        role: 'seller',
        isEmailVerified: true,
      },
    }),
    prisma.user.upsert({
      where: { email: 'pro@example.com' },
      update: {},
      create: {
        fullName: 'Rent95 Pro Rentals',
        email: 'pro@example.com',
        passwordHash,
        role: 'seller',
        isEmailVerified: true,
      },
    }),
  ]);

  const catData = [
    { slug: 'real-estate', name: 'Real Estate', iconName: 'apartment', allowedModes: ['rent', 'sale'] },
    { slug: 'vehicles', name: 'Vehicles', iconName: 'directions_car', allowedModes: ['rent', 'sale'] },
    { slug: 'equipment', name: 'Equipment', iconName: 'build', allowedModes: ['rent', 'sale'] },
    { slug: 'electronics', name: 'Electronics', iconName: 'devices', allowedModes: ['rent', 'sale'] },
    { slug: 'services', name: 'Services', iconName: 'handyman', allowedModes: ['service'] },
    { slug: 'fashion', name: 'Fashion', iconName: 'checkroom', allowedModes: ['rent', 'sale'] },
    { slug: 'sports', name: 'Sports', iconName: 'sports_soccer', allowedModes: ['rent', 'sale'] },
    { slug: 'furniture', name: 'Furniture', iconName: 'chair', allowedModes: ['rent', 'sale'] },
    { slug: 'events', name: 'Events', iconName: 'celebration', allowedModes: ['rent'] },
    { slug: 'other', name: 'Other', iconName: 'more_horiz', allowedModes: ['rent', 'sale', 'service'] },
  ];

  const cats = new Map<string, string>();
  for (const [i, c] of catData.entries()) {
    const created = await prisma.category.upsert({
      where: { slug: c.slug },
      update: {},
      create: {
        name: c.name,
        slug: c.slug,
        iconName: c.iconName,
        allowedModes: c.allowedModes,
        sortOrder: i,
      },
    });
    cats.set(c.slug, created.id);
  }

  const listings = [
    {
      owner: seller1,
      title: 'Tesla Model 3 — Long Range',
      slug: 'tesla-model-3-long-range',
      category: 'vehicles',
      listingType: 'rent',
      price: 95,
      priceUnit: 'day',
      securityDeposit: 300,
      customAttributes: { Make: 'Tesla', Model: 'Model 3', Year: 2022, Seats: 5, Transmission: 'Automatic' },
      description: 'Well maintained 2022 Tesla Model 3 Long Range. Autopilot enabled, clean and detailed before every rental.',
      image: 'https://images.unsplash.com/photo-1553260168-69b041873e65?w=1200',
      city: 'Brooklyn',
    },
    {
      owner: seller2,
      title: 'Cozy Studio in Williamsburg',
      slug: 'cozy-studio-williamsburg',
      category: 'real-estate',
      listingType: 'rent',
      price: 140,
      priceUnit: 'day',
      securityDeposit: 500,
      customAttributes: { Bedrooms: 0, Bathrooms: 1, Furnished: true, 'Property Type': 'Studio' },
      description: 'Sunny, quiet studio apartment steps from the L train. Fully furnished, high-speed Wi-Fi.',
      image: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=1200',
      city: 'Brooklyn',
    },
    {
      owner: seller3,
      title: 'Canon EOS R5 + 24-70mm Lens',
      slug: 'canon-eos-r5-24-70mm',
      category: 'equipment',
      listingType: 'hybrid',
      price: 65,
      priceUnit: 'day',
      securityDeposit: 800,
      customAttributes: { Brand: 'Canon', Condition: 'Like new', Includes: 'Body + 24-70mm f/2.8 + 2 batteries' },
      description: 'Full-frame mirrorless camera with the RF 24-70mm f/2.8 lens. Includes 2 batteries and hard case.',
      image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=1200',
      city: 'Manhattan',
    },
    {
      owner: seller3,
      title: 'MacBook Pro 16" M3 Max — 64GB RAM',
      slug: 'macbook-pro-16-m3-max',
      category: 'electronics',
      listingType: 'hybrid',
      price: 3200,
      priceUnit: 'fixed',
      securityDeposit: 0,
      customAttributes: { Brand: 'Apple', Storage: '2 TB', Condition: 'Like new' },
      description: 'Barely used MacBook Pro 16-inch with the M3 Max chip. Great for video editing, 3D, and AI dev work.',
      image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=1200',
      city: 'Jersey City',
    },
    {
      owner: seller1,
      title: 'Deep Clean — 2-Bedroom Apartment',
      slug: 'deep-clean-2br-nyc',
      category: 'services',
      listingType: 'service',
      price: 160,
      priceUnit: 'fixed',
      securityDeposit: 0,
      customAttributes: { Duration: '3 hours', 'Service Area': '10 mi radius' },
      description: 'Insured professional cleaning team. Includes kitchen deep clean, bathrooms, floors, and appliances.',
      image: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=1200',
      city: 'Queens',
    },
    {
      owner: seller2,
      title: 'Designer Evening Dress — Size M',
      slug: 'designer-evening-dress-m',
      category: 'fashion',
      listingType: 'rent',
      price: 55,
      priceUnit: 'day',
      securityDeposit: 150,
      customAttributes: { Size: 'M', Color: 'Emerald', Occasion: 'Formal / Gala' },
      description: 'Stunning full-length evening dress. Rent for a night, dry-cleaned between rentals.',
      image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200',
      city: 'Manhattan',
    },
  ];

  for (const l of listings) {
    const categoryId = cats.get(l.category)!;
    const existing = await prisma.product.findUnique({ where: { slug: l.slug } });
    if (existing) continue;
    await prisma.product.create({
      data: {
        ownerId: l.owner.id,
        categoryId,
        title: l.title,
        slug: l.slug,
        description: l.description,
        listingType: l.listingType as 'rent' | 'sale' | 'service' | 'hybrid',
        price: l.price,
        priceUnit: l.priceUnit as 'day' | 'fixed',
        securityDeposit: l.securityDeposit,
        currency: 'USD',
        quantity: 1,
        customAttributes: l.customAttributes,
        status: 'active',
        moderationStatus: 'approved',
        deliveryOptions: ['pickup'],
        location: {
          create: {
            address: `${l.city}, NY`,
            city: l.city,
            country: 'USA',
            latitude: 40.7128,
            longitude: -74.006,
          },
        },
        media: {
          create: [{ url: l.image, mediaType: 'image', sortOrder: 0, isPrimary: true }],
        },
      },
    });
  }

  console.log(`✅ Seeded ${listings.length} listings, ${catData.length} categories, and demo users.`);
  console.log('   Admin: admin@rent95.dev / demo1234');
  console.log('   Buyer: alex@example.com / demo1234');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
