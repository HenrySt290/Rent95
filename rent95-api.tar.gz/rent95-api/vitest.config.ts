import { defineConfig } from 'vitest/config';
import { config as loadEnv } from 'dotenv';
import { resolve } from 'node:path';

// Load .env.test into process.env BEFORE any src/config/env import runs.
// This lets us point at a test database + secrets in one file, and keeps
// the production env schema in src/config/env.ts fully strict.
loadEnv({ path: resolve(__dirname, '.env.test') });

export default defineConfig({
  test: {
    include: ['tests/**/*.test.ts'],
    environment: 'node',
    globals: false,
    // Integration tests share a Postgres database. Running them in parallel
    // would race on the shared tables. We keep unit tests parallel (they
    // don't touch the DB) and force integration tests into one fork.
    pool: 'forks',
    poolOptions: {
      forks: {
        // A single worker for the whole run is the safest default for a
        // shared DB. Override with --pool=threads locally if you're
        // certain your tests are isolated per-user.
        singleFork: true,
      },
    },
    // Integration tests do real HTTP + Prisma round-trips → be generous.
    testTimeout: 20_000,
    hookTimeout: 30_000,
    // Global setup runs ONCE for the whole run; it's where we migrate the
    // test DB before any test file loads.
    globalSetup: ['tests/support/global-setup.ts'],
    // Truncate all rows between tests so ordering doesn't matter.
    setupFiles: ['tests/support/reset-db.ts'],
  },
});
