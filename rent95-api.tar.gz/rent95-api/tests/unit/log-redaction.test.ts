import { describe, expect, it } from 'vitest';
import { REDACT_PATTERNS, scrubMessage } from '../../src/config/log-redaction';

describe('scrubMessage — regex-based scrubber for raw strings', () => {
  it('redacts Bearer tokens', () => {
    const s = 'Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.abc.def';
    const out = scrubMessage(s);
    expect(out).toContain('[REDACTED]');
    expect(out).not.toContain('eyJhbGciOiJIUzI1NiJ9.abc.def');
  });

  it('redacts Stripe secret keys (test + live)', () => {
    for (const key of ['sk_test_ABC123DEF456', 'sk_live_XYZ789PQR012', 'rk_live_secret42']) {
      expect(scrubMessage(`Using key ${key}`)).not.toContain(key);
    }
  });

  it('redacts Stripe PaymentIntent client secrets', () => {
    const secret = 'pi_1AbCd23fghIJ_secret_kLmnop456789';
    expect(scrubMessage(`clientSecret=${secret}`)).not.toContain(secret);
  });

  it('redacts bare JWT-shaped values', () => {
    const jwt = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIn0.abcdefghijklmnop';
    expect(scrubMessage(`token=${jwt}`)).not.toContain(jwt);
  });

  it('leaves non-secret strings intact', () => {
    const s = 'Hello world, order R95-2025-001 total $432.10';
    expect(scrubMessage(s)).toBe(s);
  });

  it('exposes patterns as a stable readonly-ish array (frozen contract)', () => {
    // Sanity check that new pattern additions don't accidentally drop
    // existing ones; this test fails loudly if someone shortens the list.
    expect(REDACT_PATTERNS.length).toBeGreaterThanOrEqual(4);
  });
});
