import { describe, expect, it } from 'vitest';
import { REDACT_PATTERNS, REDACT_PATHS, scrubMessage } from '../../src/config/log-redaction';

describe('scrubMessage — regex-based scrubber for raw strings', () => {
  it('redacts Bearer tokens', () => {
    const s = 'Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.abc.def';
    const out = scrubMessage(s);
    expect(out).toContain('[REDACTED]');
    expect(out).not.toContain('eyJhbGciOiJIUzI1NiJ9.abc.def');
  });

  it('redacts Stripe secret keys (test + live)', () => {
    for (const key of ['sk_test_ABC123DEF456', 'sk_live_XYZ789PQR012', 'rk_live_secret42']) {
      expect(scrubMessage(`Using key ${key}`)).not.toContain(key);
    }
  });

  it('redacts Stripe PaymentIntent client secrets', () => {
    const secret = 'pi_1AbCd23fghIJ_secret_kLmnop456789';
    expect(scrubMessage(`clientSecret=${secret}`)).not.toContain(secret);
  });

  it('redacts Stripe webhook signing secrets (whsec_…)', () => {
    const s = 'STRIPE_WEBHOOK_SECRET=whsec_abcDEF123456xyz';
    expect(scrubMessage(s)).not.toContain('whsec_abcDEF123456xyz');
  });

  it('redacts SetupIntent client secrets', () => {
    const secret = 'seti_1AbCd23fghIJ_secret_kLmnop456789';
    expect(scrubMessage(`seti=${secret}`)).not.toContain(secret);
  });

  it('redacts bare JWT-shaped values', () => {
    const jwt = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIn0.abcdefghijklmnop';
    expect(scrubMessage(`token=${jwt}`)).not.toContain(jwt);
  });

  it('redacts the admin panel AES-GCM session wire format', () => {
    // <b64url(iv=16 chars)>.<b64url(ct)>.<b64url(tag=22 chars)>
    const session =
      'abcdef0123456789.abcdefghijklmnopqrstuvwxyz012345678901.abcdefghijklmnopqrstuv';
    const out = scrubMessage(`cookie=__Host-rent95_admin_session=${session}`);
    expect(out).not.toContain(session);
  });

  it('redacts the admin session cookie by name', () => {
    const cookie = '__Host-rent95_admin_session=xxxxxxxxxx.yyyyyyyyyyyyyy.zzzzzzzzzz';
    expect(scrubMessage(`Set-Cookie: ${cookie}; HttpOnly`)).not.toContain(cookie);
  });

  it('redacts credit-card-shaped digit runs', () => {
    for (const pan of ['4242424242424242', '4242 4242 4242 4242', '4242-4242-4242-4242']) {
      expect(scrubMessage(`pan=${pan}`)).not.toContain(pan);
    }
  });

  it('redacts CVV/CVC values in key=value dumps', () => {
    expect(scrubMessage('cvv=123')).not.toContain('123');
    expect(scrubMessage('"cvc": "4567"')).not.toContain('4567');
  });

  it('leaves non-secret strings intact', () => {
    const s = 'Hello world, order R95-2025-001 total $432.10';
    // Order number contains 4 digit runs but not 13-19; must not trigger.
    expect(scrubMessage(s)).toBe(s);
  });

  it('exposes patterns as a stable readonly-ish array (frozen contract)', () => {
    expect(REDACT_PATTERNS.length).toBeGreaterThanOrEqual(8);
  });

  it('REDACT_PATHS covers plaintext session cookie names', () => {
    const asStr = REDACT_PATHS.join(' ');
    expect(asStr).toMatch(/__Host-rent95_admin_session/);
    expect(asStr).toMatch(/adminSession|admin_session/);
  });

  it('REDACT_PATHS covers axios/dio error attachments', () => {
    const asStr = REDACT_PATHS.join(' ');
    expect(asStr).toContain('err.request');
    expect(asStr).toContain('err.config');
    expect(asStr).toContain('err.response.data');
  });

  it('REDACT_PATHS covers Prisma error meta', () => {
    const asStr = REDACT_PATHS.join(' ');
    expect(asStr).toContain('err.meta');
    expect(asStr).toContain('err.meta.cause');
  });

  it('REDACT_PATHS covers OAuth query params', () => {
    const asStr = REDACT_PATHS.join(' ');
    expect(asStr).toMatch(/req\.query\.token|req\.query\.access_token/);
    expect(asStr).toContain('req.query.code');
  });

  it('REDACT_PATHS covers common OTP / MFA fields at any depth', () => {
    const asStr = REDACT_PATHS.join(' ');
    expect(asStr).toContain('*.otp');
    expect(asStr).toContain('*.mfaCode');
    expect(asStr).toContain('*.totpSecret');
  });

  it('REDACT_PATHS covers newPassword + oldPassword variants', () => {
    const asStr = REDACT_PATHS.join(' ');
    expect(asStr).toContain('*.newPassword');
    expect(asStr).toContain('*.oldPassword');
    expect(asStr).toContain('*.currentPassword');
  });
});
