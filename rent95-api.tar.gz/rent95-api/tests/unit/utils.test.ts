import { describe, expect, it } from 'vitest';
import { slugify, generateOrderNumber } from '../../src/utils/slug';
import { hashRefreshToken, refreshTokenExpiryDate } from '../../src/utils/crypto';

describe('slugify', () => {
  it('lowercases and dashes titles', () => {
    expect(slugify('Tesla Model 3 — Long Range')).toBe('tesla-model-3-long-range');
  });
  it('appends a suffix', () => {
    expect(slugify('Hello world', 'abc')).toBe('hello-world-abc');
  });
});

describe('generateOrderNumber', () => {
  it('matches the R95-YYMMDD-#### pattern', () => {
    expect(generateOrderNumber()).toMatch(/^R95-\d{6}-\d{4}$/);
  });
});

describe('refresh tokens', () => {
  it('hashes deterministically', () => {
    expect(hashRefreshToken('a')).toBe(hashRefreshToken('a'));
    expect(hashRefreshToken('a')).not.toBe(hashRefreshToken('b'));
  });
  it('sets an expiry in the future', () => {
    expect(refreshTokenExpiryDate().getTime()).toBeGreaterThan(Date.now());
  });
});
