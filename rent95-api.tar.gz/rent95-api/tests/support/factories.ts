/**
 * Object factories. Each function returns a Promise<Row> so tests can:
 *
 *   const seller = await createUser({ role: 'seller' });
 *   const product = await createProduct({ ownerId: seller.id });
 *
 * We deliberately avoid a heavy fixture library — Postgres + Prisma is
 * fast enough that a fresh row per test is fine, and named factories keep
 * intent obvious in test bodies.
 */

import { prisma } from '../../src/config/prisma';
import { hashPassword } from '../../src/utils/crypto';

type UserOverrides = Partial<{
  email: string;
  fullName: string;
  password: string;
  role: 'buyer' | 'seller' | 'admin' | 'moderator' | 'support';
}>;

let userCounter = 0;
export async function createUser(overrides: UserOverrides = {}) {
  userCounter += 1;
  const email = overrides.email ?? `user${userCounter}-${Date.now()}@test.dev`;
  const password = overrides.password ?? 'test1234';
  const passwordHash = await hashPassword(password);
  return prisma.user.create({
    data: {
      email,
      fullName: overrides.fullName ?? `Test User ${userCounter}`,
      passwordHash,
      role: overrides.role ?? 'buyer',
      isEmailVerified: true,
    },
  });
}

let categoryCounter = 0;
export async function createCategory(overrides: Partial<{ name: string; slug: string; allowedModes: string[] }> = {}) {
  categoryCounter += 1;
  const slug = overrides.slug ?? `cat-${categoryCounter}-${Date.now()}`;
  return prisma.category.create({
    data: {
      name: overrides.name ?? `Category ${categoryCounter}`,
      slug,
      allowedModes: overrides.allowedModes ?? ['rent', 'sale'],
    },
  });
}

type ProductOverrides = Partial<{
  ownerId: string;
  categoryId: string;
  title: string;
  price: number;
  priceUnit: 'hour' | 'day' | 'week' | 'month' | 'fixed';
  listingType: 'rent' | 'sale' | 'service' | 'hybrid';
  quantity: number;
  status: 'draft' | 'pending' | 'active' | 'rejected' | 'paused' | 'sold' | 'archived';
  moderationStatus: 'pending' | 'approved' | 'rejected';
  currency: string;
  securityDeposit: number;
}>;

let productCounter = 0;
export async function createProduct(overrides: ProductOverrides = {}) {
  productCounter += 1;
  const ownerId = overrides.ownerId ?? (await createUser({ role: 'seller' })).id;
  const categoryId = overrides.categoryId ?? (await createCategory()).id;
  const slug = `product-${productCounter}-${Date.now()}`;

  return prisma.product.create({
    data: {
      ownerId,
      categoryId,
      title: overrides.title ?? `Product ${productCounter}`,
      slug,
      description: 'Test product description that is long enough to pass validation.',
      listingType: overrides.listingType ?? 'rent',
      price: overrides.price ?? 100,
      priceUnit: overrides.priceUnit ?? 'day',
      securityDeposit: overrides.securityDeposit ?? 0,
      currency: overrides.currency ?? 'USD',
      quantity: overrides.quantity ?? 1,
      status: overrides.status ?? 'active',
      moderationStatus: overrides.moderationStatus ?? 'approved',
      deliveryOptions: ['pickup'],
      location: {
        create: {
          address: '1 Test St',
          city: 'Testville',
          country: 'USA',
          latitude: 40.7128,
          longitude: -74.006,
        },
      },
      media: {
        create: [
          {
            url: `https://example.test/img-${productCounter}.jpg`,
            mediaType: 'image',
            sortOrder: 0,
            isPrimary: true,
          },
        ],
      },
    },
    include: { media: true, location: true },
  });
}
