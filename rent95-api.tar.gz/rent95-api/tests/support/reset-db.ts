import { beforeEach, afterAll } from 'vitest';
import { prisma } from '../../src/config/prisma';

/**
 * Truncates every table before each test.
 *
 * Uses `TRUNCATE … RESTART IDENTITY CASCADE` so:
 *   - foreign-key chains clean themselves up in one shot
 *   - sequences reset (nicer test output when we peek at ids)
 *   - the operation is measured in milliseconds even with millions of rows
 *
 * Unit tests under tests/unit/ don't need this — skip via an env var so
 * `npm run test:unit` doesn't require a live Postgres.
 */
const TABLES_TO_TRUNCATE = [
  'disputes',
  'notifications',
  'messages',
  'conversations',
  'reviews',
  'payouts',
  'payments',
  'orders',
  'favorites',
  'product_availability',
  'product_locations',
  'product_media',
  'products',
  'category_fields',
  'categories',
  'device_tokens',
  'refresh_tokens',
  'seller_profiles',
  'user_addresses',
  'users',
];

const SKIP = process.env.SKIP_DB_RESET === '1';

beforeEach(async () => {
  if (SKIP) return;
  const list = TABLES_TO_TRUNCATE.map((t) => `"${t}"`).join(', ');
  await prisma.$executeRawUnsafe(`TRUNCATE ${list} RESTART IDENTITY CASCADE;`);
});

afterAll(async () => {
  if (SKIP) return;
  await prisma.$disconnect();
});
