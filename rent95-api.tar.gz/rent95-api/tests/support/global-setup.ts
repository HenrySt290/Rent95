import { execSync } from 'node:child_process';

/**
 * Runs once before any test file loads.
 *
 * Uses `prisma migrate deploy` (production-style) rather than `migrate dev`
 * so we don't spam the migrations table with shadow migrations in CI. The
 * DB is expected to already exist (docker-compose.test.yml or GH Actions
 * service creates it).
 *
 * If you want a clean schema every run (helpful when you're actively
 * changing the Prisma schema), export FORCE_DB_RESET=1 before running.
 */
export default async function setup() {
  const url = process.env.DATABASE_URL;
  if (!url) {
    throw new Error('DATABASE_URL is not set — check .env.test');
  }

  if (process.env.FORCE_DB_RESET === '1') {
    execSync('npx prisma migrate reset --force --skip-seed', {
      stdio: 'inherit',
      env: process.env,
    });
    return;
  }

  execSync('npx prisma migrate deploy', {
    stdio: 'inherit',
    env: process.env,
  });
}
