import type { Express } from 'express';
import request from 'supertest';
import { createApp } from '../../src/app';
import { signAccessToken } from '../../src/utils/crypto';

/**
 * Builds a fresh Express instance per test file. We NEVER call
 * `httpServer.listen()` — supertest binds an ephemeral port on demand,
 * which lets tests run truly in parallel per file (and keeps us out of
 * "port already in use" hell in CI).
 */
export function testApp(): Express {
  return createApp();
}

/**
 * Grants an access token as the given user. Bypasses `/api/auth/login` on
 * purpose — that endpoint is tested directly by the auth suite, and every
 * OTHER suite just wants a valid Bearer without doing the login dance.
 */
export function tokenFor(user: { id: string; email: string; role: string }): string {
  return signAccessToken({ sub: user.id, email: user.email, role: user.role });
}

/**
 * Convenience: run a supertest request with an Authorization header
 * already attached.
 */
export function authed(app: Express, token: string) {
  const agent = request(app);
  return {
    get: (url: string) => agent.get(url).set('Authorization', `Bearer ${token}`),
    post: (url: string) => agent.post(url).set('Authorization', `Bearer ${token}`),
    patch: (url: string) => agent.patch(url).set('Authorization', `Bearer ${token}`),
    delete: (url: string) => agent.delete(url).set('Authorization', `Bearer ${token}`),
  };
}
