/**
 * Integration tests for the security patches applied in the pre-flight audit.
 *
 * Focus: CORS gate + payload size limits + preflight behaviour. The other
 * security surface (helmet headers) has its own file
 * `tests/integration/security-headers.test.ts`; we keep the two split so a
 * failing CORS test doesn't hide a failing CSP assertion.
 *
 * Every test builds a fresh Express app via `testApp()` (see
 * `tests/support/http.ts`) so we don't share state between assertions.
 */

import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';

import { testApp } from '../support/http';

// -----------------------------------------------------------------------------
// CORS gate — the audit C2 fix.
//
// The test env's .env.test sets NODE_ENV=test and CORS_ORIGINS='' — the
// production superRefine that requires a non-empty allowlist only fires
// when NODE_ENV=production, so tests boot fine. Meanwhile the CORS
// middleware still refuses any Origin it doesn't recognise, which is what
// we assert below.
//
// For the "allowed origin" case we monkey-patch process.env.CORS_ORIGINS
// via a global before hook, then rebuild the app so the fresh Express
// instance picks up the new allowlist. This mirrors what a real deploy
// does at boot.
// -----------------------------------------------------------------------------

describe('CORS gate — origin allowlist enforcement', () => {
  it('does not reflect Access-Control-Allow-Origin for an unapproved origin', async () => {
    const app = testApp();
    const res = await request(app)
      .get('/health')
      .set('Origin', 'https://evil.example.com');

    // Two acceptable outcomes per the CORS middleware contract:
    //   (a) The header is absent entirely (our current behaviour — the
    //       origin callback returns an error, express-cors omits the header).
    //   (b) Express returns a 500 from the cors error propagating through
    //       the middleware chain.
    // Either way, the header MUST NOT reflect the attacker's origin, and
    // MUST NOT be '*' under `credentials: true`.
    const acao = res.headers['access-control-allow-origin'];
    expect(acao).not.toBe('https://evil.example.com');
    expect(acao).not.toBe('*');
    // Status is either 200 (header omitted → browser blocks) or 500 (the
    // origin callback threw). Anything else is a regression.
    expect([200, 500]).toContain(res.status);
  });

  it('accepts a request with no Origin header (server-to-server / mobile-native)', async () => {
    // Native mobile clients don't send an Origin header — the CORS spec
    // only applies to browsers. Our middleware special-cases missing
    // origin as `callback(null, true)` so healthchecks and inter-service
    // calls just work.
    const app = testApp();
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    // No ACAO header for non-CORS requests — that's the correct behaviour.
    expect(res.headers['access-control-allow-origin']).toBeUndefined();
  });

  it('refuses preflight for an unapproved origin', async () => {
    const app = testApp();
    const res = await request(app)
      .options('/api/products')
      .set('Origin', 'https://not-in-allowlist.test')
      .set('Access-Control-Request-Method', 'GET')
      .set('Access-Control-Request-Headers', 'authorization');

    // Preflight must NOT be granted for a rogue origin. Either the
    // middleware short-circuits with 5xx or the ACAO header is absent.
    const acao = res.headers['access-control-allow-origin'];
    expect(acao).not.toBe('https://not-in-allowlist.test');
    expect(acao).not.toBe('*');
  });
});

describe('CORS gate — approved origin accepted', () => {
  const ALLOWED = 'https://admin.rent95.app';
  const previousCorsOrigins = process.env.CORS_ORIGINS;

  beforeAll(() => {
    // Rewrite the env var, then blow away the module cache so a fresh
    // env.ts is loaded and `corsOrigins` picks up our allowlist.
    process.env.CORS_ORIGINS = ALLOWED;
  });

  afterAll(() => {
    process.env.CORS_ORIGINS = previousCorsOrigins;
  });

  it('reflects the exact allowed origin with credentials enabled', async () => {
    // Reset module cache so config/env re-runs with the new CORS_ORIGINS.
    const { vi } = await import('vitest');
    vi.resetModules();
    const { testApp: freshApp } = await import('../support/http');
    const app = freshApp();

    const res = await request(app).get('/health').set('Origin', ALLOWED);

    expect(res.status).toBe(200);
    // MUST reflect the exact origin (not '*') because `credentials: true`
    // requires a specific origin per the CORS spec.
    expect(res.headers['access-control-allow-origin']).toBe(ALLOWED);
    expect(res.headers['access-control-allow-credentials']).toBe('true');
    // Vary: Origin is critical so intermediary caches don't serve a
    // response with one origin's ACAO to a request from another.
    const vary = res.headers['vary'] ?? '';
    expect(vary.toLowerCase()).toContain('origin');
  });

  it('grants preflight for an allowed origin + expected method/headers', async () => {
    const { vi } = await import('vitest');
    vi.resetModules();
    const { testApp: freshApp } = await import('../support/http');
    const app = freshApp();

    const res = await request(app)
      .options('/api/products')
      .set('Origin', ALLOWED)
      .set('Access-Control-Request-Method', 'POST')
      .set('Access-Control-Request-Headers', 'authorization,content-type');

    // 204 No Content is the standard preflight-success shape.
    expect([200, 204]).toContain(res.status);
    expect(res.headers['access-control-allow-origin']).toBe(ALLOWED);
    // Our allowlist explicitly enumerates methods + headers.
    const methods = (res.headers['access-control-allow-methods'] ?? '').toUpperCase();
    expect(methods).toContain('POST');
    expect(methods).toContain('GET');
    const allowedHeaders = (
      res.headers['access-control-allow-headers'] ?? ''
    ).toLowerCase();
    expect(allowedHeaders).toContain('authorization');
    expect(allowedHeaders).toContain('content-type');
  });
});

// -----------------------------------------------------------------------------
// Payload boundary — the audit H1 fix.
//
// We construct a JSON body strictly larger than 100 KB and assert Express's
// built-in body parser rejects with 413 Payload Too Large BEFORE our
// controllers see it. The route we target is /api/auth/login because it's
// exercised by CI already and has no auth requirement (would 401 first
// otherwise).
// -----------------------------------------------------------------------------

describe('Payload boundary — 100 KB JSON limit', () => {
  it('rejects a JSON body just over 100 KB with 413', async () => {
    const app = testApp();
    // 100 KB is 102 400 bytes. We build 110 KB so JSON encoding + field
    // names still land us comfortably past the cap.
    const overflow = 'a'.repeat(110 * 1024);

    const res = await request(app)
      .post('/api/auth/login')
      .set('Content-Type', 'application/json')
      .send({ email: 'someone@example.dev', password: overflow });

    expect(res.status).toBe(413);
    // Never runs the controller — assert the body IS NOT the standard
    // "Invalid email or password" from the auth service.
    if (typeof res.body === 'object' && res.body !== null) {
      const msg = (res.body as { message?: string }).message ?? '';
      expect(msg.toLowerCase()).not.toContain('invalid email');
    }
  });

  it('accepts a normal-sized JSON body (< 100 KB)', async () => {
    // Sanity floor: a tiny payload passes through the parser and reaches
    // the auth service, which then 401s on unknown credentials. Proves
    // the limiter isn't over-aggressive.
    const app = testApp();
    const res = await request(app)
      .post('/api/auth/login')
      .set('Content-Type', 'application/json')
      .send({ email: 'unknown@example.dev', password: 'not-a-real-user' });

    // The parser did not choke: we get past 413 and into the auth flow.
    expect(res.status).not.toBe(413);
    // The auth flow rejects the unknown user with a 401.
    expect([400, 401]).toContain(res.status);
  });

  it('rejects a urlencoded body just over 100 KB with 413', async () => {
    // Same limit applies to urlencoded — verify both parsers are capped.
    const app = testApp();
    const overflow = 'x'.repeat(110 * 1024);

    const res = await request(app)
      .post('/api/auth/login')
      .set('Content-Type', 'application/x-www-form-urlencoded')
      .send(`email=a@b.c&password=${encodeURIComponent(overflow)}`);

    expect(res.status).toBe(413);
  });
});
