import { describe, expect, it } from 'vitest';
import request from 'supertest';

import { testApp, tokenFor, authed } from '../support/http';
import { createProduct, createUser } from '../support/factories';
import { prisma } from '../../src/config/prisma';

async function seedCompletedOrder() {
  const seller = await createUser({ role: 'seller' });
  const buyer = await createUser({ role: 'buyer' });
  const product = await createProduct({ ownerId: seller.id });
  const order = await prisma.order.create({
    data: {
      orderNumber: `R95-${Date.now()}`,
      buyerId: buyer.id,
      sellerId: seller.id,
      productId: product.id,
      orderType: 'rental',
      status: 'completed',
      subtotal: 100,
      totalAmount: 130,
      currency: 'USD',
    },
  });
  return { seller, buyer, product, order };
}

describe('POST /api/reviews', () => {
  const app = testApp();

  it('lets the buyer post a review on a completed order and recomputes product rating', async () => {
    const { buyer, product, order } = await seedCompletedOrder();

    const res = await authed(app, tokenFor(buyer))
      .post('/api/reviews')
      .send({ orderId: order.id, rating: 5, comment: 'Great!' });

    expect(res.status).toBe(201);
    expect(res.body.data.rating).toBe(5);

    const p = await prisma.product.findUnique({ where: { id: product.id } });
    expect(Number(p?.ratingAverage)).toBe(5);
    expect(p?.reviewCount).toBe(1);
  });

  it('averages multiple reviews correctly', async () => {
    const { buyer, seller, product } = await seedCompletedOrder();
    // First review by original buyer.
    const order1 = await prisma.order.findFirst({ where: { buyerId: buyer.id } });
    await authed(app, tokenFor(buyer))
      .post('/api/reviews')
      .send({ orderId: order1!.id, rating: 4 });

    // Second review by a different buyer via a second completed order.
    const buyer2 = await createUser({ role: 'buyer' });
    const order2 = await prisma.order.create({
      data: {
        orderNumber: `R95-${Date.now()}-b`,
        buyerId: buyer2.id,
        sellerId: seller.id,
        productId: product.id,
        orderType: 'rental',
        status: 'completed',
        subtotal: 100,
        totalAmount: 100,
        currency: 'USD',
      },
    });
    await authed(app, tokenFor(buyer2))
      .post('/api/reviews')
      .send({ orderId: order2.id, rating: 2 });

    const p = await prisma.product.findUnique({ where: { id: product.id } });
    expect(Number(p?.ratingAverage)).toBe(3); // (4+2)/2
    expect(p?.reviewCount).toBe(2);
  });

  it("400s when the order isn't completed", async () => {
    const seller = await createUser({ role: 'seller' });
    const buyer = await createUser({ role: 'buyer' });
    const product = await createProduct({ ownerId: seller.id });
    const order = await prisma.order.create({
      data: {
        orderNumber: `R95-${Date.now()}-x`,
        buyerId: buyer.id,
        sellerId: seller.id,
        productId: product.id,
        orderType: 'rental',
        status: 'active', // not completed
        subtotal: 100,
        totalAmount: 100,
        currency: 'USD',
      },
    });

    const res = await authed(app, tokenFor(buyer))
      .post('/api/reviews')
      .send({ orderId: order.id, rating: 5 });
    expect(res.status).toBe(400);
  });

  it('403s when someone other than the buyer tries to review', async () => {
    const { seller, order } = await seedCompletedOrder();
    const res = await authed(app, tokenFor(seller))
      .post('/api/reviews')
      .send({ orderId: order.id, rating: 5 });
    expect(res.status).toBe(403);
  });

  it("400s on second review for the same order (one-per-buyer-per-order)", async () => {
    const { buyer, order } = await seedCompletedOrder();
    await authed(app, tokenFor(buyer))
      .post('/api/reviews')
      .send({ orderId: order.id, rating: 5 });

    const dup = await authed(app, tokenFor(buyer))
      .post('/api/reviews')
      .send({ orderId: order.id, rating: 1 });
    expect(dup.status).toBe(400);
  });
});

describe('GET /api/products/:id/reviews', () => {
  const app = testApp();

  it('returns approved reviews for a product', async () => {
    const { buyer, product, order } = await seedCompletedOrder();
    await authed(app, tokenFor(buyer))
      .post('/api/reviews')
      .send({ orderId: order.id, rating: 5, comment: 'Nice!' });

    const res = await request(app).get(`/api/products/${product.id}/reviews`);
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveLength(1);
    expect(res.body.data[0].comment).toBe('Nice!');
  });
});
