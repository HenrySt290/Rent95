import { describe, expect, it } from 'vitest';
import request from 'supertest';

import { testApp } from '../support/http';

const app = testApp();

describe('Security headers', () => {
  it('sets a strict CSP with default-src none', async () => {
    const res = await request(app).get('/health');
    const csp = res.headers['content-security-policy'] ?? '';
    expect(csp).toContain("default-src 'none'");
    // Never allow inline scripts on an API surface.
    expect(csp).not.toContain("'unsafe-inline'");
    expect(csp).toContain("frame-ancestors 'none'");
    expect(csp).toContain('upgrade-insecure-requests');
  });

  it('advertises 2-year HSTS with subdomains + preload', async () => {
    const res = await request(app).get('/health');
    const hsts = res.headers['strict-transport-security'] ?? '';
    expect(hsts).toContain('max-age=63072000');
    expect(hsts).toContain('includeSubDomains');
    expect(hsts).toContain('preload');
  });

  it('denies framing entirely', async () => {
    const res = await request(app).get('/health');
    expect(res.headers['x-frame-options']).toBe('DENY');
  });

  it('sends Referrer-Policy: no-referrer', async () => {
    const res = await request(app).get('/health');
    expect(res.headers['referrer-policy']).toBe('no-referrer');
  });

  it('does not expose X-Powered-By', async () => {
    const res = await request(app).get('/health');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });

  it('advertises X-Content-Type-Options: nosniff', async () => {
    const res = await request(app).get('/health');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
  });
});

describe('CORS allowlist', () => {
  it('accepts a request with no Origin (server-to-server, curl, mobile native)', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
  });

  // The test env sets CORS_ORIGINS='' (see .env.test). We rely on the
  // fact that the middleware treats an empty allowlist as "no cross-origin
  // browsers allowed" in production, but permissive in test. The test below
  // asserts the guard using an explicit disallowed origin — always refused
  // regardless of environment because it isn't in the allowlist.
  it('refuses a browser origin that is not on the allowlist', async () => {
    const res = await request(app)
      .get('/health')
      .set('Origin', 'https://evil.example.com');
    // Response body still returns (Express doesn't 500 the response), but
    // Access-Control-Allow-Origin must NOT reflect evil.example.com.
    expect(res.headers['access-control-allow-origin']).not.toBe('https://evil.example.com');
    expect(res.headers['access-control-allow-origin']).not.toBe('*');
  });
});

describe('Body limits', () => {
  it('rejects a JSON body over 100 KB', async () => {
    // Build a payload larger than the 100kb express.json limit.
    const big = 'a'.repeat(150 * 1024);
    const res = await request(app)
      .post('/api/auth/login')
      .set('Content-Type', 'application/json')
      .send({ email: 'x@y.z', password: big });
    // Express returns 413 for entity-too-large.
    expect(res.status).toBe(413);
  });
});

describe('Error hygiene', () => {
  it('does not reflect the raw request path in 404 responses', async () => {
    const res = await request(app).get('/api/definitely-not-a-real-path-xyz');
    expect(res.status).toBe(404);
    // The old handler embedded the full URL — we no longer do (audit H5).
    expect(res.body.message).toBe('Not found.');
    expect(res.body.code).toBe('route_not_found');
  });
});
