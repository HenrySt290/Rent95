/**
 * Security-header contract tests.
 *
 * CORS + body-size tests moved to `security.test.ts` after the follow-up
 * audit. This file now covers HTTP header hygiene ONLY, so a CSP change
 * doesn't accidentally hide a CORS regression (and vice versa).
 */

import { describe, expect, it } from 'vitest';
import request from 'supertest';

import { testApp } from '../support/http';

const app = testApp();

describe('Security headers', () => {
  it('sets a strict CSP with default-src none', async () => {
    const res = await request(app).get('/health');
    const csp = res.headers['content-security-policy'] ?? '';
    expect(csp).toContain("default-src 'none'");
    // Never allow inline scripts on an API surface.
    expect(csp).not.toContain("'unsafe-inline'");
    expect(csp).toContain("frame-ancestors 'none'");
    expect(csp).toContain('upgrade-insecure-requests');
  });

  it('advertises 2-year HSTS with subdomains + preload', async () => {
    const res = await request(app).get('/health');
    const hsts = res.headers['strict-transport-security'] ?? '';
    expect(hsts).toContain('max-age=63072000');
    expect(hsts).toContain('includeSubDomains');
    expect(hsts).toContain('preload');
  });

  it('denies framing entirely', async () => {
    const res = await request(app).get('/health');
    expect(res.headers['x-frame-options']).toBe('DENY');
  });

  it('sends Referrer-Policy: no-referrer', async () => {
    const res = await request(app).get('/health');
    expect(res.headers['referrer-policy']).toBe('no-referrer');
  });

  it('does not expose X-Powered-By', async () => {
    const res = await request(app).get('/health');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });

  it('advertises X-Content-Type-Options: nosniff', async () => {
    const res = await request(app).get('/health');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
  });
});

describe('Error hygiene', () => {
  it('does not reflect the raw request path in 404 responses', async () => {
    const res = await request(app).get('/api/definitely-not-a-real-path-xyz');
    expect(res.status).toBe(404);
    expect(res.body.message).toBe('Not found.');
    expect(res.body.code).toBe('route_not_found');
  });
});
