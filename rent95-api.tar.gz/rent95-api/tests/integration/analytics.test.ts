import { describe, expect, it } from 'vitest';

import { testApp, tokenFor, authed } from '../support/http';
import { createCategory, createProduct, createUser } from '../support/factories';
import { prisma } from '../../src/config/prisma';

const app = testApp();

/** UTC day at 12:00 so we're safely inside the bucket regardless of TZ. */
function daysAgo(n: number): Date {
  const d = new Date();
  d.setUTCHours(12, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() - n);
  return d;
}

/** Backdate a Prisma row's created_at to a specific timestamp. */
async function backdateOrder(id: string, when: Date) {
  await prisma.$executeRawUnsafe(
    `UPDATE orders SET created_at = $1 WHERE id = $2::uuid`,
    when,
    id,
  );
}
async function backdateUser(id: string, when: Date) {
  await prisma.$executeRawUnsafe(
    `UPDATE users SET created_at = $1 WHERE id = $2::uuid`,
    when,
    id,
  );
}
async function backdateProduct(id: string, when: Date) {
  await prisma.$executeRawUnsafe(
    `UPDATE products SET created_at = $1 WHERE id = $2::uuid`,
    when,
    id,
  );
}
async function backdatePayment(id: string, when: Date) {
  await prisma.$executeRawUnsafe(
    `UPDATE payments SET created_at = $1 WHERE id = $2::uuid`,
    when,
    id,
  );
}

async function makeOrder(opts: {
  when: Date;
  status?: 'paid' | 'active' | 'completed' | 'refunded' | 'disputed' | 'pending';
  totalAmount?: number;
  categoryId?: string;
}) {
  const seller = await createUser({ role: 'seller' });
  const buyer = await createUser({ role: 'buyer' });
  const product = await createProduct({
    ownerId: seller.id,
    ...(opts.categoryId ? { categoryId: opts.categoryId } : {}),
  });
  const order = await prisma.order.create({
    data: {
      orderNumber: `R95-${opts.when.getTime()}-${Math.random().toString(36).slice(2, 5)}`,
      buyerId: buyer.id,
      sellerId: seller.id,
      productId: product.id,
      orderType: 'rental',
      status: opts.status ?? 'paid',
      subtotal: 100,
      totalAmount: opts.totalAmount ?? 130,
      currency: 'USD',
    },
  });
  await backdateOrder(order.id, opts.when);
  return { seller, buyer, product, order };
}

// ---------------------------------------------------------------------------

describe('GET /api/admin/analytics', () => {
  it('403s buyers, 200s admins', async () => {
    const buyer = await createUser({ role: 'buyer' });
    const admin = await createUser({ role: 'admin' });

    const forbidden = await authed(app, tokenFor(buyer)).get('/api/admin/analytics');
    expect(forbidden.status).toBe(403);

    const ok = await authed(app, tokenFor(admin)).get('/api/admin/analytics');
    expect(ok.status).toBe(200);
  });

  it('returns a zero-filled series when there is no data', async () => {
    const admin = await createUser({ role: 'admin' });
    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=7d');
    expect(res.status).toBe(200);
    expect(res.body.data.range.days).toBe(7);
    expect(res.body.data.gmv.total).toBe(0);
    // 7-day window → exactly 7 buckets, all zero.
    expect(res.body.data.gmv.series).toHaveLength(7);
    expect(res.body.data.gmv.series.every((b: { value: number }) => b.value === 0)).toBe(true);
    // Rates default to null when the denominator is zero (see service docs).
    expect(res.body.data.paymentSuccessRate).toBeNull();
    expect(res.body.data.refundRate).toBeNull();
    expect(res.body.data.disputeRate).toBeNull();
    // Deltas default to null when there's nothing to compare.
    expect(res.body.data.gmv.delta).toBeNull();
  });

  it('sums GMV only from paid/active/completed orders', async () => {
    const admin = await createUser({ role: 'admin' });

    // In-window orders — should contribute to GMV in different ways.
    await makeOrder({ when: daysAgo(1), status: 'paid', totalAmount: 100 });
    await makeOrder({ when: daysAgo(2), status: 'completed', totalAmount: 50 });
    await makeOrder({ when: daysAgo(3), status: 'active', totalAmount: 200 });
    // These SHOULD NOT count towards GMV — different statuses.
    await makeOrder({ when: daysAgo(1), status: 'pending', totalAmount: 999 });
    await makeOrder({ when: daysAgo(1), status: 'refunded', totalAmount: 999 });
    await makeOrder({ when: daysAgo(1), status: 'disputed', totalAmount: 999 });

    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=7d');
    expect(res.body.data.gmv.total).toBe(100 + 50 + 200);

    // Locate the two buckets that should have money and verify their values.
    const series: Array<{ day: string; value: number }> = res.body.data.gmv.series;
    const yesterday = daysAgo(1).toISOString().slice(0, 10);
    const twoAgo = daysAgo(2).toISOString().slice(0, 10);
    const threeAgo = daysAgo(3).toISOString().slice(0, 10);

    expect(series.find((b) => b.day === yesterday)?.value).toBe(100);
    expect(series.find((b) => b.day === twoAgo)?.value).toBe(50);
    expect(series.find((b) => b.day === threeAgo)?.value).toBe(200);
  });

  it('excludes orders that fall OUTSIDE the requested window', async () => {
    const admin = await createUser({ role: 'admin' });
    // Way outside the 7-day window.
    await makeOrder({ when: daysAgo(100), status: 'completed', totalAmount: 5000 });
    // Inside the window.
    await makeOrder({ when: daysAgo(1), status: 'completed', totalAmount: 40 });

    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=7d');
    expect(res.body.data.gmv.total).toBe(40);
  });

  it('counts new users per day', async () => {
    const admin = await createUser({ role: 'admin' });
    // Backdate the admin so it doesn't contaminate the today bucket.
    await backdateUser(admin.id, daysAgo(30));

    const u1 = await createUser();
    const u2 = await createUser();
    const u3 = await createUser();
    await backdateUser(u1.id, daysAgo(1));
    await backdateUser(u2.id, daysAgo(1));
    await backdateUser(u3.id, daysAgo(3));

    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=7d');
    expect(res.body.data.newUsers.total).toBe(3);
    const series: Array<{ day: string; value: number }> = res.body.data.newUsers.series;
    expect(series.find((b) => b.day === daysAgo(1).toISOString().slice(0, 10))?.value).toBe(2);
    expect(series.find((b) => b.day === daysAgo(3).toISOString().slice(0, 10))?.value).toBe(1);
  });

  it('counts new listings per day', async () => {
    const admin = await createUser({ role: 'admin' });
    const p1 = await createProduct();
    const p2 = await createProduct();
    await backdateProduct(p1.id, daysAgo(0));
    await backdateProduct(p2.id, daysAgo(2));

    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=7d');
    expect(res.body.data.newListings.total).toBe(2);
  });

  it('breaks down orders by status in the window', async () => {
    const admin = await createUser({ role: 'admin' });
    await makeOrder({ when: daysAgo(1), status: 'paid' });
    await makeOrder({ when: daysAgo(1), status: 'paid' });
    await makeOrder({ when: daysAgo(2), status: 'completed' });
    await makeOrder({ when: daysAgo(3), status: 'refunded' });

    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=7d');
    expect(res.body.data.orders.total).toBe(4);
    expect(res.body.data.orders.byStatus).toMatchObject({
      paid: 2,
      completed: 1,
      refunded: 1,
    });
  });

  it('computes refund and dispute rates as fractions in [0, 1]', async () => {
    const admin = await createUser({ role: 'admin' });
    // 4 orders total: 1 refunded, 1 disputed, 2 completed.
    await makeOrder({ when: daysAgo(1), status: 'completed' });
    await makeOrder({ when: daysAgo(1), status: 'completed' });
    await makeOrder({ when: daysAgo(2), status: 'refunded' });
    await makeOrder({ when: daysAgo(2), status: 'disputed' });

    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=7d');
    expect(res.body.data.refundRate).toBeCloseTo(0.25, 3);
    expect(res.body.data.disputeRate).toBeCloseTo(0.25, 3);
  });

  it('computes paymentSuccessRate from Payment.status', async () => {
    const admin = await createUser({ role: 'admin' });
    const { order } = await makeOrder({ when: daysAgo(1), status: 'paid' });
    // Seed 3 payments: 2 captured, 1 failed.
    const buyer = await createUser({ role: 'buyer' });
    const seller = await createUser({ role: 'seller' });

    const pays = await Promise.all([
      prisma.payment.create({
        data: {
          orderId: order.id, payerId: buyer.id, sellerId: seller.id,
          provider: 'stripe', amount: 100, platformFee: 10, sellerAmount: 90,
          currency: 'USD', status: 'captured', escrowStatus: 'held',
        },
      }),
      prisma.payment.create({
        data: {
          orderId: order.id, payerId: buyer.id, sellerId: seller.id,
          provider: 'stripe', amount: 100, platformFee: 10, sellerAmount: 90,
          currency: 'USD', status: 'captured', escrowStatus: 'held',
        },
      }),
      prisma.payment.create({
        data: {
          orderId: order.id, payerId: buyer.id, sellerId: seller.id,
          provider: 'stripe', amount: 100, platformFee: 10, sellerAmount: 90,
          currency: 'USD', status: 'failed', escrowStatus: 'held',
        },
      }),
    ]);
    for (const p of pays) await backdatePayment(p.id, daysAgo(1));

    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=7d');
    // 2 successful out of 3 total = 66.6...%
    expect(res.body.data.paymentSuccessRate).toBeCloseTo(2 / 3, 3);
  });

  it('ranks top categories by GMV', async () => {
    const admin = await createUser({ role: 'admin' });
    const cars = await createCategory({ name: 'Cars', slug: 'cars-test' });
    const bikes = await createCategory({ name: 'Bikes', slug: 'bikes-test' });
    const boats = await createCategory({ name: 'Boats', slug: 'boats-test' });

    await makeOrder({ when: daysAgo(1), status: 'paid', totalAmount: 500, categoryId: cars.id });
    await makeOrder({ when: daysAgo(2), status: 'paid', totalAmount: 300, categoryId: cars.id });
    await makeOrder({ when: daysAgo(1), status: 'paid', totalAmount: 100, categoryId: bikes.id });
    await makeOrder({ when: daysAgo(1), status: 'paid', totalAmount: 50, categoryId: boats.id });

    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=7d');
    const top: Array<{ name: string; gmv: number; orderCount: number }> =
      res.body.data.topCategories;
    expect(top[0].name).toBe('Cars');
    expect(top[0].gmv).toBe(800);
    expect(top[0].orderCount).toBe(2);
    expect(top[1].name).toBe('Bikes');
  });

  it('computes delta% vs. the previous window', async () => {
    const admin = await createUser({ role: 'admin' });
    // Current 7-day window: 200 GMV.
    await makeOrder({ when: daysAgo(1), status: 'paid', totalAmount: 200 });
    // Previous 7-day window (days 8..14 ago): 100 GMV.
    await makeOrder({ when: daysAgo(10), status: 'paid', totalAmount: 100 });

    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=7d');
    // (200 - 100) / 100 = +100%
    expect(res.body.data.gmv.total).toBe(200);
    expect(res.body.data.gmv.delta?.percent).toBe(100);
    expect(res.body.data.gmv.delta?.vs).toBe('previous_period');
  });

  it('delta is null when the previous window had zero', async () => {
    const admin = await createUser({ role: 'admin' });
    await makeOrder({ when: daysAgo(1), status: 'paid', totalAmount: 200 });

    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=7d');
    expect(res.body.data.gmv.delta).toBeNull();
  });

  it('falls back to 14d for unknown range values', async () => {
    const admin = await createUser({ role: 'admin' });
    const res = await authed(app, tokenFor(admin)).get('/api/admin/analytics?range=potato');
    expect(res.status).toBe(200);
    expect(res.body.data.range.days).toBe(14);
    expect(res.body.data.gmv.series).toHaveLength(14);
  });
});
