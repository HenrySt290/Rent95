import { describe, expect, it } from 'vitest';
import request from 'supertest';

import { testApp, tokenFor, authed } from '../support/http';
import { createProduct, createUser } from '../support/factories';
import { prisma } from '../../src/config/prisma';

describe('POST /api/orders (create booking)', () => {
  const app = testApp();

  it('computes totals server-side and returns them on the created order', async () => {
    const seller = await createUser({ role: 'seller' });
    const buyer = await createUser({ role: 'buyer' });
    const product = await createProduct({
      ownerId: seller.id,
      price: 100,
      priceUnit: 'day',
      securityDeposit: 50,
      currency: 'USD',
    });

    const res = await authed(app, tokenFor(buyer))
      .post('/api/orders')
      .send({
        productId: product.id,
        orderType: 'rental',
        quantity: 1,
        startDatetime: '2030-01-01T10:00:00Z',
        endDatetime: '2030-01-04T10:00:00Z', // 3 days
      });

    expect(res.status).toBe(201);
    // subtotal = 100 * 1 * 3 = 300; platformFee = 10% = 30; tax = 8% of 300 = 24;
    // total = 300 + 30 + 24 + 50 (deposit) = 404
    expect(Number(res.body.data.subtotal)).toBe(300);
    expect(Number(res.body.data.platformFee)).toBe(30);
    expect(Number(res.body.data.taxAmount)).toBe(24);
    expect(Number(res.body.data.securityDeposit)).toBe(50);
    expect(Number(res.body.data.totalAmount)).toBe(404);
    expect(res.body.data.status).toBe('pending');
    expect(res.body.data.buyerId).toBe(buyer.id);
    expect(res.body.data.sellerId).toBe(seller.id);
    expect(res.body.data.orderNumber).toMatch(/^R95-/);
  });

  it('rejects a seller trying to book their own listing', async () => {
    const seller = await createUser({ role: 'seller' });
    const product = await createProduct({ ownerId: seller.id });

    const res = await authed(app, tokenFor(seller))
      .post('/api/orders')
      .send({
        productId: product.id,
        orderType: 'rental',
        quantity: 1,
        startDatetime: '2030-01-01T10:00:00Z',
        endDatetime: '2030-01-02T10:00:00Z',
      });
    expect(res.status).toBe(400);
  });

  it('prevents overlapping bookings when quantity is 1', async () => {
    const seller = await createUser({ role: 'seller' });
    const buyer1 = await createUser({ role: 'buyer' });
    const buyer2 = await createUser({ role: 'buyer' });
    const product = await createProduct({ ownerId: seller.id, quantity: 1 });

    // First booking succeeds.
    const first = await authed(app, tokenFor(buyer1))
      .post('/api/orders')
      .send({
        productId: product.id,
        orderType: 'rental',
        quantity: 1,
        startDatetime: '2030-06-01T10:00:00Z',
        endDatetime: '2030-06-05T10:00:00Z',
      });
    expect(first.status).toBe(201);

    // Bump it into a state that consumes availability. `pending` alone
    // wouldn't block (spec §11.3 lock semantics), but `accepted` does.
    await prisma.order.update({
      where: { id: first.body.data.id },
      data: { status: 'accepted' },
    });

    // Overlapping request from a different buyer must fail.
    const conflict = await authed(app, tokenFor(buyer2))
      .post('/api/orders')
      .send({
        productId: product.id,
        orderType: 'rental',
        quantity: 1,
        startDatetime: '2030-06-03T10:00:00Z', // starts inside the first
        endDatetime: '2030-06-07T10:00:00Z',
      });
    expect(conflict.status).toBe(400);
  });

  it('allows a non-overlapping second booking', async () => {
    const seller = await createUser({ role: 'seller' });
    const buyer = await createUser({ role: 'buyer' });
    const product = await createProduct({ ownerId: seller.id, quantity: 1 });

    const first = await authed(app, tokenFor(buyer))
      .post('/api/orders')
      .send({
        productId: product.id,
        orderType: 'rental',
        quantity: 1,
        startDatetime: '2030-06-01T10:00:00Z',
        endDatetime: '2030-06-05T10:00:00Z',
      });
    await prisma.order.update({
      where: { id: first.body.data.id },
      data: { status: 'accepted' },
    });

    const next = await authed(app, tokenFor(buyer))
      .post('/api/orders')
      .send({
        productId: product.id,
        orderType: 'rental',
        quantity: 1,
        startDatetime: '2030-06-06T10:00:00Z',
        endDatetime: '2030-06-08T10:00:00Z',
      });
    expect(next.status).toBe(201);
  });

  it('rejects end-before-start', async () => {
    const seller = await createUser({ role: 'seller' });
    const buyer = await createUser({ role: 'buyer' });
    const product = await createProduct({ ownerId: seller.id });

    const res = await authed(app, tokenFor(buyer))
      .post('/api/orders')
      .send({
        productId: product.id,
        orderType: 'rental',
        quantity: 1,
        startDatetime: '2030-06-05T10:00:00Z',
        endDatetime: '2030-06-01T10:00:00Z',
      });
    expect(res.status).toBe(400);
  });

  it('rejects quantity > available inventory', async () => {
    const seller = await createUser({ role: 'seller' });
    const buyer = await createUser({ role: 'buyer' });
    const product = await createProduct({ ownerId: seller.id, quantity: 2 });

    const res = await authed(app, tokenFor(buyer))
      .post('/api/orders')
      .send({
        productId: product.id,
        orderType: 'rental',
        quantity: 5,
      });
    expect(res.status).toBe(400);
  });
});

describe('PATCH /api/orders/:id/status', () => {
  const app = testApp();

  async function seedBooking() {
    const seller = await createUser({ role: 'seller' });
    const buyer = await createUser({ role: 'buyer' });
    const product = await createProduct({ ownerId: seller.id });
    const res = await authed(app, tokenFor(buyer))
      .post('/api/orders')
      .send({
        productId: product.id,
        orderType: 'rental',
        quantity: 1,
        startDatetime: '2030-06-01T10:00:00Z',
        endDatetime: '2030-06-02T10:00:00Z',
      });
    return { seller, buyer, product, order: res.body.data };
  }

  it('lets the seller accept a pending order', async () => {
    const { seller, order } = await seedBooking();
    const res = await authed(app, tokenFor(seller))
      .patch(`/api/orders/${order.id}/status`)
      .send({ status: 'accepted' });
    expect(res.status).toBe(200);
    expect(res.body.data.status).toBe('accepted');
  });

  it('forbids the buyer from accepting their own order', async () => {
    const { buyer, order } = await seedBooking();
    const res = await authed(app, tokenFor(buyer))
      .patch(`/api/orders/${order.id}/status`)
      .send({ status: 'accepted' });
    expect(res.status).toBe(403);
  });

  it('forbids a stranger from touching the order', async () => {
    const { order } = await seedBooking();
    const stranger = await createUser();
    const res = await authed(app, tokenFor(stranger))
      .patch(`/api/orders/${order.id}/status`)
      .send({ status: 'cancelled' });
    expect(res.status).toBe(403);
  });

  it('rejects illegal transitions like pending → completed', async () => {
    const { seller, order } = await seedBooking();
    const res = await authed(app, tokenFor(seller))
      .patch(`/api/orders/${order.id}/status`)
      .send({ status: 'completed' });
    expect(res.status).toBe(400);
  });
});

describe('GET /api/buyer/orders and /api/seller/orders', () => {
  const app = testApp();

  it('scopes results to the caller', async () => {
    const seller = await createUser({ role: 'seller' });
    const buyer = await createUser({ role: 'buyer' });
    const other = await createUser({ role: 'buyer' });
    const product = await createProduct({ ownerId: seller.id });

    await authed(app, tokenFor(buyer))
      .post('/api/orders')
      .send({
        productId: product.id,
        orderType: 'rental',
        quantity: 1,
        startDatetime: '2030-06-01T10:00:00Z',
        endDatetime: '2030-06-02T10:00:00Z',
      });

    const buyerList = await authed(app, tokenFor(buyer)).get('/api/buyer/orders');
    expect(buyerList.body.data).toHaveLength(1);

    const otherList = await authed(app, tokenFor(other)).get('/api/buyer/orders');
    expect(otherList.body.data).toHaveLength(0);

    const sellerList = await authed(app, tokenFor(seller)).get('/api/seller/orders');
    expect(sellerList.body.data).toHaveLength(1);
  });
});
