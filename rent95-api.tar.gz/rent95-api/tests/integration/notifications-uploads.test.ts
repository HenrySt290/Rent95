import { describe, expect, it } from 'vitest';
import request from 'supertest';

import { testApp, tokenFor, authed } from '../support/http';
import { createUser } from '../support/factories';
import { prisma } from '../../src/config/prisma';

const app = testApp();

// ---------------------------------------------------------------------------
// Notification inbox
// ---------------------------------------------------------------------------

describe('GET /api/notifications', () => {
  it('401s without a bearer', async () => {
    const res = await request(app).get('/api/notifications');
    expect(res.status).toBe(401);
  });

  it('returns the caller\'s own notifications sorted newest-first', async () => {
    const me = await createUser();
    const other = await createUser();

    // Two mine (one old, one fresh) + one belonging to someone else.
    await prisma.notification.create({
      data: { userId: me.id, title: 'Old', body: 'x', type: 'system' },
    });
    // Backdate via raw SQL so createdAt lands in the past deterministically.
    await prisma.$executeRawUnsafe(
      `UPDATE notifications SET created_at = NOW() - INTERVAL '2 days' WHERE user_id = $1::uuid`,
      me.id,
    );
    await prisma.notification.create({
      data: { userId: me.id, title: 'Fresh', body: 'y', type: 'system' },
    });
    await prisma.notification.create({
      data: { userId: other.id, title: 'Other', body: 'z', type: 'system' },
    });

    const res = await authed(app, tokenFor(me)).get('/api/notifications');
    expect(res.status).toBe(200);
    const titles = (res.body.data as Array<{ title: string }>).map((n) => n.title);
    expect(titles).toEqual(['Fresh', 'Old']);
  });
});

describe('PATCH /api/notifications/:id/read', () => {
  it('marks a notification read + 403s another user', async () => {
    const me = await createUser();
    const stranger = await createUser();
    const n = await prisma.notification.create({
      data: { userId: me.id, title: 'x', body: 'y', type: 'system' },
    });

    // Stranger can't mark my notification as read.
    const forbidden = await authed(app, tokenFor(stranger))
      .patch(`/api/notifications/${n.id}/read`);
    expect(forbidden.status).toBe(403);

    // I can.
    const ok = await authed(app, tokenFor(me)).patch(`/api/notifications/${n.id}/read`);
    expect(ok.status).toBe(200);
    const updated = await prisma.notification.findUnique({ where: { id: n.id } });
    expect(updated?.isRead).toBe(true);
  });

  it('404s unknown ids', async () => {
    const me = await createUser();
    const res = await authed(app, tokenFor(me))
      .patch('/api/notifications/00000000-0000-0000-0000-000000000000/read');
    expect(res.status).toBe(404);
  });
});

describe('PATCH /api/notifications/read-all', () => {
  it('flips every unread notification for the caller only', async () => {
    const me = await createUser();
    const other = await createUser();
    await prisma.notification.createMany({
      data: [
        { userId: me.id, title: 'a', body: 'a', type: 'system' },
        { userId: me.id, title: 'b', body: 'b', type: 'system' },
        { userId: other.id, title: 'c', body: 'c', type: 'system' },
      ],
    });

    const res = await authed(app, tokenFor(me)).patch('/api/notifications/read-all');
    expect(res.status).toBe(200);

    const myUnread = await prisma.notification.count({
      where: { userId: me.id, isRead: false },
    });
    const otherUnread = await prisma.notification.count({
      where: { userId: other.id, isRead: false },
    });
    expect(myUnread).toBe(0);
    expect(otherUnread).toBe(1); // untouched
  });
});

describe('DELETE /api/notifications/:id', () => {
  it('deletes my own, 403s someone else\'s', async () => {
    const me = await createUser();
    const stranger = await createUser();
    const n = await prisma.notification.create({
      data: { userId: me.id, title: 't', body: 'b', type: 'system' },
    });

    const forbid = await authed(app, tokenFor(stranger)).delete(`/api/notifications/${n.id}`);
    expect(forbid.status).toBe(403);
    expect(await prisma.notification.findUnique({ where: { id: n.id } })).not.toBeNull();

    const del = await authed(app, tokenFor(me)).delete(`/api/notifications/${n.id}`);
    expect(del.status).toBe(200);
    expect(await prisma.notification.findUnique({ where: { id: n.id } })).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// Device token registration
// ---------------------------------------------------------------------------

describe('POST /api/users/device-token', () => {
  it('registers a token for the authenticated user', async () => {
    const me = await createUser();
    const res = await authed(app, tokenFor(me))
      .post('/api/users/device-token')
      .send({ token: 'fcm-token-abcdefghijk-1234567890', platform: 'ios' });
    expect(res.status).toBe(200);
    const row = await prisma.deviceToken.findFirst({
      where: { userId: me.id, token: 'fcm-token-abcdefghijk-1234567890' },
    });
    expect(row?.platform).toBe('ios');
  });

  it('is idempotent — re-posting the same token updates the row, does not duplicate', async () => {
    const me = await createUser();
    const client = authed(app, tokenFor(me));
    const body = { token: 'fcm-token-dup-1234567890abcd', platform: 'android' as const };

    await client.post('/api/users/device-token').send(body);
    await client.post('/api/users/device-token').send(body);

    const count = await prisma.deviceToken.count({
      where: { token: body.token },
    });
    expect(count).toBe(1);
  });

  it('422s on bad payload', async () => {
    const me = await createUser();
    const res = await authed(app, tokenFor(me))
      .post('/api/users/device-token')
      .send({ token: 'too-short', platform: 'martian' });
    expect(res.status).toBe(422);
  });

  it('401s without auth', async () => {
    const res = await request(app)
      .post('/api/users/device-token')
      .send({ token: 'fcm-token-abcdefghijk-000000000', platform: 'ios' });
    expect(res.status).toBe(401);
  });
});

// ---------------------------------------------------------------------------
// Cloudinary signature endpoint
// ---------------------------------------------------------------------------

describe('POST /api/uploads/signature', () => {
  it('401s without auth', async () => {
    const res = await request(app)
      .post('/api/uploads/signature')
      .send({ purpose: 'listing' });
    expect(res.status).toBe(401);
  });

  it('400s when Cloudinary is not configured', async () => {
    // Test env has empty CLOUDINARY_* — the controller should refuse the
    // request rather than crash inside cloudinary.utils.api_sign_request.
    const me = await createUser();
    const res = await authed(app, tokenFor(me))
      .post('/api/uploads/signature')
      .send({ purpose: 'listing' });
    // Either 400 (well-formed refusal) or 500 (cloudinary lib throws).
    // Both are acceptable "off" states; not-200 is the point.
    expect([400, 500]).toContain(res.status);
    // MUST NOT leak internal error messages
    if (res.body?.message) {
      expect(res.body.message).not.toMatch(/api_secret/i);
    }
  });
});
