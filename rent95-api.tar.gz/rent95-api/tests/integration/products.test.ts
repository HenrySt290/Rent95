import { describe, expect, it } from 'vitest';
import request from 'supertest';

import { testApp, tokenFor, authed } from '../support/http';
import { createCategory, createProduct, createUser } from '../support/factories';
import { prisma } from '../../src/config/prisma';

describe('GET /api/products (search)', () => {
  const app = testApp();

  it('returns only active + approved listings', async () => {
    const cat = await createCategory({ name: 'Vehicles', slug: 'vehicles' });
    await createProduct({ categoryId: cat.id, title: 'Visible', status: 'active', moderationStatus: 'approved' });
    await createProduct({ categoryId: cat.id, title: 'Pending', status: 'pending', moderationStatus: 'pending' });
    await createProduct({ categoryId: cat.id, title: 'Rejected', moderationStatus: 'rejected' });

    const res = await request(app).get('/api/products');
    expect(res.status).toBe(200);
    const titles = (res.body.data as { title: string }[]).map((p) => p.title);
    expect(titles).toEqual(['Visible']);
  });

  it('filters by categoryId', async () => {
    const cars = await createCategory({ slug: 'cars' });
    const bikes = await createCategory({ slug: 'bikes' });
    await createProduct({ categoryId: cars.id, title: 'Tesla' });
    await createProduct({ categoryId: bikes.id, title: 'BMX' });

    const res = await request(app).get(`/api/products?categoryId=${cars.id}`);
    expect(res.body.data.map((p: { title: string }) => p.title)).toEqual(['Tesla']);
  });

  it('respects minPrice / maxPrice bounds', async () => {
    const cat = await createCategory();
    await createProduct({ categoryId: cat.id, title: 'cheap', price: 20 });
    await createProduct({ categoryId: cat.id, title: 'mid', price: 100 });
    await createProduct({ categoryId: cat.id, title: 'lux', price: 500 });

    const res = await request(app).get('/api/products?minPrice=50&maxPrice=200');
    const titles = (res.body.data as { title: string }[]).map((p) => p.title);
    expect(titles).toEqual(['mid']);
  });

  it('sorts by price_asc', async () => {
    const cat = await createCategory();
    await createProduct({ categoryId: cat.id, title: 'a', price: 300 });
    await createProduct({ categoryId: cat.id, title: 'b', price: 100 });
    await createProduct({ categoryId: cat.id, title: 'c', price: 200 });

    const res = await request(app).get('/api/products?sort=price_asc');
    const prices = (res.body.data as { price: string }[]).map((p) => Number(p.price));
    expect(prices).toEqual([100, 200, 300]);
  });

  it('paginates and reports total + totalPages', async () => {
    const cat = await createCategory();
    for (let i = 0; i < 5; i++) {
      await createProduct({ categoryId: cat.id, title: `p${i}` });
    }
    const res = await request(app).get('/api/products?pageSize=2&page=2');
    expect(res.body.data).toHaveLength(2);
    expect(res.body.pagination.total).toBe(5);
    expect(res.body.pagination.totalPages).toBe(3);
    expect(res.body.pagination.page).toBe(2);
  });
});

describe('GET /api/products/:id', () => {
  const app = testApp();

  it('returns a listing and increments viewCount', async () => {
    const p = await createProduct({ title: 'Track me' });
    expect(p.viewCount).toBe(0);

    const res = await request(app).get(`/api/products/${p.id}`);
    expect(res.status).toBe(200);
    expect(res.body.data.title).toBe('Track me');

    // View tracking is fire-and-forget on the response but always
    // completes before the next request lands.
    const after = await prisma.product.findUnique({ where: { id: p.id } });
    expect(after?.viewCount).toBe(1);
  });

  it('404s for an unknown id', async () => {
    const res = await request(app).get('/api/products/00000000-0000-0000-0000-000000000000');
    expect(res.status).toBe(404);
  });
});

describe('POST /api/products', () => {
  const app = testApp();

  it('creates a listing under the authenticated seller', async () => {
    const seller = await createUser({ role: 'seller' });
    const cat = await createCategory();

    const res = await authed(app, tokenFor(seller))
      .post('/api/products')
      .send({
        title: 'My Camera',
        description: 'A very nice camera for rent, freshly cleaned and calibrated.',
        categoryId: cat.id,
        listingType: 'rent',
        price: 45,
        priceUnit: 'day',
        currency: 'USD',
        quantity: 1,
        location: {
          address: '1 Test St',
          city: 'Brooklyn',
          country: 'USA',
          latitude: 40.7128,
          longitude: -74.006,
        },
      });

    expect(res.status).toBe(201);
    expect(res.body.data.ownerId).toBe(seller.id);
    // New listings start pending — search visibility only after moderation.
    expect(res.body.data.status).toBe('pending');
    expect(res.body.data.moderationStatus).toBe('pending');
  });

  it('rejects buyers with 403', async () => {
    const buyer = await createUser({ role: 'buyer' });
    const cat = await createCategory();
    const res = await authed(app, tokenFor(buyer))
      .post('/api/products')
      .send({
        title: 'My Camera',
        description: 'Long enough description here.',
        categoryId: cat.id,
        listingType: 'rent',
        price: 45,
        priceUnit: 'day',
        currency: 'USD',
        quantity: 1,
        location: { address: 'x', city: 'x', country: 'x', latitude: 0, longitude: 0 },
      });
    expect(res.status).toBe(403);
  });

  it('422 when required fields are missing', async () => {
    const seller = await createUser({ role: 'seller' });
    const res = await authed(app, tokenFor(seller))
      .post('/api/products')
      .send({ title: 'X' });
    expect(res.status).toBe(422);
  });
});

describe('POST /api/products/:productId/favorite', () => {
  const app = testApp();

  it('toggles favorite on then off', async () => {
    const buyer = await createUser();
    const product = await createProduct();
    const client = authed(app, tokenFor(buyer));

    const on = await client.post(`/api/products/${product.id}/favorite`);
    expect(on.status).toBe(200);
    expect(on.body.data.favorited).toBe(true);

    const off = await client.post(`/api/products/${product.id}/favorite`);
    expect(off.body.data.favorited).toBe(false);

    const after = await prisma.product.findUnique({ where: { id: product.id } });
    expect(after?.favoriteCount).toBe(0);
  });

  it('401s without a bearer', async () => {
    const p = await createProduct();
    const res = await request(app).post(`/api/products/${p.id}/favorite`);
    expect(res.status).toBe(401);
  });
});
