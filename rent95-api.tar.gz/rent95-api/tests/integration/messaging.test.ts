import { describe, expect, it } from 'vitest';

import { testApp, tokenFor, authed } from '../support/http';
import { createProduct, createUser } from '../support/factories';
import { prisma } from '../../src/config/prisma';

describe('Messaging', () => {
  const app = testApp();

  async function seedPair() {
    const seller = await createUser({ role: 'seller' });
    const buyer = await createUser({ role: 'buyer' });
    const product = await createProduct({ ownerId: seller.id });
    return { seller, buyer, product };
  }

  it('creates a conversation, reuses it on repeat, and rejects self-message', async () => {
    const { seller, buyer, product } = await seedPair();
    const client = authed(app, tokenFor(buyer));

    const first = await client.post('/api/conversations').send({
      sellerId: seller.id,
      productId: product.id,
    });
    expect(first.status).toBe(201);
    const convId = first.body.data.id;

    // Repeat call must return the SAME conversation, not create a duplicate.
    const again = await client.post('/api/conversations').send({
      sellerId: seller.id,
      productId: product.id,
    });
    expect(again.status).toBe(200);
    expect(again.body.data.id).toBe(convId);

    // Self-message is 400.
    const self = await client.post('/api/conversations').send({ sellerId: buyer.id });
    expect(self.status).toBe(400);
  });

  it('lists only conversations the caller participates in', async () => {
    const { seller, buyer } = await seedPair();
    const stranger = await createUser();

    await authed(app, tokenFor(buyer))
      .post('/api/conversations')
      .send({ sellerId: seller.id });

    const buyerList = await authed(app, tokenFor(buyer)).get('/api/conversations');
    expect(buyerList.body.data).toHaveLength(1);

    const strangerList = await authed(app, tokenFor(stranger)).get('/api/conversations');
    expect(strangerList.body.data).toHaveLength(0);
  });

  it('sends messages, updates lastMessage/lastMessageAt, and 403s outsiders', async () => {
    const { seller, buyer } = await seedPair();
    const buyerClient = authed(app, tokenFor(buyer));

    const conv = (
      await buyerClient.post('/api/conversations').send({ sellerId: seller.id })
    ).body.data;

    const send = await buyerClient
      .post(`/api/conversations/${conv.id}/messages`)
      .send({ content: 'Hi there', type: 'text' });
    expect(send.status).toBe(201);
    expect(send.body.data.content).toBe('Hi there');
    expect(send.body.data.senderId).toBe(buyer.id);
    expect(send.body.data.receiverId).toBe(seller.id);

    const list = await buyerClient.get(`/api/conversations/${conv.id}/messages`);
    expect(list.body.data).toHaveLength(1);

    // Denormalized last-message columns updated on the conversation row.
    const updated = await prisma.conversation.findUnique({ where: { id: conv.id } });
    expect(updated?.lastMessage).toBe('Hi there');
    expect(updated?.lastMessageAt).not.toBeNull();

    // A third-party can't read the messages.
    const outsider = await createUser();
    const forbidden = await authed(app, tokenFor(outsider)).get(
      `/api/conversations/${conv.id}/messages`,
    );
    expect(forbidden.status).toBe(403);
  });

  it('validates that a message has either content or mediaUrl', async () => {
    const { seller, buyer } = await seedPair();
    const buyerClient = authed(app, tokenFor(buyer));
    const conv = (
      await buyerClient.post('/api/conversations').send({ sellerId: seller.id })
    ).body.data;

    const res = await buyerClient
      .post(`/api/conversations/${conv.id}/messages`)
      .send({ type: 'text' });
    expect(res.status).toBe(422);
  });
});
