import { describe, expect, it } from 'vitest';
import request from 'supertest';

import { testApp } from '../support/http';
import { createCategory } from '../support/factories';
import { prisma } from '../../src/config/prisma';

describe('Categories', () => {
  const app = testApp();

  it('/api/categories returns only active categories sorted by sortOrder', async () => {
    await createCategory({ name: 'Zebras', slug: 'zebras' });
    await createCategory({ name: 'Apples', slug: 'apples' });
    // Manually flip one inactive so we can assert it's filtered.
    await prisma.category.updateMany({
      where: { slug: 'zebras' },
      data: { isActive: false, sortOrder: 1 },
    });
    await prisma.category.updateMany({
      where: { slug: 'apples' },
      data: { sortOrder: 0 },
    });

    const res = await request(app).get('/api/categories');
    expect(res.status).toBe(200);
    const names = (res.body.data as { name: string }[]).map((c) => c.name);
    expect(names).toContain('Apples');
    expect(names).not.toContain('Zebras');
  });

  it('/api/categories/tree builds a parent → children shape', async () => {
    const parent = await createCategory({ name: 'Vehicles', slug: 'vehicles' });
    await prisma.category.create({
      data: {
        name: 'Cars',
        slug: 'cars',
        parentId: parent.id,
        allowedModes: ['rent', 'sale'],
      },
    });
    await prisma.category.create({
      data: {
        name: 'Bikes',
        slug: 'bikes',
        parentId: parent.id,
        allowedModes: ['rent', 'sale'],
      },
    });

    const res = await request(app).get('/api/categories/tree');
    expect(res.status).toBe(200);
    const tree = res.body.data as Array<{ name: string; children: { name: string }[] }>;
    const vehicles = tree.find((n) => n.name === 'Vehicles');
    expect(vehicles).toBeDefined();
    expect(vehicles!.children.map((c) => c.name).sort()).toEqual(['Bikes', 'Cars']);
  });
});

describe('Health', () => {
  const app = testApp();
  it('/health returns ok', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });
});

describe('404 handling', () => {
  const app = testApp();
  it('returns a friendly JSON 404 for unknown routes', async () => {
    const res = await request(app).get('/api/does-not-exist');
    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
    expect(res.body.code).toBe('route_not_found');
  });
});
