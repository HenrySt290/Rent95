import { describe, expect, it } from 'vitest';

import { testApp, tokenFor, authed } from '../support/http';
import { createProduct, createUser } from '../support/factories';
import { prisma } from '../../src/config/prisma';

// ---------------------------------------------------------------------------
// GET /api/admin/orders
// ---------------------------------------------------------------------------

describe('GET /api/admin/orders', () => {
  const app = testApp();

  async function seedOrder(overrides: Partial<{
    status: 'pending' | 'paid' | 'completed' | 'refunded';
    orderType: 'rental' | 'purchase' | 'service';
    buyerId: string;
    sellerId: string;
    orderNumber: string;
  }> = {}) {
    const buyer = overrides.buyerId
      ? await prisma.user.findUniqueOrThrow({ where: { id: overrides.buyerId } })
      : await createUser({ role: 'buyer' });
    const seller = overrides.sellerId
      ? await prisma.user.findUniqueOrThrow({ where: { id: overrides.sellerId } })
      : await createUser({ role: 'seller' });
    const product = await createProduct({ ownerId: seller.id });
    return prisma.order.create({
      data: {
        orderNumber: overrides.orderNumber ?? `R95-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        buyerId: buyer.id,
        sellerId: seller.id,
        productId: product.id,
        orderType: overrides.orderType ?? 'rental',
        status: overrides.status ?? 'paid',
        subtotal: 100,
        totalAmount: 130,
        currency: 'USD',
      },
    });
  }

  it('403s buyers, 200s admins', async () => {
    const buyer = await createUser({ role: 'buyer' });
    const admin = await createUser({ role: 'admin' });

    const forbidden = await authed(app, tokenFor(buyer)).get('/api/admin/orders');
    expect(forbidden.status).toBe(403);

    const ok = await authed(app, tokenFor(admin)).get('/api/admin/orders');
    expect(ok.status).toBe(200);
  });

  it('returns paginated results with buyer/seller/product relations', async () => {
    const admin = await createUser({ role: 'admin' });
    await seedOrder();
    await seedOrder();

    const res = await authed(app, tokenFor(admin)).get('/api/admin/orders');
    expect(res.body.data).toHaveLength(2);
    expect(res.body.pagination.total).toBe(2);
    expect(res.body.data[0].buyer.email).toEqual(expect.any(String));
    expect(res.body.data[0].seller.email).toEqual(expect.any(String));
    expect(res.body.data[0].product.title).toEqual(expect.any(String));
  });

  it('filters by status', async () => {
    const admin = await createUser({ role: 'admin' });
    await seedOrder({ status: 'paid' });
    await seedOrder({ status: 'completed' });
    await seedOrder({ status: 'refunded' });

    const res = await authed(app, tokenFor(admin)).get('/api/admin/orders?status=paid');
    expect(res.body.data).toHaveLength(1);
    expect(res.body.data[0].status).toBe('paid');
  });

  it('filters by orderType', async () => {
    const admin = await createUser({ role: 'admin' });
    await seedOrder({ orderType: 'rental' });
    await seedOrder({ orderType: 'purchase' });

    const res = await authed(app, tokenFor(admin)).get('/api/admin/orders?orderType=purchase');
    expect(res.body.data).toHaveLength(1);
    expect(res.body.data[0].orderType).toBe('purchase');
  });

  it('filters by sellerId', async () => {
    const admin = await createUser({ role: 'admin' });
    const targetSeller = await createUser({ role: 'seller' });
    await seedOrder({ sellerId: targetSeller.id });
    await seedOrder(); // different seller

    const res = await authed(app, tokenFor(admin))
      .get(`/api/admin/orders?sellerId=${targetSeller.id}`);
    expect(res.body.data).toHaveLength(1);
    expect(res.body.data[0].sellerId).toBe(targetSeller.id);
  });

  it('ignores unknown status values (defence-in-depth)', async () => {
    const admin = await createUser({ role: 'admin' });
    await seedOrder({ status: 'paid' });
    const res = await authed(app, tokenFor(admin)).get('/api/admin/orders?status=totally-fake');
    // Bad status is silently dropped -> returns everything
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveLength(1);
  });

  it('respects pagination bounds', async () => {
    const admin = await createUser({ role: 'admin' });
    for (let i = 0; i < 5; i++) await seedOrder();

    const p1 = await authed(app, tokenFor(admin)).get('/api/admin/orders?pageSize=2&page=1');
    expect(p1.body.data).toHaveLength(2);
    expect(p1.body.pagination.total).toBe(5);
    expect(p1.body.pagination.totalPages).toBe(3);

    const p3 = await authed(app, tokenFor(admin)).get('/api/admin/orders?pageSize=2&page=3');
    expect(p3.body.data).toHaveLength(1);
  });
});

// ---------------------------------------------------------------------------
// GET /api/admin/payments
// ---------------------------------------------------------------------------

describe('GET /api/admin/payments', () => {
  const app = testApp();

  async function seedPayment(overrides: Partial<{
    status: 'created' | 'authorized' | 'captured' | 'refunded';
    escrowStatus: 'held' | 'released' | 'refunded';
    provider: 'stripe' | 'razorpay';
    amount: number;
  }> = {}) {
    const buyer = await createUser({ role: 'buyer' });
    const seller = await createUser({ role: 'seller' });
    const product = await createProduct({ ownerId: seller.id });
    const order = await prisma.order.create({
      data: {
        orderNumber: `R95-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        buyerId: buyer.id,
        sellerId: seller.id,
        productId: product.id,
        orderType: 'rental',
        status: 'paid',
        subtotal: 100,
        totalAmount: overrides.amount ?? 130,
        currency: 'USD',
      },
    });
    return prisma.payment.create({
      data: {
        orderId: order.id,
        payerId: buyer.id,
        sellerId: seller.id,
        provider: overrides.provider ?? 'stripe',
        providerPaymentId: `pi_test_${Math.random().toString(36).slice(2, 12)}`,
        amount: overrides.amount ?? 130,
        platformFee: 13,
        sellerAmount: (overrides.amount ?? 130) - 13,
        currency: 'USD',
        status: overrides.status ?? 'captured',
        escrowStatus: overrides.escrowStatus ?? 'held',
      },
    });
  }

  it('403s buyers, 200s admins', async () => {
    const buyer = await createUser({ role: 'buyer' });
    const admin = await createUser({ role: 'admin' });

    const forbidden = await authed(app, tokenFor(buyer)).get('/api/admin/payments');
    expect(forbidden.status).toBe(403);

    const ok = await authed(app, tokenFor(admin)).get('/api/admin/payments');
    expect(ok.status).toBe(200);
  });

  it('403s moderators — payments are admin-only', async () => {
    const mod = await createUser({ role: 'moderator' });
    const support = await createUser({ role: 'support' });

    const modRes = await authed(app, tokenFor(mod)).get('/api/admin/payments');
    expect(modRes.status).toBe(403);

    const supportRes = await authed(app, tokenFor(support)).get('/api/admin/payments');
    expect(supportRes.status).toBe(403);
  });

  it('returns payments with order + payer + seller relations', async () => {
    const admin = await createUser({ role: 'admin' });
    await seedPayment();

    const res = await authed(app, tokenFor(admin)).get('/api/admin/payments');
    expect(res.body.data).toHaveLength(1);
    const p = res.body.data[0];
    expect(p.order.orderNumber).toEqual(expect.stringMatching(/^R95-/));
    expect(p.payer.email).toEqual(expect.any(String));
    expect(p.seller.email).toEqual(expect.any(String));
    expect(p.providerPaymentId).toMatch(/^pi_test_/);
  });

  it('filters by escrowStatus', async () => {
    const admin = await createUser({ role: 'admin' });
    await seedPayment({ escrowStatus: 'held' });
    await seedPayment({ escrowStatus: 'released' });
    await seedPayment({ escrowStatus: 'refunded' });

    const heldOnly = await authed(app, tokenFor(admin))
      .get('/api/admin/payments?escrowStatus=held');
    expect(heldOnly.body.data).toHaveLength(1);
    expect(heldOnly.body.data[0].escrowStatus).toBe('held');
  });

  it('filters by provider', async () => {
    const admin = await createUser({ role: 'admin' });
    await seedPayment({ provider: 'stripe' });
    await seedPayment({ provider: 'razorpay' });

    const res = await authed(app, tokenFor(admin))
      .get('/api/admin/payments?provider=razorpay');
    expect(res.body.data).toHaveLength(1);
    expect(res.body.data[0].provider).toBe('razorpay');
  });
});

// ---------------------------------------------------------------------------
// GET /api/admin/disputes
// PATCH /api/admin/disputes/:id/resolve
// ---------------------------------------------------------------------------

describe('Disputes', () => {
  const app = testApp();

  async function seedDispute(overrides: Partial<{
    status: 'open' | 'under_review' | 'resolved' | 'rejected';
    reason: string;
  }> = {}) {
    const buyer = await createUser({ role: 'buyer' });
    const seller = await createUser({ role: 'seller' });
    const product = await createProduct({ ownerId: seller.id });
    const order = await prisma.order.create({
      data: {
        orderNumber: `R95-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        buyerId: buyer.id,
        sellerId: seller.id,
        productId: product.id,
        orderType: 'rental',
        status: 'paid',
        subtotal: 100,
        totalAmount: 130,
        currency: 'USD',
      },
    });
    // Every dispute needs a matching payment row so escrow updates have
    // something to write against.
    await prisma.payment.create({
      data: {
        orderId: order.id,
        payerId: buyer.id,
        sellerId: seller.id,
        provider: 'stripe',
        providerPaymentId: `pi_test_${Math.random().toString(36).slice(2, 10)}`,
        amount: 130,
        platformFee: 13,
        sellerAmount: 117,
        currency: 'USD',
        status: 'captured',
        escrowStatus: 'held',
      },
    });
    const dispute = await prisma.dispute.create({
      data: {
        orderId: order.id,
        raisedBy: buyer.id,
        againstUserId: seller.id,
        reason: overrides.reason ?? 'Item not as described',
        description: 'The camera arrived with a cracked screen and the lens cap missing.',
        status: overrides.status ?? 'open',
      },
    });
    return { buyer, seller, order, dispute };
  }

  it('403s buyers on GET, 200s admins', async () => {
    const buyer = await createUser({ role: 'buyer' });
    const admin = await createUser({ role: 'admin' });

    const forbidden = await authed(app, tokenFor(buyer)).get('/api/admin/disputes');
    expect(forbidden.status).toBe(403);

    const ok = await authed(app, tokenFor(admin)).get('/api/admin/disputes');
    expect(ok.status).toBe(200);
  });

  it('returns disputes with order + raisedBy + against relations', async () => {
    const admin = await createUser({ role: 'admin' });
    await seedDispute();

    const res = await authed(app, tokenFor(admin)).get('/api/admin/disputes');
    expect(res.body.data).toHaveLength(1);
    const d = res.body.data[0];
    expect(d.reason).toBe('Item not as described');
    expect(d.raisedByUser.email).toEqual(expect.any(String));
    expect(d.againstUser.email).toEqual(expect.any(String));
    expect(d.order.orderNumber).toEqual(expect.stringMatching(/^R95-/));
  });

  it('filters by status', async () => {
    const admin = await createUser({ role: 'admin' });
    await seedDispute({ status: 'open' });
    await seedDispute({ status: 'resolved' });
    await seedDispute({ status: 'rejected' });

    const res = await authed(app, tokenFor(admin))
      .get('/api/admin/disputes?status=open');
    expect(res.body.data).toHaveLength(1);
    expect(res.body.data[0].status).toBe('open');
  });

  // -- Resolution -----------------------------------------------------------

  it('refund_buyer flips order → refunded and payment → refunded', async () => {
    const admin = await createUser({ role: 'admin' });
    const { order, dispute } = await seedDispute();

    const res = await authed(app, tokenFor(admin))
      .patch(`/api/admin/disputes/${dispute.id}/resolve`)
      .send({ resolution: 'refund_buyer', note: 'Damaged item, buyer refunded.' });

    expect(res.status).toBe(200);
    expect(res.body.data.status).toBe('resolved');
    expect(res.body.data.resolution).toContain('Refunded buyer in full');

    const orderAfter = await prisma.order.findUnique({ where: { id: order.id } });
    expect(orderAfter?.status).toBe('refunded');

    const paymentAfter = await prisma.payment.findFirst({ where: { orderId: order.id } });
    expect(paymentAfter?.status).toBe('refunded');
    expect(paymentAfter?.escrowStatus).toBe('refunded');
  });

  it('release_seller flips order → completed', async () => {
    const admin = await createUser({ role: 'admin' });
    const { order, dispute } = await seedDispute();

    const res = await authed(app, tokenFor(admin))
      .patch(`/api/admin/disputes/${dispute.id}/resolve`)
      .send({ resolution: 'release_seller', note: 'Buyer misrepresented the issue.' });

    expect(res.status).toBe(200);
    const orderAfter = await prisma.order.findUnique({ where: { id: order.id } });
    expect(orderAfter?.status).toBe('completed');
    // The dispute itself is resolved.
    const disputeAfter = await prisma.dispute.findUnique({ where: { id: dispute.id } });
    expect(disputeAfter?.status).toBe('resolved');
  });

  it('partial_refund marks payment as partially_refunded and records the amount', async () => {
    const admin = await createUser({ role: 'admin' });
    const { order, dispute } = await seedDispute();

    const res = await authed(app, tokenFor(admin))
      .patch(`/api/admin/disputes/${dispute.id}/resolve`)
      .send({
        resolution: 'partial_refund',
        partialRefundAmount: 40,
        note: 'Lens cap replacement fee.',
      });

    expect(res.status).toBe(200);
    expect(res.body.data.resolution).toContain('Partial refund of 40');

    const paymentAfter = await prisma.payment.findFirst({ where: { orderId: order.id } });
    expect(paymentAfter?.status).toBe('partially_refunded');
    expect(paymentAfter?.escrowStatus).toBe('refunded');
  });

  it('partial_refund without amount 400s', async () => {
    const admin = await createUser({ role: 'admin' });
    const { dispute } = await seedDispute();

    const res = await authed(app, tokenFor(admin))
      .patch(`/api/admin/disputes/${dispute.id}/resolve`)
      .send({ resolution: 'partial_refund' });
    expect(res.status).toBe(400);
  });

  it('reject closes the dispute without touching the order', async () => {
    const admin = await createUser({ role: 'admin' });
    const { order, dispute } = await seedDispute();

    const res = await authed(app, tokenFor(admin))
      .patch(`/api/admin/disputes/${dispute.id}/resolve`)
      .send({ resolution: 'reject', note: 'No evidence of damage in the photos submitted.' });

    expect(res.status).toBe(200);
    expect(res.body.data.status).toBe('rejected');
    const orderAfter = await prisma.order.findUnique({ where: { id: order.id } });
    // Order left untouched — was 'paid', stays 'paid'.
    expect(orderAfter?.status).toBe('paid');
  });

  it('cannot resolve a dispute that is already closed', async () => {
    const admin = await createUser({ role: 'admin' });
    const { dispute } = await seedDispute({ status: 'resolved' });

    const res = await authed(app, tokenFor(admin))
      .patch(`/api/admin/disputes/${dispute.id}/resolve`)
      .send({ resolution: 'refund_buyer' });
    expect(res.status).toBe(400);
  });

  it('403s a support agent from resolving', async () => {
    const support = await createUser({ role: 'support' });
    const { dispute } = await seedDispute();

    const res = await authed(app, tokenFor(support))
      .patch(`/api/admin/disputes/${dispute.id}/resolve`)
      .send({ resolution: 'refund_buyer' });
    expect(res.status).toBe(403);
  });

  it('400s on unknown resolution value', async () => {
    const admin = await createUser({ role: 'admin' });
    const { dispute } = await seedDispute();

    const res = await authed(app, tokenFor(admin))
      .patch(`/api/admin/disputes/${dispute.id}/resolve`)
      .send({ resolution: 'do-what-i-want' });
    expect(res.status).toBe(400);
  });

  it('404s on unknown dispute id', async () => {
    const admin = await createUser({ role: 'admin' });
    const res = await authed(app, tokenFor(admin))
      .patch('/api/admin/disputes/00000000-0000-0000-0000-000000000000/resolve')
      .send({ resolution: 'refund_buyer' });
    expect(res.status).toBe(404);
  });
});

// ---------------------------------------------------------------------------
// GET /api/admin/products (moderation queue)
// ---------------------------------------------------------------------------

describe('GET /api/admin/products (moderation queue)', () => {
  const app = testApp();

  it('returns EVERY listing including pending and rejected', async () => {
    const admin = await createUser({ role: 'admin' });
    await createProduct({ moderationStatus: 'approved', status: 'active' });
    await createProduct({ moderationStatus: 'pending', status: 'pending' });
    await createProduct({ moderationStatus: 'rejected', status: 'rejected' });

    const res = await authed(app, tokenFor(admin)).get('/api/admin/products');
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveLength(3);
  });

  it('filters to the pending queue with ?moderationStatus=pending', async () => {
    const admin = await createUser({ role: 'admin' });
    await createProduct({ moderationStatus: 'approved', status: 'active' });
    await createProduct({ moderationStatus: 'pending', status: 'pending' });

    const res = await authed(app, tokenFor(admin))
      .get('/api/admin/products?moderationStatus=pending');
    expect(res.body.data).toHaveLength(1);
    expect(res.body.data[0].moderationStatus).toBe('pending');
  });

  it('shows the pending queue in oldest-first order (FIFO)', async () => {
    const admin = await createUser({ role: 'admin' });
    const a = await createProduct({ moderationStatus: 'pending', status: 'pending', title: 'A' });
    // Bump B's createdAt so we're sure of ordering regardless of clock resolution.
    const b = await createProduct({ moderationStatus: 'pending', status: 'pending', title: 'B' });
    await prisma.product.update({
      where: { id: a.id },
      data: { createdAt: new Date(Date.now() - 60_000) },
    });
    void b;

    const res = await authed(app, tokenFor(admin))
      .get('/api/admin/products?moderationStatus=pending');
    expect(res.body.data[0].title).toBe('A');
    expect(res.body.data[1].title).toBe('B');
  });

  it('keyword search hits both title and description', async () => {
    const admin = await createUser({ role: 'admin' });
    await createProduct({ title: 'Vintage Camera' });
    await createProduct({ title: 'Bicycle' });

    const res = await authed(app, tokenFor(admin))
      .get('/api/admin/products?keyword=camera');
    expect(res.body.data).toHaveLength(1);
    expect(res.body.data[0].title).toBe('Vintage Camera');
  });
});
