import { describe, expect, it } from 'vitest';
import request from 'supertest';

import { testApp } from '../support/http';
import { createUser } from '../support/factories';
import { prisma } from '../../src/config/prisma';
import { hashRefreshToken } from '../../src/utils/crypto';

describe('POST /api/auth/register', () => {
  const app = testApp();

  it('creates a user, hashes the password, and returns tokens', async () => {
    const res = await request(app).post('/api/auth/register').send({
      fullName: 'Alex Rivera',
      email: 'new@example.com',
      password: 'supersecret',
    });

    expect(res.status).toBe(201);
    expect(res.body.data.accessToken).toEqual(expect.any(String));
    expect(res.body.data.refreshToken).toEqual(expect.any(String));
    expect(res.body.data.user.email).toBe('new@example.com');
    // Response must never leak the password hash.
    expect(res.body.data.user.passwordHash).toBeUndefined();

    // DB check: password stored HASHED, never in plaintext.
    const stored = await prisma.user.findUnique({ where: { email: 'new@example.com' } });
    expect(stored?.passwordHash).toBeTruthy();
    expect(stored?.passwordHash).not.toBe('supersecret');
    expect(stored?.passwordHash?.startsWith('$argon2')).toBe(true);

    // Refresh token in DB is the SHA-256 hash, not the raw string.
    const refreshRow = await prisma.refreshToken.findUnique({
      where: { tokenHash: hashRefreshToken(res.body.data.refreshToken) },
    });
    expect(refreshRow).not.toBeNull();
  });

  it('rejects duplicate emails with 409', async () => {
    await createUser({ email: 'dup@example.com' });
    const res = await request(app).post('/api/auth/register').send({
      fullName: 'X',
      email: 'dup@example.com',
      password: 'supersecret',
    });
    expect(res.status).toBe(409);
  });

  it('validates the payload with 422 and field errors', async () => {
    const res = await request(app).post('/api/auth/register').send({
      fullName: 'X',
      email: 'not-an-email',
      password: 'short',
    });
    expect(res.status).toBe(422);
    expect(res.body.errors).toBeDefined();
    expect(res.body.errors.email).toBeDefined();
    expect(res.body.errors.password).toBeDefined();
  });
});

describe('POST /api/auth/login', () => {
  const app = testApp();

  it('returns tokens for valid creds', async () => {
    await createUser({ email: 'login@example.com', password: 'p@ssw0rd!' });
    const res = await request(app).post('/api/auth/login').send({
      email: 'login@example.com',
      password: 'p@ssw0rd!',
    });
    expect(res.status).toBe(200);
    expect(res.body.data.accessToken).toEqual(expect.any(String));
    expect(res.body.data.refreshToken).toEqual(expect.any(String));
  });

  it('401s on wrong password without leaking whether the email exists', async () => {
    await createUser({ email: 'target@example.com', password: 'right' });
    const res = await request(app).post('/api/auth/login').send({
      email: 'target@example.com',
      password: 'wrong',
    });
    expect(res.status).toBe(401);
  });

  it('401s on unknown email with the same shape of response', async () => {
    const res = await request(app).post('/api/auth/login').send({
      email: 'ghost@example.com',
      password: 'anything',
    });
    expect(res.status).toBe(401);
  });
});

describe('POST /api/auth/refresh-token', () => {
  const app = testApp();

  it('rotates the refresh token (issues new pair, revokes old)', async () => {
    // Seed a session by registering.
    const reg = await request(app).post('/api/auth/register').send({
      fullName: 'Rot',
      email: 'rot@example.com',
      password: 'supersecret',
    });
    const oldRefresh = reg.body.data.refreshToken as string;
    const oldAccess = reg.body.data.accessToken as string;

    const res = await request(app)
      .post('/api/auth/refresh-token')
      .send({ refreshToken: oldRefresh });

    expect(res.status).toBe(200);
    const newAccess = res.body.data.accessToken as string;
    const newRefresh = res.body.data.refreshToken as string;
    expect(newAccess).not.toBe(oldAccess);
    expect(newRefresh).not.toBe(oldRefresh);

    // The old refresh token must not work a second time.
    const replay = await request(app)
      .post('/api/auth/refresh-token')
      .send({ refreshToken: oldRefresh });
    expect(replay.status).toBe(401);
  });

  it('rejects an unknown refresh token', async () => {
    const res = await request(app)
      .post('/api/auth/refresh-token')
      .send({ refreshToken: 'not-a-real-token' });
    expect(res.status).toBe(401);
  });
});

describe('GET /api/auth/me', () => {
  const app = testApp();

  it('returns the current user for a valid bearer', async () => {
    const reg = await request(app).post('/api/auth/register').send({
      fullName: 'Me',
      email: 'me@example.com',
      password: 'supersecret',
    });
    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${reg.body.data.accessToken}`);
    expect(res.status).toBe(200);
    expect(res.body.data.email).toBe('me@example.com');
  });

  it('401s without a bearer', async () => {
    const res = await request(app).get('/api/auth/me');
    expect(res.status).toBe(401);
  });

  it('401s with a garbage bearer', async () => {
    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', 'Bearer not-a-jwt');
    expect(res.status).toBe(401);
  });
});
