#!/bin/sh
# Release phase — runs ONCE per deploy, on one machine, before any user
# traffic hits the new build.
#
# Fly calls this via `release_command` in fly.toml.
# Render calls it via `preDeployCommand` in render.yaml.
# Locally you can run it too: `./scripts/release.sh`.
#
# Everything here must be idempotent so a retried deploy is a no-op.

set -eu

echo "→ Running Prisma migrations against $DATABASE_URL"

# `migrate deploy` applies committed migrations in order without prompting.
# Never use `migrate dev` in prod — it can drop the shadow DB, which in
# some managed setups means dropping your real DB.
npx prisma migrate deploy

echo "✓ Release phase complete"
