# Rent95 API 🛠️

**Node.js + Express + TypeScript + Prisma + Postgres backend** for the Rent95 marketplace mobile app.

Companion to [`HenrySt290/Rent95`](https://github.com/HenrySt290/Rent95) — flip the Flutter app's `USE_MOCKS=false` and point it at this API.

---

## What's implemented

- ✅ **Auth**: register / login / refresh / logout / me / change-password — Argon2 password hashing, JWT access + rotating refresh tokens stored as SHA-256 hashes
- ✅ **Users**: profiles, role-based auth (buyer/seller/admin/moderator/support), account status (active/suspended/banned)
- ✅ **Categories**: listing + tree endpoints
- ✅ **Products/listings**: search (keyword/category/price/city/type/sort), get by id, create (seller-only), update, pause/archive, favorites toggle
- ✅ **Orders**: create with server-side price math, seller accept/reject, status transitions, buyer/seller order lists, **overlap prevention via `SERIALIZABLE` transaction**
- ✅ **Payments**: Stripe Connect Express — `PaymentIntent` with `capture_method: 'manual'` for escrow, `application_fee_amount` for platform take, `transfer_data.destination` for seller payout, webhook handler with signature verification
- ✅ **Escrow**: funds held until order completes, then captured + marked released
- ✅ **Reviews**: buyer-only post-completion, one-per-order, product rating auto-recomputed in a transaction
- ✅ **Messaging**: conversations + messages REST + **Socket.io** with JWT auth, Redis adapter for horizontal scale, typing indicators, read receipts, order/user/conversation rooms
- ✅ **Admin**: dashboard metrics, user list, moderate listings (approve/reject with reason), suspend/activate/ban users
- ✅ **Security**: Helmet, CORS allowlist, rate limits (global + auth + OTP), Zod validation on every input, typed error middleware, idempotency keys on payments, webhooks signature-verified

## What's stubbed / deferred

- Google/Apple OAuth (endpoints reserved, implementation left for you to plug in with `google-auth-library` + `apple-signin-auth`)
- Phone OTP send/verify (route reserved, needs Twilio/MSG91 credentials)
- KYC document upload (Stripe Identity handoff recommended per revised MVP)
- Cloudinary/S3 signed upload URL endpoint (add when your storage bucket is ready)
- Razorpay (India launch — v1.1)
- FCM push worker (Redis queue skeleton exists in `sockets/`; add a BullMQ worker + Firebase Admin SDK in `src/jobs/push.ts`)
- Search re-indexing to Meilisearch (Postgres full-text works fine for MVP)

Every one of these has a clear seam in the code.

---

## Prerequisites

- Node.js **≥ 20**
- Docker + Docker Compose (to run Postgres + Redis locally)
- npm (or pnpm/yarn — pick one and stick to it)

---

## Getting started

```bash
# 1. Install dependencies
npm install

# 2. Copy env template
cp .env.example .env
# then edit .env — the defaults work with the docker-compose file below

# 3. Start Postgres + Redis
docker compose up -d

# 4. Run migrations + seed
npm run prisma:migrate       # creates the schema, name it e.g. "init"
npm run db:seed              # inserts admin user, categories, sample listings

# 5. Run in dev (hot reload)
npm run dev
```

You should see:
```
🚀 Rent95 API listening on http://localhost:4000
```

### Quick sanity check

```bash
# health
curl http://localhost:4000/health

# search listings (public)
curl 'http://localhost:4000/api/products?keyword=tesla'

# categories
curl http://localhost:4000/api/categories

# login (returns accessToken + refreshToken)
curl -X POST http://localhost:4000/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"alex@example.com","password":"demo1234"}'
```

---

## Connecting the Flutter app

In the mobile repo run:

```bash
flutter run \
  --dart-define=USE_MOCKS=false \
  --dart-define=API_BASE_URL=http://localhost:4000 \
  --dart-define=SOCKET_URL=http://localhost:4000
```

On an Android emulator, replace `localhost` with `10.0.2.2`. On a physical device, use your machine's LAN IP.

---

## Project layout

```
src/
├── config/           # env, logger, prisma, redis singletons
├── middleware/       # auth, validate, rate-limit, error handler
├── controllers/      # thin HTTP layer, one file per domain
├── services/         # business logic (auth, product, order, payment)
├── routes/           # Express routers, one per domain
├── validators/       # Zod schemas
├── sockets/          # Socket.io setup + event handlers
├── utils/            # errors, crypto, slug, response helpers
├── jobs/             # background workers (BullMQ) — placeholder
├── app.ts            # Express app factory
└── server.ts         # HTTP + Socket bootstrap

prisma/
├── schema.prisma     # single source of truth for DB
└── seed.ts           # deterministic seed data

tests/
└── utils.test.ts     # Vitest — expand as needed
```

## Commands

| Command | Purpose |
|---|---|
| `npm run dev` | Hot-reload development server via `tsx` |
| `npm run build` | Compile to `dist/` |
| `npm start` | Run compiled server |
| `npm run typecheck` | TypeScript check without emit |
| `npm run lint` | ESLint |
| `npm test` | Vitest one-shot |
| `npm run prisma:migrate` | Create a new dev migration |
| `npm run prisma:studio` | Web GUI for the DB |
| `npm run db:seed` | Seed sample data |
| `npm run db:reset` | Drop, migrate, seed (destroys data) |

## API surface (all under `/api`)

Matches the endpoints listed in the mobile repo's `docs/MVP_REVISED.md`. Highlights:

```
POST   /api/auth/register          Public
POST   /api/auth/login             Public
POST   /api/auth/refresh-token     Public
POST   /api/auth/logout            Public (revokes refresh token)
GET    /api/auth/me                Auth
PATCH  /api/auth/change-password   Auth

GET    /api/categories             Public
GET    /api/categories/tree        Public

GET    /api/products               Public (paginated search)
GET    /api/products/:id           Public (increments viewCount)
POST   /api/products               Seller
PATCH  /api/products/:id           Owner or admin
PATCH  /api/products/:id/status    Owner or admin
POST   /api/products/:id/favorite  Auth (toggle)
GET    /api/products/me/favorites  Auth

POST   /api/orders                 Auth (buyer)
GET    /api/orders/:id             Auth (participant)
PATCH  /api/orders/:id/status      Auth (role-scoped transitions)
GET    /api/buyer/orders           Auth
GET    /api/seller/orders          Auth

POST   /api/payments/create-intent Auth (buyer)
POST   /api/payments/webhook/stripe Stripe (signature-verified)

POST   /api/reviews                Auth (buyer, post-completion only)
GET    /api/products/:id/reviews   Public

POST   /api/conversations          Auth
GET    /api/conversations          Auth
GET    /api/conversations/:id      Auth (participant)
GET    /api/conversations/:id/messages Auth
POST   /api/conversations/:id/messages Auth

GET    /api/admin/dashboard        Admin/moderator/support
GET    /api/admin/users            Admin
PATCH  /api/admin/users/:id/status Admin
PATCH  /api/admin/products/:id/moderate Admin/moderator
```

## Deploying (later)

- **Runtime**: any Node 20 host — Render, Railway, Fly.io, or a `Dockerfile` on ECS/Cloud Run
- **DB**: Neon / Supabase / RDS Postgres — set `DATABASE_URL` and run `npm run prisma:migrate:deploy`
- **Redis**: Upstash / ElastiCache
- **CI**: `.github/workflows/api.yml` — `npm ci && npm run typecheck && npm test && npm run prisma:generate`
- **Sockets behind a load balancer**: enable sticky sessions **and** keep the Redis adapter enabled

## Next things I'd build

1. **BullMQ queue + workers** for FCM push, email, SMS, and delayed payouts (`src/jobs/`)
2. **Cloudinary signed-upload endpoint** (`POST /api/uploads/signature`)
3. **OAuth**: Google + Apple, using existing user records
4. **Dispute controller + admin resolution flow** (schema is ready)
5. **Meilisearch indexing worker** — sync products on create/update

---

## Sandbox note

If you're pulling this from the Arena sandbox: `npm install` and `docker compose up` need normal internet access, which the sandbox restricts. Clone locally and everything works.
