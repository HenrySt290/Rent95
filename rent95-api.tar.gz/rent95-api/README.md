# Rent95 API 🛠️

**Node.js + Express + TypeScript + Prisma + Postgres backend** for the Rent95 marketplace mobile app.

Companion to [`HenrySt290/Rent95`](https://github.com/HenrySt290/Rent95) — flip the Flutter app's `USE_MOCKS=false` and point it at this API.

---

## What's implemented

- ✅ **Auth**: register / login / refresh / logout / me / change-password — Argon2 password hashing, JWT access + rotating refresh tokens stored as SHA-256 hashes
- ✅ **Users**: profiles, role-based auth (buyer/seller/admin/moderator/support), account status (active/suspended/banned)
- ✅ **Categories**: listing + tree endpoints
- ✅ **Products/listings**: search (keyword/category/price/city/type/sort), get by id, create (seller-only), update, pause/archive, favorites toggle
- ✅ **Orders**: create with server-side price math, seller accept/reject, status transitions, buyer/seller order lists, **overlap prevention via `SERIALIZABLE` transaction**
- ✅ **Payments**: Stripe Connect Express — `PaymentIntent` with `capture_method: 'manual'` for escrow, `application_fee_amount` for platform take, `transfer_data.destination` for seller payout, webhook handler with signature verification
- ✅ **Escrow**: funds held until order completes, then captured + marked released
- ✅ **Reviews**: buyer-only post-completion, one-per-order, product rating auto-recomputed in a transaction
- ✅ **Messaging**: conversations + messages REST + **Socket.io** with JWT auth, Redis adapter for horizontal scale, typing indicators, read receipts, order/user/conversation rooms
- ✅ **Admin**: dashboard metrics, user list, moderate listings (approve/reject with reason), suspend/activate/ban users
- ✅ **Security**: Helmet, CORS allowlist, rate limits (global + auth + OTP), Zod validation on every input, typed error middleware, idempotency keys on payments, webhooks signature-verified

## What's stubbed / deferred

- Google/Apple OAuth (endpoints reserved, implementation left for you to plug in with `google-auth-library` + `apple-signin-auth`)
- Phone OTP send/verify (route reserved, needs Twilio/MSG91 credentials)
- KYC document upload (Stripe Identity handoff recommended per revised MVP)
- Cloudinary/S3 signed upload URL endpoint (add when your storage bucket is ready)
- Razorpay (India launch — v1.1)
- FCM push worker (Redis queue skeleton exists in `sockets/`; add a BullMQ worker + Firebase Admin SDK in `src/jobs/push.ts`)
- Search re-indexing to Meilisearch (Postgres full-text works fine for MVP)

Every one of these has a clear seam in the code.

---

## Prerequisites

- Node.js **≥ 20**
- Docker + Docker Compose (to run Postgres + Redis locally)
- npm (or pnpm/yarn — pick one and stick to it)

---

## Getting started

```bash
# 1. Install dependencies
npm install

# 2. Copy env template
cp .env.example .env
# then edit .env — the defaults work with the docker-compose file below

# 3. Start Postgres + Redis
docker compose up -d

# 4. Run migrations + seed
npm run prisma:migrate       # creates the schema, name it e.g. "init"
npm run db:seed              # inserts admin user, categories, sample listings

# 5. Run in dev (hot reload)
npm run dev
```

You should see:
```
🚀 Rent95 API listening on http://localhost:4000
```

### Quick sanity check

```bash
# health
curl http://localhost:4000/health

# search listings (public)
curl 'http://localhost:4000/api/products?keyword=tesla'

# categories
curl http://localhost:4000/api/categories

# login (returns accessToken + refreshToken)
curl -X POST http://localhost:4000/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"alex@example.com","password":"demo1234"}'
```

---

## Connecting the Flutter app

In the mobile repo run:

```bash
flutter run \
  --dart-define=USE_MOCKS=false \
  --dart-define=API_BASE_URL=http://localhost:4000 \
  --dart-define=SOCKET_URL=http://localhost:4000
```

On an Android emulator, replace `localhost` with `10.0.2.2`. On a physical device, use your machine's LAN IP.

---

## Project layout

```
src/
├── config/           # env, logger, prisma, redis singletons
├── middleware/       # auth, validate, rate-limit, error handler
├── controllers/      # thin HTTP layer, one file per domain
├── services/         # business logic (auth, product, order, payment)
├── routes/           # Express routers, one per domain
├── validators/       # Zod schemas
├── sockets/          # Socket.io setup + event handlers
├── utils/            # errors, crypto, slug, response helpers
├── jobs/             # background workers (BullMQ) — placeholder
├── app.ts            # Express app factory
└── server.ts         # HTTP + Socket bootstrap

prisma/
├── schema.prisma     # single source of truth for DB
└── seed.ts           # deterministic seed data

tests/
└── utils.test.ts     # Vitest — expand as needed
```

## Commands

| Command | Purpose |
|---|---|
| `npm run dev` | Hot-reload development server via `tsx` |
| `npm run build` | Compile to `dist/` |
| `npm start` | Run compiled server |
| `npm run typecheck` | TypeScript check without emit |
| `npm run lint` | ESLint |
| `npm test` | Vitest — both unit and integration |
| `npm run test:unit` | Fast tests, no DB needed |
| `npm run test:integration` | Full-stack tests against a real Postgres |
| `npm run prisma:migrate` | Create a new dev migration |
| `npm run prisma:studio` | Web GUI for the DB |
| `npm run db:seed` | Seed sample data |
| `npm run db:reset` | Drop, migrate, seed (destroys data) |

## Testing

Two flavours:

### Unit — `tests/unit/`
Pure logic, no I/O. Run instantly, no DB needed:
```bash
npm run test:unit
```

### Integration — `tests/integration/`
Boots the full Express app in-process via `supertest`, hits real endpoints,
and asserts against real Prisma reads. Every test file gets a truncated
database via `TRUNCATE … RESTART IDENTITY CASCADE`, so tests are
order-independent.

**One-time setup:**
```bash
# Spin up an isolated Postgres on port 5433 (RAM-backed for speed).
docker compose -f docker-compose.test.yml up -d

# Push the schema.
DATABASE_URL='postgresql://rent95:rent95@localhost:5433/rent95_test?schema=public' \
  npx prisma db push --skip-generate
```

**Then run:**
```bash
npm run test:integration
```

**What's covered** (7 test files, ~50 assertions):

- `auth.test.ts` — register hashes with Argon2; login returns tokens; refresh
  rotates + revokes old; `/me` guards; unknown refresh 401s; duplicate email 409.
- `products.test.ts` — search filters (category / price / sort); pagination
  envelope; getById increments `viewCount`; create as seller vs. buyer; 422s.
- `orders.test.ts` — server-side price math (subtotal + fee + tax + deposit);
  seller-can't-book-self; **overlap prevention with a busy accepted booking**;
  non-overlapping second booking succeeds; end-before-start rejected;
  quantity > inventory rejected; only-seller-can-accept; illegal transitions.
- `reviews.test.ts` — post-completion only; one-per-order; product rating
  recomputes as a running average on new reviews; buyer-only.
- `messaging.test.ts` — create + reuse conversation; self-message rejected;
  list-scoped-to-participants; outsiders 403; message validation.
- `admin.test.ts` — dashboard metrics; role gating; approve/reject listings
  with a reason; suspend + reactivate users.
- `categories.test.ts` — /api/categories filter + sort; /api/categories/tree
  parent → children shape; /health smoke; JSON 404 handler.

**Notes for CI**
- `.github/workflows/ci.yml` boots a Postgres service on port 5433, runs
  `prisma db push` (faster than `migrate deploy` in CI), then unit + integration.
- Set `FORCE_DB_RESET=1` locally if you're actively editing `prisma/schema.prisma`
  and want a fresh migrate on every test run.
- Vitest is configured with `pool: 'forks'` + `singleFork: true` — integration
  tests share a Postgres, so parallel runs would race on the truncate.

## API surface (all under `/api`)

Matches the endpoints listed in the mobile repo's `docs/MVP_REVISED.md`. Highlights:

```
POST   /api/auth/register          Public
POST   /api/auth/login             Public
POST   /api/auth/refresh-token     Public
POST   /api/auth/logout            Public (revokes refresh token)
GET    /api/auth/me                Auth
PATCH  /api/auth/change-password   Auth

GET    /api/categories             Public
GET    /api/categories/tree        Public

GET    /api/products               Public (paginated search)
GET    /api/products/:id           Public (increments viewCount)
POST   /api/products               Seller
PATCH  /api/products/:id           Owner or admin
PATCH  /api/products/:id/status    Owner or admin
POST   /api/products/:id/favorite  Auth (toggle)
GET    /api/products/me/favorites  Auth

POST   /api/orders                 Auth (buyer)
GET    /api/orders/:id             Auth (participant)
PATCH  /api/orders/:id/status      Auth (role-scoped transitions)
GET    /api/buyer/orders           Auth
GET    /api/seller/orders          Auth

POST   /api/payments/create-intent Auth (buyer)
POST   /api/payments/webhook/stripe Stripe (signature-verified)

POST   /api/reviews                Auth (buyer, post-completion only)
GET    /api/products/:id/reviews   Public

POST   /api/conversations          Auth
GET    /api/conversations          Auth
GET    /api/conversations/:id      Auth (participant)
GET    /api/conversations/:id/messages Auth
POST   /api/conversations/:id/messages Auth

GET    /api/admin/dashboard        Admin/moderator/support
GET    /api/admin/users            Admin/moderator/support
PATCH  /api/admin/users/:id/status Admin only
GET    /api/admin/products         Admin/moderator/support (moderation queue)
PATCH  /api/admin/products/:id/moderate Admin/moderator
GET    /api/admin/orders           Admin/moderator/support (paginated, filterable)
GET    /api/admin/payments         Admin only (financial data)
GET    /api/admin/disputes         Admin/moderator/support
PATCH  /api/admin/disputes/:id/resolve Admin/moderator (refund_buyer | release_seller | partial_refund | reject)
```

## Deploying (later)

- **Runtime**: any Node 20 host — Render, Railway, Fly.io, or a `Dockerfile` on ECS/Cloud Run
- **DB**: Neon / Supabase / RDS Postgres — set `DATABASE_URL` and run `npm run prisma:migrate:deploy`
- **Redis**: Upstash / ElastiCache
- **CI**: `.github/workflows/api.yml` — `npm ci && npm run typecheck && npm test && npm run prisma:generate`
- **Sockets behind a load balancer**: enable sticky sessions **and** keep the Redis adapter enabled

## Next things I'd build

1. **BullMQ queue + workers** for FCM push, email, SMS, and delayed payouts (`src/jobs/`)
2. **Cloudinary signed-upload endpoint** (`POST /api/uploads/signature`)
3. **OAuth**: Google + Apple, using existing user records
4. **Dispute controller + admin resolution flow** (schema is ready)
5. **Meilisearch indexing worker** — sync products on create/update

---

## Sandbox note

If you're pulling this from the Arena sandbox: `npm install` and `docker compose up` need normal internet access, which the sandbox restricts. Clone locally and everything works.
