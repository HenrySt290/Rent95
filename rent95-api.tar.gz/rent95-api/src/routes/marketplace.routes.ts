import { Router } from 'express';
import * as order from '../controllers/order.controller';
import * as payment from '../controllers/payment.controller';
import * as review from '../controllers/review.controller';
import * as marketplace from '../controllers/marketplace.controller';
import { requireAuth } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { idempotency } from '../middleware/idempotency';
import {
  createConversationSchema,
  createOrderSchema,
  createReviewSchema,
  orderStatusSchema,
  sendMessageSchema,
} from '../validators/marketplace.validators';
import { idParamSchema } from '../validators/product.validators';

const router: Router = Router();

// Orders
router.post('/orders', requireAuth, idempotency(), validate({ body: createOrderSchema }), order.create);
router.get('/orders/:id', requireAuth, validate({ params: idParamSchema }), order.get);
router.patch('/orders/:id/status', requireAuth, validate({ params: idParamSchema, body: orderStatusSchema }), order.updateStatus);
router.get('/buyer/orders', requireAuth, order.myBuyerOrders);
router.get('/seller/orders', requireAuth, order.mySellerOrders);

// Payments
router.post('/payments/create-intent', requireAuth, idempotency(), payment.createIntent);
// Note: Stripe webhook is mounted separately in server.ts with raw body parser.

// Reviews
router.post('/reviews', requireAuth, validate({ body: createReviewSchema }), review.createReview);
router.get('/products/:id/reviews', validate({ params: idParamSchema }), review.listForProduct);

// Messaging
router.post('/conversations', requireAuth, validate({ body: createConversationSchema }), marketplace.createConversation);
router.get('/conversations', requireAuth, marketplace.listConversations);
router.get('/conversations/:id', requireAuth, validate({ params: idParamSchema }), marketplace.getConversation);
router.get('/conversations/:id/messages', requireAuth, validate({ params: idParamSchema }), marketplace.listMessages);
router.post('/conversations/:id/messages', requireAuth, validate({ params: idParamSchema, body: sendMessageSchema }), marketplace.sendMessage);

export default router;
