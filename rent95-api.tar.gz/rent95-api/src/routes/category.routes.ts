import { Router } from 'express';
import * as marketplace from '../controllers/marketplace.controller';

const router: Router = Router();

router.get('/', marketplace.listCategories);
router.get('/tree', marketplace.categoryTree);

export default router;
