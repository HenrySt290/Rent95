import { Router } from 'express';
import * as notification from '../controllers/notification.controller';
import { requireAuth } from '../middleware/auth';

/**
 * Notification inbox — matches the mobile app's `NotificationRepository`
 * shape exactly. Every endpoint requires auth and scopes to the caller.
 */
const router: Router = Router();

router.get('/', requireAuth, notification.list);
router.patch('/read-all', requireAuth, notification.markAllRead);
router.patch('/:id/read', requireAuth, notification.markRead);
router.delete('/:id', requireAuth, notification.remove);

export default router;
