import { Router } from 'express';
import * as auth from '../controllers/auth.controller';
import { authLimiter } from '../middleware/rate-limit';
import { requireAuth } from '../middleware/auth';
import { validate } from '../middleware/validate';
import {
  changePasswordSchema,
  loginSchema,
  refreshSchema,
  registerSchema,
} from '../validators/auth.validators';

const router: Router = Router();

router.post('/register', authLimiter, validate({ body: registerSchema }), auth.register);
router.post('/login', authLimiter, validate({ body: loginSchema }), auth.login);
router.post('/refresh-token', validate({ body: refreshSchema }), auth.refresh);
router.post('/logout', validate({ body: refreshSchema }), auth.logout);
router.get('/me', requireAuth, auth.me);
router.patch('/change-password', requireAuth, validate({ body: changePasswordSchema }), auth.changePassword);

export default router;
