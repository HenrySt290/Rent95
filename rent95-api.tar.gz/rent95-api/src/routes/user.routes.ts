import { Router } from 'express';
import * as deviceTokenController from '../controllers/device-token.controller';
import { requireAuth } from '../middleware/auth';

const router: Router = Router();

// FCM device tokens — see mobile app's PushRegistrar.
router.post('/device-token', requireAuth, deviceTokenController.register);
router.delete('/device-token', requireAuth, deviceTokenController.revoke);

export default router;

