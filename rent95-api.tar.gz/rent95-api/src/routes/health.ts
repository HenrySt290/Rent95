import type { Request, Response } from 'express';
import { prisma } from '../config/prisma';

/**
 * Two-tier health check.
 *
 *   GET /health            — cheap liveness check for load balancers.
 *                            Just proves the process is up.
 *
 *   GET /health?deep=1     — deep check. Pings Postgres. Used by the
 *                            deploy pipeline to gate rolling upgrades so
 *                            a machine with a dead DB pool never gets
 *                            promoted to serve traffic.
 *
 * The deep check is separated because doing a DB round-trip on every
 * load-balancer ping (which happens every few seconds per machine) would
 * generate a lot of pointless queries.
 */
export async function health(req: Request, res: Response) {
  const shallow = req.query.deep !== '1';

  if (shallow) {
    return res.json({ status: 'ok', ts: new Date().toISOString() });
  }

  const checks: Record<string, 'ok' | { error: string }> = { server: 'ok' };
  let overall: 'ok' | 'degraded' = 'ok';

  try {
    await prisma.$queryRawUnsafe('SELECT 1');
    checks.database = 'ok';
  } catch (e) {
    checks.database = { error: e instanceof Error ? e.message : String(e) };
    overall = 'degraded';
  }

  return res.status(overall === 'ok' ? 200 : 503).json({
    status: overall,
    ts: new Date().toISOString(),
    checks,
  });
}
