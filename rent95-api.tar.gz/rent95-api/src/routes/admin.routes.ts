import { Router } from 'express';
import * as admin from '../controllers/admin.controller';
import { requireAuth, requireRole } from '../middleware/auth';

const router: Router = Router();

router.use(requireAuth, requireRole('admin', 'moderator', 'support'));

router.get('/dashboard', admin.dashboardMetrics);
router.get('/users', admin.listUsers);
router.patch('/users/:id/status', admin.suspendUser);
router.patch('/products/:id/moderate', admin.moderateListing);

export default router;
