import { Router } from 'express';
import * as admin from '../controllers/admin.controller';
import { requireAuth, requireRole } from '../middleware/auth';

const router: Router = Router();

// All admin routes require auth + one of the three staff roles at a minimum.
// Individual write endpoints tighten this further via `requireRole('admin')`
// or `requireRole('admin', 'moderator')` — see the capability matrix in
// rent95-admin/lib/session.ts for the canonical policy.
router.use(requireAuth, requireRole('admin', 'moderator', 'support'));

// -- Dashboard ---------------------------------------------------------------

router.get('/dashboard', admin.dashboardMetrics);

// -- Users -------------------------------------------------------------------

router.get('/users', admin.listUsers);
// Only admins can suspend/ban — matches the panel's capability matrix.
router.patch('/users/:id/status', requireRole('admin'), admin.suspendUser);

// -- Products / moderation ---------------------------------------------------

router.get('/products', admin.listAdminProducts);
router.patch('/products/:id/moderate', requireRole('admin', 'moderator'), admin.moderateListing);

// -- Orders ------------------------------------------------------------------

router.get('/orders', admin.listAdminOrders);

// -- Payments ----------------------------------------------------------------

// Financial data — admins only. Moderators and support don't see it.
router.get('/payments', requireRole('admin'), admin.listAdminPayments);

// -- Disputes ----------------------------------------------------------------

router.get('/disputes', admin.listAdminDisputes);
router.patch('/disputes/:id/resolve', requireRole('admin', 'moderator'), admin.resolveDispute);

export default router;
