import { Router } from 'express';
import * as product from '../controllers/product.controller';
import { optionalAuth, requireAuth, requireRole } from '../middleware/auth';
import { validate } from '../middleware/validate';
import {
  createProductSchema,
  idParamSchema,
  productSearchSchema,
  updateProductSchema,
} from '../validators/product.validators';

const router: Router = Router();

router.get('/', optionalAuth, validate({ query: productSearchSchema }), product.search);
router.get('/:id', optionalAuth, validate({ params: idParamSchema }), product.getById);

router.post(
  '/',
  requireAuth,
  requireRole('seller', 'admin'),
  validate({ body: createProductSchema }),
  product.create,
);

router.patch(
  '/:id',
  requireAuth,
  validate({ params: idParamSchema, body: updateProductSchema }),
  product.update,
);

router.patch('/:id/status', requireAuth, product.setStatus);

router.post('/:productId/favorite', requireAuth, product.toggleFavorite);
router.get('/me/favorites', requireAuth, product.listFavorites);

export default router;
