import { PrismaClient } from '@prisma/client';
import { isProd } from './env';

// Singleton Prisma client so we don't exhaust connections in dev/HMR.
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: isProd ? ['error'] : ['warn', 'error'],
  });

if (!isProd) globalForPrisma.prisma = prisma;
