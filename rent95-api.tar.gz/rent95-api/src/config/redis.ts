import Redis from 'ioredis';
import { env } from './env';
import { logger } from './logger';

let _redis: Redis | null = null;

export function getRedis(): Redis {
  if (_redis) return _redis;
  _redis = new Redis(env.REDIS_URL, {
    lazyConnect: false,
    maxRetriesPerRequest: 3,
    enableReadyCheck: true,
  });
  _redis.on('error', (err) => logger.error({ err }, 'Redis error'));
  _redis.on('connect', () => logger.info('Redis connected'));
  return _redis;
}
