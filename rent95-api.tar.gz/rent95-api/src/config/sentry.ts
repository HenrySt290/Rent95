/**
 * Sentry integration — optional.
 *
 * Enabled when `SENTRY_DSN` is set in the environment. Otherwise every
 * function here is a friendly no-op so local dev never depends on the
 * `@sentry/node` package being installed.
 *
 * To enable in production:
 *   1. `npm install @sentry/node`
 *   2. Set `SENTRY_DSN` on Fly / Render.
 *
 * Sentry receives **only sanitised events**: we install a `beforeSend`
 * hook that redacts request bodies, headers, and cookies before the
 * event ever leaves the process. This mirrors the pino redaction paths
 * in `log-redaction.ts`.
 */

import { REDACT_PATTERNS } from './log-redaction';

let _sentry: {
  init: (opts: Record<string, unknown>) => void;
  captureException: (err: unknown) => void;
} | null = null;

export function initSentry(): void {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) return;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports, @typescript-eslint/no-var-requires
    _sentry = require('@sentry/node');
    _sentry!.init({
      dsn,
      environment: process.env.NODE_ENV,
      tracesSampleRate: 0.1,
      // -- Redact request body, headers, and query --------------------------
      sendDefaultPii: false,
      integrations: [],
      beforeSend(event: SentryEventShape) {
        return _scrubEvent(event);
      },
      beforeBreadcrumb(breadcrumb: SentryBreadcrumbShape) {
        if (breadcrumb.data) breadcrumb.data = _scrubObject(breadcrumb.data);
        if (breadcrumb.message) {
          breadcrumb.message = _scrubString(breadcrumb.message);
        }
        return breadcrumb;
      },
    });
  } catch {
    // @sentry/node not installed — silent no-op.
  }
}

export function captureException(err: unknown): void {
  _sentry?.captureException(err);
}

// -----------------------------------------------------------------------------
// Sanitisation
//
// We duplicate a small amount of key-matching logic here instead of importing
// pino's redact — @sentry/node doesn't ship pino, and the shapes are
// different. Keeping both scrubbers close in `log-redaction.ts` prevents
// drift.
// -----------------------------------------------------------------------------

// Minimal shapes; we don't want a hard dependency on @sentry/node types
// because it's dynamic-required at runtime.
type SentryEventShape = {
  request?: {
    data?: unknown;
    headers?: Record<string, string>;
    cookies?: Record<string, string> | string;
    query_string?: unknown;
  };
  extra?: Record<string, unknown>;
  contexts?: Record<string, Record<string, unknown>>;
  breadcrumbs?: SentryBreadcrumbShape[];
  message?: string;
  exception?: {
    values?: Array<{
      type?: string;
      value?: string;
      stacktrace?: {
        frames?: Array<{
          vars?: Record<string, unknown>;
          pre_context?: string[];
          context_line?: string;
          post_context?: string[];
        }>;
      };
    }>;
  };
  user?: Record<string, unknown>;
  tags?: Record<string, string>;
};

type SentryBreadcrumbShape = {
  message?: string;
  data?: Record<string, unknown>;
};

// Broadened key matcher (was too narrow — missed `sessionId`, `stripeKey`, etc.)
const SENSITIVE_KEY_RE =
  /pass|token|secret|session|api[_-]?key|otp|pin|cvv|cvc|authorization|cookie|card[_-]?number|stripe|private|refresh|access|magic|totp|mfa/i;

/**
 * Depth-limited recursive scrubber. The depth cap is important: Sentry
 * events can carry cycles (via `contexts.state`), and unbounded recursion
 * would DoS ourselves. Depth 6 is more than enough for real error shapes.
 */
const MAX_DEPTH = 6;

function _scrubEvent(event: SentryEventShape): SentryEventShape {
  if (event.request) {
    if (event.request.data) event.request.data = _scrubObject(event.request.data);
    if (event.request.headers) event.request.headers = _scrubHeaders(event.request.headers);
    if (event.request.query_string) {
      // Query strings sometimes carry `?token=…` on OAuth callbacks.
      event.request.query_string =
        typeof event.request.query_string === 'string'
          ? _scrubString(event.request.query_string)
          : _scrubObject(event.request.query_string);
    }
    // Cookies always go — no admin ever needs to see the auth cookie in a
    // stack trace.
    event.request.cookies = '[REDACTED]';
  }
  if (event.extra) event.extra = _scrubObject(event.extra) as Record<string, unknown>;
  if (event.contexts) {
    for (const k of Object.keys(event.contexts)) {
      event.contexts[k] = _scrubObject(event.contexts[k]) as Record<string, unknown>;
    }
  }
  // Exception frames may include local variables via `vars` (integrations
  // like `@sentry/node` `LocalVariables` will attach these). This is the
  // canonical leak vector for plain-text passwords: they land in the
  // `login` function's local scope. Scrub every frame.
  if (event.exception?.values) {
    for (const ex of event.exception.values) {
      if (ex.value) ex.value = _scrubString(ex.value);
      if (ex.stacktrace?.frames) {
        for (const frame of ex.stacktrace.frames) {
          if (frame.vars) {
            frame.vars = _scrubObject(frame.vars) as Record<string, unknown>;
          }
          // Source context lines can contain literal strings from the
          // codebase — usually safe, but if someone hard-coded a secret
          // in a comment we'd rather redact than leak.
          if (frame.context_line) frame.context_line = _scrubString(frame.context_line);
          if (frame.pre_context) frame.pre_context = frame.pre_context.map(_scrubString);
          if (frame.post_context) frame.post_context = frame.post_context.map(_scrubString);
        }
      }
    }
  }
  if (event.message) event.message = _scrubString(event.message);
  // Never send our own user PII outside {id}. Sentry defaults are usually
  // safe but be defensive if an integration re-enables `sendDefaultPii`.
  if (event.user) {
    event.user = {
      id: typeof event.user.id === 'string' ? event.user.id : undefined,
      // No email, ip_address, username, or arbitrary keys.
    };
  }
  if (event.breadcrumbs) {
    for (const bc of event.breadcrumbs) {
      if (bc.data) bc.data = _scrubObject(bc.data) as Record<string, unknown>;
      if (bc.message) bc.message = _scrubString(bc.message);
    }
  }
  return event;
}

function _scrubObject(input: unknown, depth = 0): unknown {
  if (input == null) return input;
  if (depth > MAX_DEPTH) return '[REDACTED_DEPTH]';
  if (typeof input === 'string') return _scrubString(input);
  if (Array.isArray(input)) {
    // Cap array length to avoid pathological payloads.
    return input.slice(0, 200).map((v) => _scrubObject(v, depth + 1));
  }
  if (typeof input !== 'object') return input;

  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(input as Record<string, unknown>)) {
    if (SENSITIVE_KEY_RE.test(k)) {
      out[k] = '[REDACTED]';
    } else {
      out[k] = _scrubObject(v, depth + 1);
    }
  }
  return out;
}

function _scrubHeaders(headers: Record<string, string>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(headers)) {
    if (SENSITIVE_KEY_RE.test(k)) {
      out[k] = '[REDACTED]';
    } else {
      out[k] = _scrubString(v);
    }
  }
  return out;
}

function _scrubString(s: string): string {
  let out = s;
  for (const re of REDACT_PATTERNS) {
    out = out.replace(re, '[REDACTED]');
  }
  return out;
}
