/**
 * Sentry integration — optional.
 *
 * Enabled when `SENTRY_DSN` is set in the environment. Otherwise every
 * function here is a friendly no-op so local dev never depends on the
 * `@sentry/node` package being installed.
 *
 * To enable in production:
 *   1. `npm install @sentry/node`
 *   2. Uncomment the require() below.
 *   3. Set `SENTRY_DSN` on Fly / Render.
 *
 * We keep the require dynamic so the base image doesn't need to include
 * Sentry when it's off — one fewer transitive dependency to audit.
 */

let _sentry: {
  init: (opts: Record<string, unknown>) => void;
  captureException: (err: unknown) => void;
  Handlers?: {
    requestHandler: () => unknown;
    errorHandler: () => unknown;
  };
} | null = null;

export function initSentry(): void {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) return;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports, @typescript-eslint/no-var-requires
    _sentry = require('@sentry/node');
    _sentry!.init({
      dsn,
      environment: process.env.NODE_ENV,
      tracesSampleRate: 0.1,
      // Server errors get grouped by controller.function.
      integrations: [],
    });
  } catch {
    // @sentry/node not installed — silent no-op.
  }
}

export function captureException(err: unknown): void {
  _sentry?.captureException(err);
}
