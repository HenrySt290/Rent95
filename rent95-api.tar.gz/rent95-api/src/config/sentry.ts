/**
 * Sentry integration — optional.
 *
 * Enabled when `SENTRY_DSN` is set in the environment. Otherwise every
 * function here is a friendly no-op so local dev never depends on the
 * `@sentry/node` package being installed.
 *
 * To enable in production:
 *   1. `npm install @sentry/node`
 *   2. Set `SENTRY_DSN` on Fly / Render.
 *
 * Sentry receives **only sanitised events**: we install a `beforeSend`
 * hook that redacts request bodies, headers, and cookies before the
 * event ever leaves the process. This mirrors the pino redaction paths
 * in `log-redaction.ts`.
 */

import { REDACT_PATTERNS } from './log-redaction';

let _sentry: {
  init: (opts: Record<string, unknown>) => void;
  captureException: (err: unknown) => void;
} | null = null;

export function initSentry(): void {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) return;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports, @typescript-eslint/no-var-requires
    _sentry = require('@sentry/node');
    _sentry!.init({
      dsn,
      environment: process.env.NODE_ENV,
      tracesSampleRate: 0.1,
      // -- Redact request body, headers, and query --------------------------
      sendDefaultPii: false,
      integrations: [],
      beforeSend(event: SentryEventShape) {
        return _scrubEvent(event);
      },
      beforeBreadcrumb(breadcrumb: SentryBreadcrumbShape) {
        if (breadcrumb.data) breadcrumb.data = _scrubObject(breadcrumb.data);
        if (breadcrumb.message) {
          breadcrumb.message = _scrubString(breadcrumb.message);
        }
        return breadcrumb;
      },
    });
  } catch {
    // @sentry/node not installed — silent no-op.
  }
}

export function captureException(err: unknown): void {
  _sentry?.captureException(err);
}

// -----------------------------------------------------------------------------
// Sanitisation
//
// We duplicate a small amount of key-matching logic here instead of importing
// pino's redact — @sentry/node doesn't ship pino, and the shapes are
// different. Keeping both scrubbers close in `log-redaction.ts` prevents
// drift.
// -----------------------------------------------------------------------------

// Minimal shapes; we don't want a hard dependency on @sentry/node types
// because it's dynamic-required at runtime.
type SentryEventShape = {
  request?: {
    data?: unknown;
    headers?: Record<string, string>;
    cookies?: Record<string, string> | string;
    query_string?: unknown;
  };
  extra?: Record<string, unknown>;
  contexts?: Record<string, Record<string, unknown>>;
  breadcrumbs?: SentryBreadcrumbShape[];
  message?: string;
};

type SentryBreadcrumbShape = {
  message?: string;
  data?: Record<string, unknown>;
};

const SENSITIVE_KEY_RE =
  /pass|token|secret|api[_-]?key|otp|pin|cvv|cvc|authorization|cookie|card[_-]?number/i;

function _scrubEvent(event: SentryEventShape): SentryEventShape {
  if (event.request) {
    if (event.request.data) event.request.data = _scrubObject(event.request.data);
    if (event.request.headers) event.request.headers = _scrubHeaders(event.request.headers);
    // Cookies always go — no admin ever needs to see the auth cookie in a
    // stack trace.
    event.request.cookies = '[REDACTED]';
  }
  if (event.extra) event.extra = _scrubObject(event.extra) as Record<string, unknown>;
  if (event.contexts) {
    for (const k of Object.keys(event.contexts)) {
      event.contexts[k] = _scrubObject(event.contexts[k]) as Record<string, unknown>;
    }
  }
  if (event.message) event.message = _scrubString(event.message);
  return event;
}

function _scrubObject(input: unknown): unknown {
  if (input == null) return input;
  if (typeof input === 'string') return _scrubString(input);
  if (Array.isArray(input)) return input.map(_scrubObject);
  if (typeof input !== 'object') return input;

  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(input as Record<string, unknown>)) {
    if (SENSITIVE_KEY_RE.test(k)) {
      out[k] = '[REDACTED]';
    } else {
      out[k] = _scrubObject(v);
    }
  }
  return out;
}

function _scrubHeaders(headers: Record<string, string>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(headers)) {
    if (SENSITIVE_KEY_RE.test(k)) {
      out[k] = '[REDACTED]';
    } else {
      out[k] = _scrubString(v);
    }
  }
  return out;
}

function _scrubString(s: string): string {
  let out = s;
  for (const re of REDACT_PATTERNS) {
    out = out.replace(re, '[REDACTED]');
  }
  return out;
}
