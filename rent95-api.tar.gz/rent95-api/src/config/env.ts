import dotenv from 'dotenv';
import { z } from 'zod';

dotenv.config();

/**
 * Environment schema — split into a permissive dev schema and a strict
 * prod schema. Values fields marked `.optional()` in dev must be
 * `.min(1)` in prod, so a missing critical secret triggers an immediate
 * process exit at boot instead of a mysterious 500 the first time it's
 * used.
 *
 * Adding a new required-in-prod secret:
 *   1. Add it to `baseSchema` as `.optional()` so dev/test still boot.
 *   2. Extend `prodOverrides` to mark it required with the right shape.
 *   3. Add a comment above pointing at the code path that reads it.
 */

const baseSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().default(4000),
  LOG_LEVEL: z.string().default('info'),

  // CORS is DEV-defaulting to empty; prod overrides below force at least
  // one allowlisted origin so we can never boot with a "reflect any origin"
  // config.
  CORS_ORIGINS: z.string().default(''),

  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().default('redis://localhost:6379'),

  // JWT secrets — 32 bytes minimum for HMAC-SHA256. openssl rand -hex 32.
  // Note: 32 hex chars = 16 bytes = 128 bits. We want 32 BYTES → 64 hex.
  JWT_ACCESS_SECRET: z.string().min(32, 'JWT_ACCESS_SECRET must be ≥32 chars (use `openssl rand -hex 32`)'),
  JWT_REFRESH_SECRET: z.string().min(32, 'JWT_REFRESH_SECRET must be ≥32 chars (use `openssl rand -hex 32`)'),
  ACCESS_TOKEN_EXPIRES_IN: z.string().default('15m'),
  REFRESH_TOKEN_EXPIRES_IN: z.string().default('30d'),

  // Stripe — required in prod, see prodOverrides.
  STRIPE_SECRET_KEY: z.string().optional(),
  STRIPE_WEBHOOK_SECRET: z.string().optional(),
  STRIPE_CONNECT_CLIENT_ID: z.string().optional(),
  PLATFORM_COMMISSION_PERCENT: z.coerce.number().default(10),

  STORAGE_PROVIDER: z.enum(['cloudinary', 's3']).default('cloudinary'),
  CLOUDINARY_CLOUD_NAME: z.string().optional(),
  CLOUDINARY_API_KEY: z.string().optional(),
  CLOUDINARY_API_SECRET: z.string().optional(),
  AWS_ACCESS_KEY_ID: z.string().optional(),
  AWS_SECRET_ACCESS_KEY: z.string().optional(),
  AWS_REGION: z.string().optional(),
  AWS_S3_BUCKET: z.string().optional(),

  FCM_SERVICE_ACCOUNT_JSON_BASE64: z.string().optional(),

  EMAIL_PROVIDER: z.string().default('sendgrid'),
  SENDGRID_API_KEY: z.string().optional(),
  EMAIL_FROM: z.string().default('Rent95 <noreply@rent95.dev>'),

  SMS_PROVIDER: z.string().default('twilio'),
  TWILIO_ACCOUNT_SID: z.string().optional(),
  TWILIO_AUTH_TOKEN: z.string().optional(),
  TWILIO_FROM: z.string().optional(),

  SENTRY_DSN: z.string().optional(),
});

/**
 * Production-only requirements. `.superRefine` gives us multi-field
 * validation with structured error paths — Zod's `.discriminatedUnion`
 * can't cleanly express "these fields all become required when
 * NODE_ENV=production".
 */
const schema = baseSchema.superRefine((data, ctx) => {
  if (data.NODE_ENV !== 'production') return;

  const requiredInProd: Array<{ key: keyof typeof data; hint: string }> = [
    { key: 'CORS_ORIGINS', hint: 'Comma-separated allowlist of exact origins. NEVER "*".' },
    { key: 'STRIPE_SECRET_KEY', hint: 'sk_live_… from Stripe dashboard.' },
    { key: 'STRIPE_WEBHOOK_SECRET', hint: 'whsec_… — copy from the webhook endpoint page.' },
    { key: 'CLOUDINARY_CLOUD_NAME', hint: 'Cloud name from dashboard.' },
    { key: 'CLOUDINARY_API_KEY', hint: 'API key from Cloudinary dashboard.' },
    { key: 'CLOUDINARY_API_SECRET', hint: 'Server-side only — never send to client.' },
  ];
  for (const { key, hint } of requiredInProd) {
    const value = data[key];
    if (value == null || String(value).trim().length === 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: [key],
        message: `Required in production. ${hint}`,
      });
    }
  }

  // CORS_ORIGINS must contain at least one absolute URL and never `*`.
  const originsRaw = data.CORS_ORIGINS ?? '';
  const origins = originsRaw.split(',').map((s) => s.trim()).filter(Boolean);
  if (origins.length === 0) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['CORS_ORIGINS'],
      message: 'Must be a non-empty comma-separated list of https:// origins in production.',
    });
  }
  for (const o of origins) {
    if (o === '*') {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['CORS_ORIGINS'],
        message: 'Wildcard "*" is not allowed. List each origin explicitly.',
      });
    }
    if (!o.startsWith('https://') && !o.startsWith('http://localhost')) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['CORS_ORIGINS'],
        message: `Origin "${o}" must use https:// in production.`,
      });
    }
  }

  // JWT secrets must not be equal. Rotating one but not the other is a
  // subtle failure mode we short-circuit here.
  if (data.JWT_ACCESS_SECRET === data.JWT_REFRESH_SECRET) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['JWT_REFRESH_SECRET'],
      message: 'JWT_ACCESS_SECRET and JWT_REFRESH_SECRET must be distinct random values.',
    });
  }
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  // eslint-disable-next-line no-console
  console.error(
    '\n❌ Invalid environment configuration.\n' +
      'The following variables are missing or malformed:\n',
  );
  for (const issue of parsed.error.issues) {
    // eslint-disable-next-line no-console
    console.error(`  • ${issue.path.join('.')}: ${issue.message}`);
  }
  // eslint-disable-next-line no-console
  console.error('\nRefusing to boot. Set the required values and try again.\n');
  process.exit(1);
}

export const env = parsed.data;

export const isProd = env.NODE_ENV === 'production';
export const isTest = env.NODE_ENV === 'test';
export const isDev = env.NODE_ENV === 'development';

export const corsOrigins = env.CORS_ORIGINS
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);
