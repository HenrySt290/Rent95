import pino from 'pino';
import { env, isProd } from './env';
import { REDACT_PATHS, scrubMessage } from './log-redaction';

/**
 * Structured logger with mandatory PII/secret redaction.
 *
 * Every field path in `REDACT_PATHS` is stripped from log output before
 * it reaches stdout, Sentry, or any downstream collector. Redaction
 * happens inside pino's fast path — see `getpino.io/#/docs/redaction`
 * for the O(1) traversal semantics.
 *
 * ────────────────────────────────────────────────────────────────────────
 *  Defense in depth (SRE audit item #4)
 * ────────────────────────────────────────────────────────────────────────
 *
 *  1. `redact.paths`     — enumerated fields (compile-time list).
 *  2. `serializers.err`  — every Error goes through a custom serializer
 *                          that drops `request`, `response.data`, `config`,
 *                          Prisma `meta`, and stack-line-scrubs the message.
 *  3. `formatters.log`   — final chance to string-scrub any value that
 *                          slipped through as a raw string.
 *
 * Adding a new sensitive field is a one-line change to `log-redaction.ts`.
 * When in doubt, redact — pino's censor short-circuits missing paths so
 * there's zero cost for over-listing.
 */
export const logger = pino({
  level: env.LOG_LEVEL,
  redact: {
    paths: [...REDACT_PATHS],
    censor: '[REDACTED]',
    remove: false, // Keep the key so the shape stays consistent for parsers.
  },
  // Never log the process cwd or hostname in structured output — they leak
  // deploy topology to Sentry / hosted log providers.
  base: {
    env: env.NODE_ENV,
    service: 'rent95-api',
  },
  serializers: {
    // Overrides pino's default `err` serializer. Ours drops the attachment
    // fields we can never confirm are safe (Axios / Dio bodies, Prisma
    // meta, HTTP config), and regex-scrubs the message + stack.
    err: (err: unknown) => {
      if (!(err instanceof Error)) return { value: String(err) };
      const anyErr = err as Error & Record<string, unknown>;
      return {
        type: err.name,
        message: scrubMessage(err.message || ''),
        stack: isProd ? undefined : scrubMessage(err.stack ?? ''),
        // Prisma error `code` is safe (P2002 etc.), but `meta` is NOT.
        // Sentry/pino may add these later; keep them if the field is
        // present, but never propagate `meta`, `request`, `config`,
        // or `response`.
        code:
          typeof anyErr.code === 'string' || typeof anyErr.code === 'number'
            ? anyErr.code
            : undefined,
        statusCode:
          typeof anyErr.statusCode === 'number' ? anyErr.statusCode : undefined,
      };
    },
  },
  formatters: {
    // Final belt-and-braces string scrubber. If some future code path logs
    // a plain string containing a secret, this catches it.
    log(obj) {
      if (obj && typeof obj === 'object') {
        if (typeof (obj as { msg?: unknown }).msg === 'string') {
          (obj as { msg: string }).msg = scrubMessage((obj as { msg: string }).msg);
        }
      }
      return obj as Record<string, unknown>;
    },
  },
  transport: isProd
    ? undefined
    : {
        target: 'pino-pretty',
        options: {
          colorize: true,
          singleLine: false,
          translateTime: 'HH:MM:ss.l',
          ignore: 'pid,hostname',
        },
      },
});
