import pino from 'pino';
import { env, isProd } from './env';
import { REDACT_PATHS } from './log-redaction';

/**
 * Structured logger with mandatory PII/secret redaction.
 *
 * Every field path in `REDACT_PATHS` is stripped from log output before
 * it reaches stdout, Sentry, or any downstream collector. Redaction
 * happens inside pino's fast path — see `getpino.io/#/docs/redaction`
 * for the O(1) traversal semantics.
 *
 * Adding a new sensitive field is a one-line change to `log-redaction.ts`.
 * When in doubt, redact — pino's censor short-circuits missing paths so
 * there's zero cost for over-listing.
 */
export const logger = pino({
  level: env.LOG_LEVEL,
  redact: {
    paths: [...REDACT_PATHS],
    censor: '[REDACTED]',
    remove: false, // Keep the key so the shape stays consistent for parsers.
  },
  // Never log the process cwd or hostname in structured output — they leak
  // deploy topology to Sentry / hosted log providers.
  base: {
    env: env.NODE_ENV,
    service: 'rent95-api',
  },
  transport: isProd
    ? undefined
    : {
        target: 'pino-pretty',
        options: {
          colorize: true,
          singleLine: false,
          translateTime: 'HH:MM:ss.l',
          ignore: 'pid,hostname',
        },
      },
});
