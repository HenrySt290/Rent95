/**
 * Sensitive-field redaction paths for pino's built-in redact option.
 *
 * pino's redact is faster than a general-purpose recursive scrubber
 * because it walks explicit paths — no schema inference at write time.
 * The trade-off is we must enumerate every place a secret might land.
 * The list below is deliberately over-broad: better to redact a harmless
 * field than to leak a secret.
 *
 * ────────────────────────────────────────────────────────────────────────
 *  Regulatory scope (SRE audit item #4)
 * ────────────────────────────────────────────────────────────────────────
 *
 * This matrix must be closed against every plausible leak vector, not
 * merely the "obvious" ones. In particular:
 *
 *   - Node's default error serializer prints `err.request.body` and
 *     `err.config.data` on axios / Dio-side errors. Both often contain
 *     the plaintext password from a `POST /auth/login` retry.
 *
 *   - Prisma throws `PrismaClientKnownRequestError` with `meta.target` +
 *     `meta.cause` on unique-constraint hits. On the user table, `target`
 *     is `["email"]` — harmless — but `cause` on some drivers echoes the
 *     conflicting row's data. Kill both.
 *
 *   - Zod's `error.flatten()` surfaces the input value under
 *     `fieldErrors.password[0]`. We redact every `password`/`otp`/`code`
 *     field at any depth using pino's `*.` glob.
 *
 *   - `__Host-rent95_admin_session` (Next.js admin panel) is a plaintext
 *     wire-format token. Any redaction gap that lets it into pino/Sentry
 *     is a session-hijack primitive. Regex-scrubbed unconditionally.
 *
 *   - Stripe secrets travel through many object shapes (config, error,
 *     retry log). We regex-match the key pattern rather than trusting
 *     any path enumeration.
 *
 * References:
 *   - pino redact docs:  https://getpino.io/#/docs/redaction
 *   - OWASP logging cheat sheet §"Data to exclude"
 *   - PCI-DSS 3.4 (do not log PAN); PSD2 SCA (do not log OTPs)
 */
export const REDACT_PATHS: readonly string[] = [
  // -- Direct secret fields (any nesting depth) ------------------------------
  '*.password',
  '*.Password',
  '*.newPassword',
  '*.currentPassword',
  '*.oldPassword',
  '*.passwordHash',
  '*.passphrase',
  '*.token',
  '*.accessToken',
  '*.refreshToken',
  '*.refresh_token',
  '*.access_token',
  '*.idToken',
  '*.id_token',
  '*.sessionToken',
  '*.session_token',
  '*.sessionId',
  '*.session_id',
  '*.apiKey',
  '*.api_key',
  '*.secret',
  '*.privateKey',
  '*.private_key',
  '*.client_secret',
  '*.clientSecret',
  '*.otp',
  '*.otpCode',
  '*.code',
  '*.pin',
  '*.cvv',
  '*.cvc',
  '*.cardNumber',
  '*.card_number',
  '*.iban',
  '*.ssn',
  '*.taxId',
  '*.tax_id',
  '*.phoneOtp',
  '*.emailOtp',
  '*.magic_link',
  '*.magicLink',
  '*.mfaCode',
  '*.mfa_code',
  '*.totpSecret',
  '*.totp_secret',

  // -- Admin panel session (AES-256-GCM wire format) -------------------------
  '*.__Host-rent95_admin_session',
  '*.rent95_admin_session',
  '*.adminSession',
  '*.admin_session',

  // -- Same set, at request root (Express req.body.password, etc.) ----------
  'req.body.password',
  'req.body.newPassword',
  'req.body.currentPassword',
  'req.body.oldPassword',
  'req.body.refreshToken',
  'req.body.token',
  'req.body.cardNumber',
  'req.body.cvv',
  'req.body.otp',
  'req.body.otpCode',
  'req.body.code',
  'req.body.pin',
  'req.body.mfaCode',

  // Query-string leaks (single-page apps sometimes forward tokens via ?token=)
  'req.query.token',
  'req.query.access_token',
  'req.query.refresh_token',
  'req.query.code',
  'req.query.state',

  // -- HTTP headers ----------------------------------------------------------
  'req.headers.authorization',
  'req.headers.Authorization',
  'req.headers.cookie',
  'req.headers.Cookie',
  'req.headers["set-cookie"]',
  'req.headers["x-api-key"]',
  'req.headers["x-admin-token"]',
  'req.headers["stripe-signature"]',
  'req.headers["idempotency-key"]',
  'req.headers["x-forwarded-for"]', // IP addresses in some jurisdictions
  'req.headers["x-real-ip"]',
  'req.headers["proxy-authorization"]',

  // -- Response headers on error paths --------------------------------------
  'res.headers["set-cookie"]',
  'res.headers["Set-Cookie"]',

  // -- Zod `flatten()` output (`fieldErrors.<field>`) -----------------------
  //    We can't glob into arbitrary field names, but the fields most likely
  //    to be echoed back with user input are the same set as above.
  '*.fieldErrors.password',
  '*.fieldErrors.newPassword',
  '*.fieldErrors.currentPassword',
  '*.fieldErrors.otp',
  '*.fieldErrors.code',
  '*.fieldErrors.cvv',
  '*.fieldErrors.cardNumber',
  '*.formErrors.password',

  // -- Prisma error payloads: Prisma error meta occasionally carries the
  //    row we tried to insert. Kill anything that looks like user data. ----
  'err.meta',
  'err.meta.target',
  'err.meta.cause',
  'err.meta.modelName',
  'err.request',
  'err.request.data',
  'err.request.body',
  'err.request.headers',
  'err.config',
  'err.config.data',
  'err.config.headers',
  'err.response.data',
  'err.response.config',
  'err.response.request',

  // Same fields under `error.*` (Sentry / node event emitters sometimes
  // clone them there).
  'error.meta',
  'error.request',
  'error.config',
  'error.response.data',
  'error.response.config',

  // -- Stripe webhook payloads sometimes get logged raw. --------------------
  '*.stripeAccountId',
  '*.stripe_account_id',
  '*.stripe_customer_id',
  '*.stripeCustomerId',
  '*.rawBody',
  '*.raw_body',
];

/**
 * String matchers (JSON substrings) used by the socket / raw-string logger
 * path where structured field paths don't exist. Any log line containing
 * one of these key names followed by a value is scrubbed.
 */
export const SENSITIVE_KEYS: readonly string[] = [
  'password',
  'refreshToken',
  'refresh_token',
  'accessToken',
  'access_token',
  'idToken',
  'id_token',
  'sessionToken',
  'sessionId',
  'apiKey',
  'api_key',
  'client_secret',
  'clientSecret',
  'otp',
  'cvv',
  'privateKey',
  'private_key',
  'authorization',
  'cookie',
];

/**
 * Regexes for pattern-based redaction on serialized strings.
 * Used by `scrubMessage()` for the small number of code paths that log an
 * already-serialized string instead of a structured object.
 *
 * ORDERING MATTERS: earlier patterns run first. Put narrow patterns before
 * broad ones so we don't over-redact common substrings.
 */
export const REDACT_PATTERNS: RegExp[] = [
  // Bearer tokens in header dumps
  /Bearer\s+[A-Za-z0-9._-]+/g,
  // Stripe client secrets (sk_live_… / sk_test_… / rk_live_… / pi_…_secret_…)
  /(sk|rk|pk)_(live|test)_[A-Za-z0-9]+/g,
  /pi_[A-Za-z0-9]+_secret_[A-Za-z0-9]+/g,
  /seti_[A-Za-z0-9]+_secret_[A-Za-z0-9]+/g,
  // Stripe webhook signing secrets `whsec_…`
  /whsec_[A-Za-z0-9]+/g,
  // JWT-shaped tokens (3-segment base64url with a period between)
  /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g,
  // Admin session wire format: <b64url(iv)>.<b64url(ct)>.<b64url(tag)>
  // IV is 12 bytes = 16 chars b64url. Tag is 16 bytes = 22 chars b64url.
  // Ciphertext is variable length but always > 16 chars. Match structurally.
  /\b[A-Za-z0-9_-]{16}\.[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{22}\b/g,
  // Cloudinary API secrets (dashboard-formatted) — 27 chars base64ish
  /\b[A-Za-z0-9_-]{27}\b(?=\s|[,"'}])/g,
  // Credit-card PAN (13-19 digits, allow spaces / dashes) — Luhn check would
  // be more precise but this catches the leak vector.
  /\b(?:\d[ -]?){13,19}\b/g,
  // CVV in context (`cvv=123`, `"cvv": "123"`)
  /"?(cvv|cvc)"?\s*[:=]\s*"?\d{3,4}"?/gi,
  // Set-Cookie dump for our admin session cookie name
  /__Host-rent95_admin_session=[^;\s"]+/g,
];

/** Replace secrets in an already-serialized string. Best-effort. */
export function scrubMessage(input: string): string {
  let out = input;
  for (const re of REDACT_PATTERNS) {
    out = out.replace(re, '[REDACTED]');
  }
  return out;
}
