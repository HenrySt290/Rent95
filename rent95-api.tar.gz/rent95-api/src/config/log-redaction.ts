/**
 * Sensitive-field redaction paths for pino's built-in redact option.
 *
 * pino's redact is faster than a general-purpose recursive scrubber
 * because it walks explicit paths — no schema inference at write time.
 * The trade-off is we must enumerate every place a secret might land.
 * The list below is deliberately over-broad: better to redact a harmless
 * field than to leak a secret.
 *
 * References:
 *  - pino redact docs: https://getpino.io/#/docs/redaction
 *  - OWASP logging cheat sheet §"Data to exclude"
 */
export const REDACT_PATHS: readonly string[] = [
  // -- Direct secret fields (any nesting depth) ------------------------------
  '*.password',
  '*.newPassword',
  '*.currentPassword',
  '*.passwordHash',
  '*.token',
  '*.accessToken',
  '*.refreshToken',
  '*.refresh_token',
  '*.access_token',
  '*.apiKey',
  '*.api_key',
  '*.secret',
  '*.client_secret',
  '*.clientSecret',
  '*.otp',
  '*.otpCode',
  '*.code',
  '*.pin',
  '*.cvv',
  '*.cvc',
  '*.cardNumber',
  '*.card_number',
  '*.iban',
  '*.ssn',
  '*.taxId',
  '*.tax_id',

  // -- Same set, at request root (Express req.body.password, etc.) -----------
  'req.body.password',
  'req.body.newPassword',
  'req.body.currentPassword',
  'req.body.refreshToken',
  'req.body.token',
  'req.body.cardNumber',
  'req.body.cvv',
  'req.body.otp',
  'req.body.otpCode',
  'req.body.code',

  // -- HTTP headers ----------------------------------------------------------
  'req.headers.authorization',
  'req.headers.cookie',
  'req.headers["set-cookie"]',
  'req.headers["x-api-key"]',
  'req.headers["stripe-signature"]',
  'req.headers["idempotency-key"]',

  // -- Response headers on error paths --------------------------------------
  'res.headers["set-cookie"]',

  // -- Prisma error payloads: Prisma error meta occasionally carries the
  //    row we tried to insert. Kill anything that looks like user data. ----
  'err.meta.target',
  'err.meta.cause',
  'err.request.data',
  'err.request.body',
  'err.config.data',
  'err.response.data',

  // -- Stripe webhook payloads sometimes get logged raw. --------------------
  '*.stripeAccountId',
  '*.stripe_account_id',
];

/**
 * String matchers (JSON substrings) used by the socket / raw-string logger
 * path where structured field paths don't exist. Any log line containing
 * one of these key names followed by a value is scrubbed.
 */
export const SENSITIVE_KEYS: readonly string[] = [
  'password',
  'refreshToken',
  'refresh_token',
  'accessToken',
  'access_token',
  'apiKey',
  'api_key',
  'client_secret',
  'clientSecret',
  'otp',
  'cvv',
];

/**
 * Regexes for pattern-based redaction on serialized strings.
 * Used by `scrubMessage()` for the small number of code paths that log an
 * already-serialized string instead of a structured object.
 */
export const REDACT_PATTERNS: RegExp[] = [
  // Bearer tokens in header dumps
  /Bearer\s+[A-Za-z0-9._-]+/g,
  // Stripe client secrets (sk_live_… / sk_test_… / pi_…_secret_… )
  /(sk|rk)_(live|test)_[A-Za-z0-9]+/g,
  /pi_[A-Za-z0-9]+_secret_[A-Za-z0-9]+/g,
  // JWT-shaped tokens (3-segment base64url with a period between)
  /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g,
  // Cloudinary API secrets (dashboard-formatted) — 27 chars base64ish
  /\b[A-Za-z0-9_-]{27}\b(?=\s|[,"'}])/g,
];

/** Replace secrets in an already-serialized string. Best-effort. */
export function scrubMessage(input: string): string {
  let out = input;
  for (const re of REDACT_PATTERNS) {
    out = out.replace(re, '[REDACTED]');
  }
  return out;
}
