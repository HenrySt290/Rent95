import type { NextFunction, Request, Response } from 'express';
import { prisma } from '../config/prisma';
import { logger } from '../config/logger';

/**
 * HTTP-level idempotency for unsafe client requests.
 *
 * Contract (mirrors Stripe's `Idempotency-Key` semantics):
 *
 *   - Client sends `Idempotency-Key: <opaque-string-max-200-chars>` on
 *     any POST/PATCH/DELETE it wants to safely retry.
 *   - First hit: request runs normally. On a 2xx response we snapshot
 *     `{ statusCode, responseJson }` under the key + `(userId, method, path)`
 *     tuple. TTL 24h (see vacuum job).
 *   - Retry within TTL: middleware short-circuits with the stored response.
 *     The handler NEVER runs a second time.
 *   - Key reuse across different `(method, path)` → 422 (client bug).
 *   - Concurrent duplicates → the loser hits the unique-constraint on
 *     `key`, waits, and gets the stored response too.
 *
 * Mounted on order creation, review creation, dispute creation, etc.
 * NOT on the Stripe webhook (that has its own event-id dedupe).
 *
 * Scope note: the key is namespaced by `userId` so two different users
 * with the same client-generated UUID don't collide.
 */
export function idempotency() {
  return async function middleware(req: Request, res: Response, next: NextFunction) {
    const key = req.header('idempotency-key');
    if (!key) return next();
    if (key.length > 200 || key.length < 8) {
      return res.status(400).json({
        success: false,
        code: 'invalid_idempotency_key',
        message: 'Idempotency-Key must be 8–200 characters.',
      });
    }

    const userId = req.auth?.sub ?? null;
    const method = req.method;
    const path = req.originalUrl.split('?')[0];
    const scopedKey = userId ? `${userId}:${key}` : `anon:${key}`;

    // ─── Check the ledger.
    try {
      const existing = await prisma.idempotencyRecord.findUnique({
        where: { key: scopedKey },
      });
      if (existing) {
        if (existing.method !== method || existing.path !== path) {
          return res.status(422).json({
            success: false,
            code: 'idempotency_key_reused',
            message:
              'This Idempotency-Key was used for a different request. Generate a new key.',
          });
        }
        res.setHeader('Idempotent-Replay', 'true');
        return res
          .status(existing.statusCode)
          .json(existing.responseJson as Record<string, unknown>);
      }
    } catch (e) {
      // If the ledger is down (Postgres blip), fall through to normal
      // handling. Better to accept a rare duplicate than to hard-fail
      // every POST during a DB hiccup.
      logger.warn({ err: e, scopedKey }, 'Idempotency lookup failed — proceeding');
    }

    // ─── Wrap res.json to snapshot the outbound payload on 2xx.
    const originalJson = res.json.bind(res);
    res.json = ((body: unknown) => {
      const status = res.statusCode;
      if (status >= 200 && status < 300) {
        // Fire-and-forget; if the write fails we still return the response.
        prisma.idempotencyRecord
          .create({
            data: {
              key: scopedKey,
              userId,
              method,
              path,
              statusCode: status,
              responseJson: body as never,
            },
          })
          .catch((e: unknown) => {
            // Unique-constraint means a concurrent identical request
            // wrote first. That's fine — the other write is authoritative.
            const code = (e as { code?: string }).code;
            if (code !== 'P2002') {
              logger.warn({ err: e, scopedKey }, 'Idempotency snapshot failed');
            }
          });
      }
      return originalJson(body);
    }) as typeof res.json;

    return next();
  };
}
