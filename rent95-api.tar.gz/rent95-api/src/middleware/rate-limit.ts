import rateLimit, { type Options } from 'express-rate-limit';
import { isTest } from '../config/env';

/**
 * Rate limiters. Neutered in test mode so the integration suite can hammer
 * `/api/auth/*` without tripping the (correctly aggressive) production
 * defaults.
 */
function build(opts: Partial<Options> & { max: number; windowMs: number; message?: unknown }) {
  return rateLimit({
    ...opts,
    // Effectively-off in test: a very high ceiling means the limiter still
    // *runs* (so we exercise the middleware chain) but never triggers.
    max: isTest ? 100_000 : opts.max,
    standardHeaders: true,
    legacyHeaders: false,
  });
}

export const authLimiter = build({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { success: false, message: 'Too many attempts. Please try again in a moment.' },
});

export const otpLimiter = build({
  windowMs: 60 * 1000,
  max: 3,
  message: { success: false, message: 'Too many OTP requests. Please wait a minute.' },
});

export const globalLimiter = build({
  windowMs: 60 * 1000,
  max: 300,
});
