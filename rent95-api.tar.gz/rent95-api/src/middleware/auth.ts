import type { NextFunction, Request, Response } from 'express';
import { UnauthorizedError, ForbiddenError } from '../utils/errors';
import { verifyAccessToken, type AccessTokenPayload } from '../utils/crypto';

// Extend Express Request with our authenticated user info.
declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      auth?: AccessTokenPayload;
    }
  }
}

/** Requires a valid access token. Rejects with 401 otherwise. */
export function requireAuth(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return next(new UnauthorizedError('Missing bearer token'));
  }
  const token = header.slice('Bearer '.length).trim();
  try {
    req.auth = verifyAccessToken(token);
    return next();
  } catch {
    return next(new UnauthorizedError('Invalid or expired token'));
  }
}

/** Attaches req.auth if a valid token exists, but does not fail if missing. */
export function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (header?.startsWith('Bearer ')) {
    const token = header.slice('Bearer '.length).trim();
    try {
      req.auth = verifyAccessToken(token);
    } catch {
      // ignore — treat as anonymous
    }
  }
  return next();
}

/** Role-based guard. Use after requireAuth. */
export function requireRole(...roles: string[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.auth) return next(new UnauthorizedError());
    if (!roles.includes(req.auth.role)) return next(new ForbiddenError());
    return next();
  };
}
