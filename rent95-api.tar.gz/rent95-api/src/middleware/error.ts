import type { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';
import { HttpError } from '../utils/errors';
import { logger } from '../config/logger';
import { isProd } from '../config/env';
import { captureException } from '../config/sentry';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(err: unknown, req: Request, res: Response, _next: NextFunction) {
  if (err instanceof ZodError) {
    return res.status(422).json({
      success: false,
      message: 'Validation failed',
      code: 'validation_failed',
      errors: err.flatten().fieldErrors,
    });
  }

  if (err instanceof HttpError) {
    return res.status(err.statusCode).json({
      success: false,
      message: err.message,
      code: err.code,
      details: err.details,
    });
  }

  // Unknown → 500
  logger.error({ err }, 'Unhandled error');
  captureException(err);
  return res.status(500).json({
    success: false,
    message: isProd ? 'Internal server error' : (err as Error)?.message ?? 'Unknown error',
    code: 'internal_error',
  });
}

export function notFoundHandler(req: Request, res: Response) {
  res.status(404).json({
    success: false,
    message: `Not found: ${req.method} ${req.originalUrl}`,
    code: 'route_not_found',
  });
}
