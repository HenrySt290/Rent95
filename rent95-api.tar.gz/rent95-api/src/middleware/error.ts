import type { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';
import { HttpError } from '../utils/errors';
import { logger } from '../config/logger';
import { isProd } from '../config/env';
import { captureException } from '../config/sentry';

/**
 * Central Express error handler.
 *
 * Contract:
 *   - Known error types (ZodError, HttpError) produce structured JSON
 *     responses with client-safe messages.
 *   - Unknown errors → 500 with a **generic** message in production. The
 *     underlying error is logged (redacted, via pino) and reported to
 *     Sentry (redacted, via beforeSend) — but never leaks to the client.
 *   - No stack traces in production responses. Full stacks in dev only.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(err: unknown, req: Request, res: Response, _next: NextFunction) {
  if (err instanceof ZodError) {
    return res.status(422).json({
      success: false,
      message: 'Validation failed',
      code: 'validation_failed',
      errors: err.flatten().fieldErrors,
    });
  }

  if (err instanceof HttpError) {
    return res.status(err.statusCode).json({
      success: false,
      message: err.message,
      code: err.code,
      // We intentionally do NOT forward `err.details` in production to
      // clients — Prisma errors sometimes get wrapped into HttpError
      // with a details object that leaks column names. Details are still
      // logged server-side below.
      ...(isProd ? {} : { details: err.details }),
    });
  }

  // -- Unknown error path. Log with structured redaction (pino handles
  //    the field paths declared in log-redaction.ts), and send a
  //    scrubbed exception to Sentry (see sentry.ts#beforeSend).
  logger.error(
    {
      err: _serialiseError(err),
      requestId: req.headers['x-request-id'],
      method: req.method,
      path: req.originalUrl,
    },
    'Unhandled error',
  );
  captureException(err);

  // Client sees a generic message in prod. Never the raw Error.message —
  // that can carry Prisma constraint names, secret fragments, etc.
  return res.status(500).json({
    success: false,
    message: isProd ? 'Something went wrong. Please try again.' : (err as Error)?.message ?? 'Unknown error',
    code: 'internal_error',
  });
}

export function notFoundHandler(req: Request, res: Response) {
  res.status(404).json({
    success: false,
    // Don't reflect the full URL in prod — it can be used to fingerprint
    // routes an attacker is probing.
    message: 'Not found.',
    code: 'route_not_found',
  });
}

/**
 * Reduce a thrown value to a shape safe for logging.
 *
 * We deliberately drop `err.request` / `err.config` (axios/dio) and Prisma's
 * `err.meta` — those carry the offending row's data, which is often the
 * exact field that triggered the crash (frequently the password).
 * `log-redaction.ts` scrubs any leftover fields.
 */
function _serialiseError(err: unknown): Record<string, unknown> {
  if (err instanceof Error) {
    return {
      name: err.name,
      message: err.message,
      // Stack in dev only. In prod pino captures err via its serializer
      // which also does this — belt and braces.
      ...(isProd ? {} : { stack: err.stack }),
    };
  }
  return { value: String(err) };
}
