import type { Server as HttpServer } from 'node:http';
import { Server as SocketServer, type Socket } from 'socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import { verifyAccessToken } from '../utils/crypto';
import { getRedis } from '../config/redis';
import { logger } from '../config/logger';
import { corsOrigins } from '../config/env';
import { prisma } from '../config/prisma';

/**
 * Sets up the Socket.io server, authenticated via the same JWT as REST.
 *
 * Rooms:
 *   - user:{userId}           for notifications
 *   - conversation:{convId}   for chat message broadcast
 *   - order:{orderId}         for order-status updates
 */
export function initSockets(httpServer: HttpServer): SocketServer {
  const io = new SocketServer(httpServer, {
    cors: {
      origin: corsOrigins.length > 0 ? corsOrigins : true,
      credentials: true,
    },
    transports: ['websocket', 'polling'],
  });

  // Redis adapter for horizontal scaling (per spec §14.1). Falls back to
  // in-memory adapter if Redis pub/sub can't be created (e.g. local test).
  try {
    const pubClient = getRedis();
    const subClient = pubClient.duplicate();
    io.adapter(createAdapter(pubClient, subClient));
    logger.info('Socket.io using Redis adapter');
  } catch (err) {
    logger.warn({ err }, 'Socket.io Redis adapter unavailable — using in-memory');
  }

  io.use((socket, next) => {
    try {
      const token =
        socket.handshake.auth?.token ??
        (socket.handshake.headers.authorization ?? '').toString().replace(/^Bearer /, '');
      if (!token) return next(new Error('Missing auth token'));
      const payload = verifyAccessToken(token);
      (socket as Socket & { userId?: string; role?: string }).userId = payload.sub;
      (socket as Socket & { userId?: string; role?: string }).role = payload.role;
      return next();
    } catch {
      return next(new Error('Invalid auth token'));
    }
  });

  io.on('connection', (socket) => {
    const s = socket as Socket & { userId?: string };
    if (!s.userId) return socket.disconnect(true);

    socket.join(`user:${s.userId}`);
    logger.debug({ userId: s.userId }, 'Socket connected');

    socket.on('join_conversation', async ({ conversationId }: { conversationId: string }) => {
      const conv = await prisma.conversation.findUnique({ where: { id: conversationId } });
      if (!conv) return;
      if (conv.buyerId !== s.userId && conv.sellerId !== s.userId) return;
      socket.join(`conversation:${conversationId}`);
    });

    socket.on('leave_conversation', ({ conversationId }: { conversationId: string }) => {
      socket.leave(`conversation:${conversationId}`);
    });

    socket.on('typing_start', ({ conversationId }: { conversationId: string }) => {
      socket.to(`conversation:${conversationId}`).emit('typing_started', {
        conversationId,
        userId: s.userId,
      });
    });

    socket.on('typing_stop', ({ conversationId }: { conversationId: string }) => {
      socket.to(`conversation:${conversationId}`).emit('typing_stopped', {
        conversationId,
        userId: s.userId,
      });
    });

    socket.on('mark_read', async (payload: { conversationId: string; messageIds: string[] }) => {
      await prisma.message.updateMany({
        where: { id: { in: payload.messageIds }, receiverId: s.userId },
        data: { isRead: true, readAt: new Date() },
      });
      io.to(`conversation:${payload.conversationId}`).emit('message_read', payload);
    });

    socket.on('join_order_room', ({ orderId }: { orderId: string }) => {
      socket.join(`order:${orderId}`);
    });

    socket.on('disconnect', () => {
      logger.debug({ userId: s.userId }, 'Socket disconnected');
    });
  });

  return io;
}
