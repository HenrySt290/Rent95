import argon2 from 'argon2';
import jwt from 'jsonwebtoken';
import { createHash, randomBytes } from 'node:crypto';
import { env } from '../config/env';

export type AccessTokenPayload = {
  sub: string;
  role: string;
  email: string;
};

export async function hashPassword(password: string): Promise<string> {
  return argon2.hash(password, {
    type: argon2.argon2id,
    memoryCost: 19_456,
    timeCost: 2,
    parallelism: 1,
  });
}

export async function verifyPassword(hash: string, password: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, password);
  } catch {
    return false;
  }
}

export function signAccessToken(payload: AccessTokenPayload): string {
  return jwt.sign(payload, env.JWT_ACCESS_SECRET, {
    expiresIn: env.ACCESS_TOKEN_EXPIRES_IN,
    issuer: 'rent95-api',
  });
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  return jwt.verify(token, env.JWT_ACCESS_SECRET, { issuer: 'rent95-api' }) as AccessTokenPayload;
}

/**
 * Refresh tokens are opaque random strings. We never store them in JWTs so
 * we can revoke them by deleting the DB row. Only the *hash* of the token
 * ever hits the database.
 */
export function generateRefreshToken(): { token: string; tokenHash: string } {
  const token = randomBytes(48).toString('base64url');
  const tokenHash = createHash('sha256').update(token).digest('hex');
  return { token, tokenHash };
}

export function hashRefreshToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

export function refreshTokenExpiryDate(): Date {
  const raw = env.REFRESH_TOKEN_EXPIRES_IN;
  const days = parseInt(raw.replace(/[^0-9]/g, ''), 10) || 30;
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000);
}
