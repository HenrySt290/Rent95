/**
 * Typed application errors. All expected failures go through here so the
 * error middleware can turn them into the right HTTP response.
 */
export class HttpError extends Error {
  constructor(
    public statusCode: number,
    message: string,
    public code?: string,
    public details?: unknown,
  ) {
    super(message);
    this.name = this.constructor.name;
  }
}

export class BadRequestError extends HttpError {
  constructor(message = 'Bad request', code = 'bad_request', details?: unknown) {
    super(400, message, code, details);
  }
}

export class UnauthorizedError extends HttpError {
  constructor(message = 'Unauthorized', code = 'unauthorized') {
    super(401, message, code);
  }
}

export class ForbiddenError extends HttpError {
  constructor(message = 'Forbidden', code = 'forbidden') {
    super(403, message, code);
  }
}

export class NotFoundError extends HttpError {
  constructor(message = 'Not found', code = 'not_found') {
    super(404, message, code);
  }
}

export class ConflictError extends HttpError {
  constructor(message = 'Conflict', code = 'conflict') {
    super(409, message, code);
  }
}

export class ValidationError extends HttpError {
  constructor(message = 'Validation failed', details?: unknown) {
    super(422, message, 'validation_failed', details);
  }
}
