/**
 * Small helper to slugify strings for URLs and product identifiers.
 * Not exhaustive — for a production marketplace consider `slugify` npm pkg
 * with locale-aware transliteration if you support non-Latin scripts.
 */
export function slugify(input: string, suffix?: string): string {
  const base = input
    .toString()
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 180);
  return suffix ? `${base}-${suffix}` : base;
}

export function generateOrderNumber(): string {
  const now = new Date();
  const y = now.getFullYear().toString().slice(-2);
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const rand = Math.floor(Math.random() * 9000) + 1000;
  return `R95-${y}${m}${d}-${rand}`;
}
