import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';

import { corsOrigins, isProd, isTest } from './config/env';
import { errorHandler, notFoundHandler } from './middleware/error';
import { globalLimiter } from './middleware/rate-limit';

import authRoutes from './routes/auth.routes';
import productRoutes from './routes/product.routes';
import marketplaceRoutes from './routes/marketplace.routes';
import categoryRoutes from './routes/category.routes';
import adminRoutes from './routes/admin.routes';
import { stripeWebhook } from './controllers/payment.controller';

export function createApp(): Express {
  const app = express();

  app.set('trust proxy', 1);
  app.use(helmet());
  app.use(compression());
  app.use(
    cors({
      origin: corsOrigins.length > 0 ? corsOrigins : true,
      credentials: true,
    }),
  );
  if (!isProd && !isTest) app.use(morgan('dev'));

  // Stripe webhook needs the raw body BEFORE express.json() consumes it.
  app.post('/api/payments/webhook/stripe', express.raw({ type: 'application/json' }), stripeWebhook);

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  app.use(globalLimiter);

  app.get('/health', (_req: Request, res: Response) =>
    res.json({ status: 'ok', ts: new Date().toISOString() }),
  );

  app.use('/api/auth', authRoutes);
  app.use('/api/categories', categoryRoutes);
  app.use('/api/products', productRoutes);
  app.use('/api', marketplaceRoutes);
  app.use('/api/admin', adminRoutes);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
