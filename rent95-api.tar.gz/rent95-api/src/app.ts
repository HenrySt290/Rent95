import express, { type Express } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';

import { corsOrigins, isProd, isTest } from './config/env';
import { errorHandler, notFoundHandler } from './middleware/error';
import { globalLimiter } from './middleware/rate-limit';
import { health } from './routes/health';

import authRoutes from './routes/auth.routes';
import productRoutes from './routes/product.routes';
import marketplaceRoutes from './routes/marketplace.routes';
import categoryRoutes from './routes/category.routes';
import adminRoutes from './routes/admin.routes';
import notificationRoutes from './routes/notification.routes';
import uploadsRoutes from './routes/uploads.routes';
import userRoutes from './routes/user.routes';
import { stripeWebhook } from './controllers/payment.controller';

/**
 * Express app factory. Production-hardened per docs/SECURITY_AUDIT.md.
 *
 * Security-critical middleware order (top → bottom):
 *   1. trust proxy      (single hop; adjust when adding Cloudflare)
 *   2. helmet(strict)   security headers before *any* handler runs
 *   3. cors(hard)       origin allowlist enforced, never wildcard
 *   4. Stripe raw body  MUST come before express.json()
 *   5. express.json     100 KB cap — 100× smaller than the old 10 MB
 *   6. globalLimiter    per-IP rate limit
 *   7. routes
 *   8. notFound + error
 */
export function createApp(): Express {
  const app = express();

  // `1` trusts a single hop (Fly's edge). If we add Cloudflare in front
  // that becomes `2`. Wrong values mean req.ip is the proxy, and rate
  // limits get applied globally instead of per-user. Never set to `true`
  // in production — it accepts arbitrary X-Forwarded-For values.
  app.set('trust proxy', 1);
  app.disable('x-powered-by');

  // -- Helmet with an explicit, production-safe policy ----------------------
  //
  // Notes on our CSP choices:
  //
  //  - `default-src 'none'` (block everything by default) then explicitly
  //    allow only what a JSON API needs to emit.
  //  - No `'unsafe-inline'` — this is a pure-JSON API, no HTML rendering.
  //  - `frame-ancestors 'none'` prevents any embedding in an iframe.
  //  - `upgrade-insecure-requests` in case a client uses http:// by mistake.
  //  - HSTS: 2 years, includeSubDomains, preloadable.
  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: false,
        directives: {
          defaultSrc: ["'none'"],
          // Even an API can 500 with an HTML error page from our platform;
          // we allow same-origin styles for that edge only.
          styleSrc: ["'self'"],
          scriptSrc: ["'self'"],
          connectSrc: ["'self'"],
          imgSrc: ["'self'", 'data:'],
          fontSrc: ["'self'"],
          objectSrc: ["'none'"],
          baseUri: ["'none'"],
          formAction: ["'none'"],
          frameAncestors: ["'none'"],
          upgradeInsecureRequests: [],
        },
      },
      crossOriginEmbedderPolicy: false, // Would break cross-origin fetches from mobile
      crossOriginOpenerPolicy: { policy: 'same-origin' },
      crossOriginResourcePolicy: { policy: 'cross-origin' }, // allow the mobile app
      // 2 years HSTS with subdomain inclusion — required for preload
      // submission. Only asserts on HTTPS responses so localhost dev is fine.
      strictTransportSecurity: {
        maxAge: 63072000,
        includeSubDomains: true,
        preload: true,
      },
      referrerPolicy: { policy: 'no-referrer' },
      // API responses are never rendered as HTML, so DENY X-Frame-Options.
      frameguard: { action: 'deny' },
      // Legacy but cheap:
      noSniff: true,
      xssFilter: false, // Deprecated; CSP does this correctly.
      dnsPrefetchControl: { allow: false },
    }),
  );

  // -- CORS: strict allowlist ONLY, no wildcard fallback --------------------
  //
  // Prior version used `origin: true` when the env var was empty, which
  // reflects the requesting origin under `credentials: true` — the exact
  // combination the CORS spec explicitly disallows for security.
  // Now we FAIL LOUD: if the allowlist is empty in prod, that's a config
  // bug, not a permissive default. See env.ts strictness for the boot-time
  // guard that prevents this from ever happening in prod.
  const allowedOrigins = new Set(corsOrigins);
  app.use(
    cors({
      origin(origin, callback) {
        // Same-origin, curl, health-check pings, mobile app native calls
        // — none of these send an Origin header. Allow.
        if (!origin) return callback(null, true);
        if (allowedOrigins.has(origin)) return callback(null, true);
        return callback(new Error(`CORS: origin ${origin} not allowed`));
      },
      credentials: true,
      // Explicit method + header allowlists so a novel exotic method
      // (like PROPFIND) can't slip through preflight.
      methods: ['GET', 'HEAD', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
      allowedHeaders: [
        'Accept',
        'Content-Type',
        'Authorization',
        'X-Request-Id',
        'Idempotency-Key',
      ],
      exposedHeaders: ['X-Request-Id'],
      maxAge: 600,
    }),
  );

  app.use(compression());
  if (!isProd && !isTest) app.use(morgan('dev'));

  // -- Stripe webhook needs the RAW body ------------------------------------
  //
  // Must come before `express.json()` or Stripe signature verification
  // fails silently (the body becomes a parsed object, not the byte string
  // Stripe signed).
  app.post(
    '/api/payments/webhook/stripe',
    express.raw({ type: 'application/json', limit: '2mb' }),
    stripeWebhook,
  );

  // -- Body parsers ---------------------------------------------------------
  //
  // 100 KB is 50× the largest legitimate product-create payload. If we ever
  // need larger (bulk import?), give it its own scoped route + `.raw()`
  // parser, don't loosen the global limit.
  app.use(express.json({ limit: '100kb' }));
  app.use(express.urlencoded({ extended: true, limit: '100kb' }));

  app.use(globalLimiter);

  app.get('/health', health);

  app.use('/api/auth', authRoutes);
  app.use('/api/categories', categoryRoutes);
  app.use('/api/products', productRoutes);
  app.use('/api/notifications', notificationRoutes);
  app.use('/api/uploads', uploadsRoutes);
  app.use('/api/users', userRoutes);
  app.use('/api', marketplaceRoutes);
  app.use('/api/admin', adminRoutes);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
