import type { User } from '@prisma/client';
import { prisma } from '../config/prisma';
import {
  generateRefreshToken,
  hashPassword,
  hashRefreshToken,
  refreshTokenExpiryDate,
  signAccessToken,
  verifyPassword,
} from '../utils/crypto';
import { BadRequestError, ConflictError, UnauthorizedError } from '../utils/errors';

type PublicUser = Omit<User, 'passwordHash'>;

function stripUser(user: User): PublicUser {
  const { passwordHash: _pw, ...rest } = user;
  return rest;
}

export async function register(params: {
  fullName: string;
  email: string;
  phone?: string;
  password: string;
  role?: 'buyer' | 'seller';
}) {
  const existing = await prisma.user.findUnique({ where: { email: params.email } });
  if (existing) throw new ConflictError('An account with that email already exists.');

  const passwordHash = await hashPassword(params.password);
  const user = await prisma.user.create({
    data: {
      fullName: params.fullName,
      email: params.email,
      phone: params.phone,
      passwordHash,
      role: params.role ?? 'buyer',
    },
  });

  return issueTokens(user);
}

export async function login(params: { email: string; password: string; userAgent?: string; ip?: string }) {
  const user = await prisma.user.findUnique({ where: { email: params.email } });
  if (!user || !user.passwordHash) throw new UnauthorizedError('Invalid email or password');
  if (user.accountStatus !== 'active') throw new UnauthorizedError('Account is not active');

  const ok = await verifyPassword(user.passwordHash, params.password);
  if (!ok) throw new UnauthorizedError('Invalid email or password');

  return issueTokens(user, params);
}

export async function refresh(refreshToken: string) {
  const tokenHash = hashRefreshToken(refreshToken);
  const record = await prisma.refreshToken.findUnique({ where: { tokenHash }, include: { user: true } });
  if (!record || record.revokedAt || record.expiresAt < new Date()) {
    throw new UnauthorizedError('Invalid refresh token');
  }
  // Rotate: revoke the old, issue a new one.
  await prisma.refreshToken.update({ where: { id: record.id }, data: { revokedAt: new Date() } });
  return issueTokens(record.user);
}

export async function logout(refreshToken: string) {
  const tokenHash = hashRefreshToken(refreshToken);
  await prisma.refreshToken.updateMany({
    where: { tokenHash, revokedAt: null },
    data: { revokedAt: new Date() },
  });
}

export async function changePassword(userId: string, currentPassword: string, newPassword: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user || !user.passwordHash) throw new UnauthorizedError();
  const ok = await verifyPassword(user.passwordHash, currentPassword);
  if (!ok) throw new BadRequestError('Current password is incorrect');
  const passwordHash = await hashPassword(newPassword);
  await prisma.user.update({ where: { id: userId }, data: { passwordHash } });
  await prisma.refreshToken.updateMany({ where: { userId, revokedAt: null }, data: { revokedAt: new Date() } });
}

async function issueTokens(user: User, meta?: { userAgent?: string; ip?: string }) {
  const accessToken = signAccessToken({ sub: user.id, role: user.role, email: user.email });
  const { token, tokenHash } = generateRefreshToken();
  await prisma.refreshToken.create({
    data: {
      userId: user.id,
      tokenHash,
      expiresAt: refreshTokenExpiryDate(),
      userAgent: meta?.userAgent,
      ip: meta?.ip,
    },
  });
  return { user: stripUser(user), accessToken, refreshToken: token };
}
