import { Prisma } from '@prisma/client';
import { prisma } from '../config/prisma';

/**
 * Time-series analytics for the admin dashboard.
 *
 * Design notes:
 *
 * - Every daily-bucket query uses Postgres `generate_series` + LEFT JOIN so
 *   days with zero activity still appear in the output with `value = 0`.
 *   That saves the frontend from having to fill gaps and makes charts
 *   render correctly out of the box.
 *
 * - Days are bucketed in **UTC** (via `date_trunc('day', ...)`). Displaying
 *   in a specific timezone is a rendering concern — see the panel's charts.
 *   Doing timezone conversion in SQL would cost either an index or a
 *   sequential scan; we can add it in v1.1 if it matters.
 *
 * - Each metric is one round-trip. All the metrics for the dashboard are
 *   fired in parallel from the controller with `Promise.all`, so the overall
 *   response is bound by the slowest single query.
 *
 * - Percentage rates (`paymentSuccessRate`, `refundRate`, `disputeRate`) are
 *   computed as ratios over the *same window* as the series, so a dashboard
 *   header that says "94% success (last 14d)" always matches the chart.
 *
 * - Aggregations run against snapshotted `created_at` timestamps rather than
 *   `updated_at`. That matches user intuition: "orders in Jan" means orders
 *   *placed* in Jan, not orders whose status flipped in Jan.
 */

export type DayBucket = { day: string; value: number };

export type PeriodMetric = {
  total: number;
  series: DayBucket[];
  /** Percent change vs. the immediately-preceding window of equal length. */
  delta?: { percent: number; vs: 'previous_period' } | null;
};

export type AnalyticsResponse = {
  range: { from: string; to: string; days: number };
  gmv: PeriodMetric & { currency: string };
  newUsers: PeriodMetric;
  newListings: PeriodMetric;
  orders: PeriodMetric & { byStatus: Record<string, number> };
  paymentSuccessRate: number | null;
  refundRate: number | null;
  disputeRate: number | null;
  topCategories: Array<{ id: string; name: string; gmv: number; orderCount: number }>;
};

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

export async function getDashboardAnalytics(days: number): Promise<AnalyticsResponse> {
  const now = new Date();
  const from = _startOfDayUtc(new Date(now.getTime() - (days - 1) * DAY_MS));
  const to = _endOfDayUtc(now);
  // Previous window of equal length — used to compute deltas.
  const prevTo = new Date(from.getTime() - 1);
  const prevFrom = _startOfDayUtc(new Date(prevTo.getTime() - (days - 1) * DAY_MS));

  const [
    gmvSeries,
    newUsersSeries,
    newListingsSeries,
    ordersSeries,
    ordersByStatus,
    ratesRow,
    topCategories,
    prevGmvTotal,
    prevUsersTotal,
    prevListingsTotal,
    prevOrdersTotal,
  ] = await Promise.all([
    _gmvPerDay(from, to),
    _newUsersPerDay(from, to),
    _newListingsPerDay(from, to),
    _ordersPerDay(from, to),
    _ordersByStatus(from, to),
    _rates(from, to),
    _topCategories(from, to, 5),
    _gmvTotal(prevFrom, prevTo),
    _newUsersTotal(prevFrom, prevTo),
    _newListingsTotal(prevFrom, prevTo),
    _ordersTotal(prevFrom, prevTo),
  ]);

  const gmvTotal = _sumSeries(gmvSeries);
  const usersTotal = _sumSeries(newUsersSeries);
  const listingsTotal = _sumSeries(newListingsSeries);
  const ordersTotal = _sumSeries(ordersSeries);

  return {
    range: {
      from: _dateOnly(from),
      to: _dateOnly(to),
      days,
    },
    gmv: {
      total: gmvTotal,
      currency: 'USD',
      series: gmvSeries,
      delta: _deltaPercent(gmvTotal, prevGmvTotal),
    },
    newUsers: {
      total: usersTotal,
      series: newUsersSeries,
      delta: _deltaPercent(usersTotal, prevUsersTotal),
    },
    newListings: {
      total: listingsTotal,
      series: newListingsSeries,
      delta: _deltaPercent(listingsTotal, prevListingsTotal),
    },
    orders: {
      total: ordersTotal,
      series: ordersSeries,
      byStatus: ordersByStatus,
      delta: _deltaPercent(ordersTotal, prevOrdersTotal),
    },
    paymentSuccessRate: ratesRow.paymentSuccessRate,
    refundRate: ratesRow.refundRate,
    disputeRate: ratesRow.disputeRate,
    topCategories,
  };
}

// ---------------------------------------------------------------------------
// Per-metric queries
//
// Each function returns a fully-filled series (zeros for empty days) so the
// caller doesn't need to know Postgres's `generate_series` incantation. We
// use $queryRaw with Prisma.sql tagged templates so parameters are properly
// escaped and the SQL stays readable in one place.
// ---------------------------------------------------------------------------

async function _gmvPerDay(from: Date, to: Date): Promise<DayBucket[]> {
  const rows = await prisma.$queryRaw<Array<{ day: Date; value: string | null }>>(
    Prisma.sql`
      SELECT
        gs.day::date AS day,
        COALESCE(SUM(o.total_amount), 0)::text AS value
      FROM generate_series(
        date_trunc('day', ${from}::timestamp),
        date_trunc('day', ${to}::timestamp),
        '1 day'
      ) AS gs(day)
      LEFT JOIN orders o
        ON date_trunc('day', o.created_at) = gs.day
        AND o.status IN ('paid', 'active', 'completed')
      GROUP BY gs.day
      ORDER BY gs.day
    `,
  );
  return rows.map((r) => ({ day: _dateOnly(r.day), value: Number(r.value ?? 0) }));
}

async function _newUsersPerDay(from: Date, to: Date): Promise<DayBucket[]> {
  const rows = await prisma.$queryRaw<Array<{ day: Date; value: bigint }>>(
    Prisma.sql`
      SELECT gs.day::date AS day, COUNT(u.id) AS value
      FROM generate_series(
        date_trunc('day', ${from}::timestamp),
        date_trunc('day', ${to}::timestamp),
        '1 day'
      ) AS gs(day)
      LEFT JOIN users u
        ON date_trunc('day', u.created_at) = gs.day
      GROUP BY gs.day
      ORDER BY gs.day
    `,
  );
  return rows.map((r) => ({ day: _dateOnly(r.day), value: Number(r.value) }));
}

async function _newListingsPerDay(from: Date, to: Date): Promise<DayBucket[]> {
  const rows = await prisma.$queryRaw<Array<{ day: Date; value: bigint }>>(
    Prisma.sql`
      SELECT gs.day::date AS day, COUNT(p.id) AS value
      FROM generate_series(
        date_trunc('day', ${from}::timestamp),
        date_trunc('day', ${to}::timestamp),
        '1 day'
      ) AS gs(day)
      LEFT JOIN products p
        ON date_trunc('day', p.created_at) = gs.day
      GROUP BY gs.day
      ORDER BY gs.day
    `,
  );
  return rows.map((r) => ({ day: _dateOnly(r.day), value: Number(r.value) }));
}

async function _ordersPerDay(from: Date, to: Date): Promise<DayBucket[]> {
  const rows = await prisma.$queryRaw<Array<{ day: Date; value: bigint }>>(
    Prisma.sql`
      SELECT gs.day::date AS day, COUNT(o.id) AS value
      FROM generate_series(
        date_trunc('day', ${from}::timestamp),
        date_trunc('day', ${to}::timestamp),
        '1 day'
      ) AS gs(day)
      LEFT JOIN orders o
        ON date_trunc('day', o.created_at) = gs.day
      GROUP BY gs.day
      ORDER BY gs.day
    `,
  );
  return rows.map((r) => ({ day: _dateOnly(r.day), value: Number(r.value) }));
}

async function _ordersByStatus(from: Date, to: Date): Promise<Record<string, number>> {
  // For the "orders by status" pie chart we want every status that occurred
  // in the window, so we skip generate_series entirely.
  const grouped = await prisma.order.groupBy({
    by: ['status'],
    where: { createdAt: { gte: from, lte: to } },
    _count: { _all: true },
  });
  return Object.fromEntries(grouped.map((g) => [g.status, g._count._all]));
}

async function _rates(
  from: Date,
  to: Date,
): Promise<{ paymentSuccessRate: number | null; refundRate: number | null; disputeRate: number | null }> {
  // Payments: successful (captured/authorized) vs failed. Zero payments in
  // the window → null, so the frontend can render "no data yet" instead of
  // reporting a misleading 100%.
  const paymentAgg = await prisma.payment.groupBy({
    by: ['status'],
    where: { createdAt: { gte: from, lte: to } },
    _count: { _all: true },
  });
  const paymentTotal = paymentAgg.reduce((acc, r) => acc + r._count._all, 0);
  const paymentSuccessful = paymentAgg
    .filter((r) => r.status === 'captured' || r.status === 'authorized')
    .reduce((acc, r) => acc + r._count._all, 0);

  // Refund + dispute rates are ratios over ALL orders created in the window,
  // not just paid ones — that's the definition operations teams typically
  // want on the dashboard.
  const [ordersTotal, refundedCount, disputedCount] = await Promise.all([
    prisma.order.count({ where: { createdAt: { gte: from, lte: to } } }),
    prisma.order.count({
      where: { createdAt: { gte: from, lte: to }, status: 'refunded' },
    }),
    prisma.order.count({
      where: { createdAt: { gte: from, lte: to }, status: 'disputed' },
    }),
  ]);

  return {
    paymentSuccessRate: paymentTotal > 0 ? paymentSuccessful / paymentTotal : null,
    refundRate: ordersTotal > 0 ? refundedCount / ordersTotal : null,
    disputeRate: ordersTotal > 0 ? disputedCount / ordersTotal : null,
  };
}

async function _topCategories(
  from: Date,
  to: Date,
  limit: number,
): Promise<Array<{ id: string; name: string; gmv: number; orderCount: number }>> {
  const rows = await prisma.$queryRaw<
    Array<{ id: string; name: string; gmv: string | null; order_count: bigint }>
  >(
    Prisma.sql`
      SELECT
        c.id::text AS id,
        c.name AS name,
        COALESCE(SUM(o.total_amount), 0)::text AS gmv,
        COUNT(o.id) AS order_count
      FROM orders o
      JOIN products p ON p.id = o.product_id
      JOIN categories c ON c.id = p.category_id
      WHERE o.created_at >= ${from}
        AND o.created_at <= ${to}
        AND o.status IN ('paid', 'active', 'completed')
      GROUP BY c.id, c.name
      ORDER BY SUM(o.total_amount) DESC NULLS LAST
      LIMIT ${limit}
    `,
  );
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    gmv: Number(r.gmv ?? 0),
    orderCount: Number(r.order_count),
  }));
}

// ---------------------------------------------------------------------------
// Total-in-window queries (used for delta%)
// ---------------------------------------------------------------------------

async function _gmvTotal(from: Date, to: Date): Promise<number> {
  const agg = await prisma.order.aggregate({
    _sum: { totalAmount: true },
    where: {
      createdAt: { gte: from, lte: to },
      status: { in: ['paid', 'active', 'completed'] },
    },
  });
  return Number(agg._sum.totalAmount ?? 0);
}

const _newUsersTotal = (from: Date, to: Date) =>
  prisma.user.count({ where: { createdAt: { gte: from, lte: to } } });

const _newListingsTotal = (from: Date, to: Date) =>
  prisma.product.count({ where: { createdAt: { gte: from, lte: to } } });

const _ordersTotal = (from: Date, to: Date) =>
  prisma.order.count({ where: { createdAt: { gte: from, lte: to } } });

// ---------------------------------------------------------------------------
// Utility
// ---------------------------------------------------------------------------

const DAY_MS = 24 * 60 * 60 * 1000;

function _startOfDayUtc(d: Date): Date {
  const c = new Date(d);
  c.setUTCHours(0, 0, 0, 0);
  return c;
}
function _endOfDayUtc(d: Date): Date {
  const c = new Date(d);
  c.setUTCHours(23, 59, 59, 999);
  return c;
}
function _dateOnly(d: Date): string {
  return d.toISOString().slice(0, 10); // YYYY-MM-DD
}
function _sumSeries(s: DayBucket[]): number {
  return s.reduce((acc, x) => acc + x.value, 0);
}

/**
 * Percent change from `previous` to `current`. Returns `null` when the
 * previous window had zero — infinity would render poorly in the UI, and
 * "N/A" is the honest answer.
 */
function _deltaPercent(current: number, previous: number): PeriodMetric['delta'] {
  if (previous === 0) return null;
  const percent = ((current - previous) / previous) * 100;
  // Cap at ±9999.9% so the chip doesn't blow the layout on a first-week launch.
  const clamped = Math.max(-9999.9, Math.min(9999.9, percent));
  return { percent: Math.round(clamped * 10) / 10, vs: 'previous_period' };
}
