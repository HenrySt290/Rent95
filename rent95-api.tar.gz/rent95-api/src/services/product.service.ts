import type { Prisma } from '@prisma/client';
import { prisma } from '../config/prisma';
import { ForbiddenError, NotFoundError } from '../utils/errors';
import { slugify } from '../utils/slug';

export type ProductSearchParams = {
  keyword?: string;
  categoryId?: string;
  listingType?: 'rent' | 'sale' | 'service' | 'hybrid';
  minPrice?: number;
  maxPrice?: number;
  city?: string;
  sort?: 'relevance' | 'newest' | 'price_asc' | 'price_desc' | 'rating';
  page?: number;
  pageSize?: number;
};

export async function searchProducts(params: ProductSearchParams) {
  const page = Math.max(1, params.page ?? 1);
  const pageSize = Math.min(50, Math.max(1, params.pageSize ?? 20));
  const skip = (page - 1) * pageSize;

  const where: Prisma.ProductWhereInput = {
    status: 'active',
    moderationStatus: 'approved',
  };
  if (params.categoryId) where.categoryId = params.categoryId;
  if (params.listingType) where.listingType = params.listingType;
  if (params.minPrice != null || params.maxPrice != null) {
    where.price = {
      gte: params.minPrice ?? undefined,
      lte: params.maxPrice ?? undefined,
    };
  }
  if (params.keyword) {
    where.OR = [
      { title: { contains: params.keyword, mode: 'insensitive' } },
      { description: { contains: params.keyword, mode: 'insensitive' } },
    ];
  }
  if (params.city) {
    where.location = { is: { city: { contains: params.city, mode: 'insensitive' } } };
  }

  const orderBy: Prisma.ProductOrderByWithRelationInput | Prisma.ProductOrderByWithRelationInput[] =
    params.sort === 'price_asc'
      ? { price: 'asc' }
      : params.sort === 'price_desc'
        ? { price: 'desc' }
        : params.sort === 'rating'
          ? [{ ratingAverage: 'desc' }, { createdAt: 'desc' }]
          : params.sort === 'newest'
            ? { createdAt: 'desc' }
            : [{ favoriteCount: 'desc' }, { ratingAverage: 'desc' }];

  const [items, total] = await Promise.all([
    prisma.product.findMany({
      where,
      include: {
        media: { orderBy: { sortOrder: 'asc' }, take: 3 },
        location: true,
        owner: { select: { id: true, fullName: true, profileImageUrl: true } },
        category: { select: { id: true, name: true, slug: true } },
      },
      orderBy,
      skip,
      take: pageSize,
    }),
    prisma.product.count({ where }),
  ]);

  return { items, total, page, pageSize };
}

export async function getProduct(id: string) {
  const product = await prisma.product.findUnique({
    where: { id },
    include: {
      media: { orderBy: { sortOrder: 'asc' } },
      location: true,
      owner: { select: { id: true, fullName: true, profileImageUrl: true, ratingAverage: true, reviewCount: true } },
      category: true,
      subcategory: true,
      reviews: {
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: { reviewer: { select: { id: true, fullName: true, profileImageUrl: true } } },
      },
    },
  });
  if (!product) throw new NotFoundError('Listing not found');
  return product;
}

export type CreateProductInput = {
  ownerId: string;
  title: string;
  description: string;
  categoryId: string;
  subcategoryId?: string;
  listingType: 'rent' | 'sale' | 'service' | 'hybrid';
  price: number;
  priceUnit: 'hour' | 'day' | 'week' | 'month' | 'fixed';
  securityDeposit?: number;
  currency: string;
  quantity: number;
  condition?: 'new_item' | 'like_new' | 'good' | 'fair' | 'used';
  customAttributes?: Prisma.InputJsonValue;
  deliveryOptions?: string[];
  location: {
    address: string;
    city: string;
    state?: string;
    country: string;
    postalCode?: string;
    latitude: number;
    longitude: number;
  };
  images?: string[];
};

export async function createProduct(input: CreateProductInput) {
  const slug = slugify(input.title, Math.random().toString(36).slice(2, 8));
  return prisma.product.create({
    data: {
      ownerId: input.ownerId,
      title: input.title,
      slug,
      description: input.description,
      categoryId: input.categoryId,
      subcategoryId: input.subcategoryId,
      listingType: input.listingType,
      price: input.price,
      priceUnit: input.priceUnit,
      securityDeposit: input.securityDeposit ?? 0,
      currency: input.currency,
      quantity: input.quantity,
      condition: input.condition,
      customAttributes: input.customAttributes,
      deliveryOptions: input.deliveryOptions ?? ['pickup'],
      status: 'pending',
      moderationStatus: 'pending',
      location: {
        create: {
          address: input.location.address,
          city: input.location.city,
          state: input.location.state,
          country: input.location.country,
          postalCode: input.location.postalCode,
          latitude: input.location.latitude,
          longitude: input.location.longitude,
        },
      },
      media: input.images && input.images.length > 0
        ? {
            create: input.images.map((url, i) => ({
              url,
              mediaType: 'image',
              sortOrder: i,
              isPrimary: i === 0,
            })),
          }
        : undefined,
    },
    include: { media: true, location: true },
  });
}

export async function updateProduct(id: string, ownerId: string, actorRole: string, patch: Partial<CreateProductInput>) {
  const existing = await prisma.product.findUnique({ where: { id } });
  if (!existing) throw new NotFoundError('Listing not found');
  if (existing.ownerId !== ownerId && actorRole !== 'admin') throw new ForbiddenError();

  const majorEdit = patch.price != null || patch.description != null || patch.title != null;
  return prisma.product.update({
    where: { id },
    data: {
      title: patch.title,
      description: patch.description,
      categoryId: patch.categoryId,
      subcategoryId: patch.subcategoryId,
      listingType: patch.listingType,
      price: patch.price,
      priceUnit: patch.priceUnit,
      securityDeposit: patch.securityDeposit,
      quantity: patch.quantity,
      condition: patch.condition,
      customAttributes: patch.customAttributes,
      deliveryOptions: patch.deliveryOptions,
      moderationStatus: majorEdit ? 'pending' : existing.moderationStatus,
      status: majorEdit ? 'pending' : existing.status,
    },
  });
}

export async function setProductStatus(
  id: string,
  actorId: string,
  actorRole: string,
  status: 'paused' | 'archived' | 'active',
) {
  const p = await prisma.product.findUnique({ where: { id } });
  if (!p) throw new NotFoundError();
  if (p.ownerId !== actorId && actorRole !== 'admin') throw new ForbiddenError();
  return prisma.product.update({ where: { id }, data: { status } });
}

export async function toggleFavorite(userId: string, productId: string) {
  const existing = await prisma.favorite.findUnique({
    where: { userId_productId: { userId, productId } },
  });
  if (existing) {
    await prisma.favorite.delete({ where: { id: existing.id } });
    await prisma.product.update({ where: { id: productId }, data: { favoriteCount: { decrement: 1 } } });
    return { favorited: false };
  }
  await prisma.favorite.create({ data: { userId, productId } });
  await prisma.product.update({ where: { id: productId }, data: { favoriteCount: { increment: 1 } } });
  return { favorited: true };
}

export function listFavorites(userId: string) {
  return prisma.favorite.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
    include: {
      product: {
        include: {
          media: { take: 1, orderBy: { sortOrder: 'asc' } },
          location: true,
        },
      },
    },
  });
}
