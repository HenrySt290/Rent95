import Stripe from 'stripe';
import { env } from '../config/env';
import { prisma } from '../config/prisma';
import { BadRequestError, NotFoundError } from '../utils/errors';

let _stripe: Stripe | null = null;
function stripe(): Stripe {
  if (!env.STRIPE_SECRET_KEY) {
    throw new BadRequestError('Stripe is not configured on the server.');
  }
  if (!_stripe) _stripe = new Stripe(env.STRIPE_SECRET_KEY, { apiVersion: '2024-11-20.acacia' });
  return _stripe;
}

/**
 * Create a Stripe PaymentIntent for an order, using Stripe Connect
 * `transfer_data.destination` to route funds to the seller minus the
 * platform fee. Escrow is achieved with `capture_method: 'manual'` —
 * we capture on `active`, and cancel on `rejected` to refund.
 */
export async function createPaymentIntent(orderId: string, payerId: string) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { seller: { include: { sellerProfile: true } } },
  });
  if (!order) throw new NotFoundError('Order not found');
  if (order.buyerId !== payerId) throw new BadRequestError('Not your order');
  if (order.paymentStatus === 'captured') throw new BadRequestError('Already paid');

  const destination = order.seller.sellerProfile?.stripeAccountId;
  const platformFeeCents = Math.round(Number(order.platformFee) * 100);
  const amountCents = Math.round(Number(order.totalAmount) * 100);

  const intent = await stripe().paymentIntents.create(
    {
      amount: amountCents,
      currency: order.currency.toLowerCase(),
      capture_method: 'manual',
      metadata: {
        orderId: order.id,
        orderNumber: order.orderNumber,
        buyerId: order.buyerId,
        sellerId: order.sellerId,
      },
      application_fee_amount: platformFeeCents,
      transfer_data: destination ? { destination } : undefined,
    },
    { idempotencyKey: `pi-${order.id}` },
  );

  await prisma.payment.upsert({
    where: { idempotencyKey: `pi-${order.id}` },
    create: {
      orderId: order.id,
      payerId: order.buyerId,
      sellerId: order.sellerId,
      provider: 'stripe',
      providerPaymentId: intent.id,
      amount: order.totalAmount,
      platformFee: order.platformFee,
      sellerAmount: Number(order.totalAmount) - Number(order.platformFee),
      currency: order.currency,
      status: 'created',
      escrowStatus: 'held',
      idempotencyKey: `pi-${order.id}`,
    },
    update: { providerPaymentId: intent.id },
  });

  return { clientSecret: intent.client_secret, paymentIntentId: intent.id };
}

export async function handleStripeWebhook(rawBody: Buffer, signature: string) {
  if (!env.STRIPE_WEBHOOK_SECRET) throw new BadRequestError('Webhook not configured');
  const event = stripe().webhooks.constructEvent(rawBody, signature, env.STRIPE_WEBHOOK_SECRET);

  switch (event.type) {
    case 'payment_intent.amount_capturable_updated':
    case 'payment_intent.succeeded': {
      const intent = event.data.object as Stripe.PaymentIntent;
      const orderId = intent.metadata?.orderId;
      if (orderId) {
        await prisma.$transaction([
          prisma.order.update({
            where: { id: orderId },
            data: {
              status: 'paid',
              paymentStatus: intent.status === 'succeeded' ? 'captured' : 'authorized',
            },
          }),
          prisma.payment.updateMany({
            where: { providerPaymentId: intent.id },
            data: {
              status: intent.status === 'succeeded' ? 'captured' : 'authorized',
              escrowStatus: 'held',
            },
          }),
        ]);
      }
      break;
    }
    case 'payment_intent.payment_failed': {
      const intent = event.data.object as Stripe.PaymentIntent;
      await prisma.payment.updateMany({
        where: { providerPaymentId: intent.id },
        data: { status: 'failed' },
      });
      break;
    }
    default:
      break;
  }

  return { received: true };
}

/** Called when an order transitions to `completed` — release escrow and mark payout eligible. */
export async function releaseEscrow(orderId: string) {
  const payment = await prisma.payment.findFirst({ where: { orderId, provider: 'stripe' } });
  if (!payment || !payment.providerPaymentId) return;

  // If we still hold an authorization, capture it now.
  if (payment.status === 'authorized') {
    await stripe().paymentIntents.capture(payment.providerPaymentId);
  }

  await prisma.payment.update({
    where: { id: payment.id },
    data: { status: 'captured', escrowStatus: 'released' },
  });
}
