import Stripe from 'stripe';
import { env } from '../config/env';
import { prisma } from '../config/prisma';
import { logger } from '../config/logger';
import { BadRequestError, NotFoundError } from '../utils/errors';

let _stripe: Stripe | null = null;
function stripe(): Stripe {
  if (!env.STRIPE_SECRET_KEY) {
    throw new BadRequestError('Stripe is not configured on the server.');
  }
  if (!_stripe) {
    _stripe = new Stripe(env.STRIPE_SECRET_KEY, {
      apiVersion: '2024-11-20.acacia',
      // Stripe's Node client already retries 500/502/503/504 + network errors
      // with jittered exponential backoff. `maxNetworkRetries: 2` means our
      // idempotency-key path retries up to twice before we surface a 5xx —
      // safe because Stripe deduplicates on the idempotency key.
      maxNetworkRetries: 2,
      timeout: 15_000,
    });
  }
  return _stripe;
}

/**
 * Create a Stripe PaymentIntent for an order.
 *
 * ────────────────────────────────────────────────────────────────────────
 *  Idempotency + Consistency contract (SRE audit item #3)
 * ────────────────────────────────────────────────────────────────────────
 *
 * Both external and internal state transitions are bounded by the
 * deterministic key `pi-${order.id}`:
 *
 *   1. **Stripe API side** — the idempotency key is passed to
 *      `paymentIntents.create`, so:
 *        - If Stripe already created an intent under that key, it returns
 *          the same one. No duplicate intents. No double charges. Even
 *          across region failovers.
 *        - If Stripe returns 5xx, the Node client retries automatically
 *          under the same key (see `maxNetworkRetries` above).
 *
 *   2. **Our DB side** — `Payment.idempotencyKey` is `@unique` in Prisma,
 *      so a concurrent second call from the client races safely: the
 *      losing transaction hits a unique-constraint violation which we
 *      catch and translate into a refetch of the existing row.
 *
 *   3. **Draft-row pattern** — we upsert a `created` `Payment` row FIRST,
 *      BEFORE calling Stripe. That way if Stripe is slow / 5xx, we still
 *      have a record of the attempt, and a client retry finds it by
 *      `idempotencyKey` and returns the (freshly re-fetched) client
 *      secret without opening a second intent.
 *
 *   4. **Terminal-state guard** — a captured or refunded order returns
 *      a `BadRequestError('Already paid')` early so a client that lost
 *      its client_secret cannot accidentally re-authorize.
 *
 *   5. **Escrow release** is likewise bounded by
 *      `escrowStatus === 'released'` → early return, so a completion
 *      webhook fired twice cannot double-capture.
 */
export async function createPaymentIntent(orderId: string, payerId: string) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { seller: { include: { sellerProfile: true } } },
  });
  if (!order) throw new NotFoundError('Order not found');
  if (order.buyerId !== payerId) throw new BadRequestError('Not your order');
  if (order.paymentStatus === 'captured') throw new BadRequestError('Already paid');
  if (order.paymentStatus === 'refunded') throw new BadRequestError('Order was refunded');

  const idempotencyKey = `pi-${order.id}`;

  // ─── Step A: check for an existing draft. Client retry after a network
  //     drop hits this and short-circuits without touching Stripe again.
  const existing = await prisma.payment.findUnique({
    where: { idempotencyKey },
  });
  if (existing?.providerPaymentId) {
    // Refetch the intent to get a fresh client_secret (client_secret is
    // stable for the intent's lifetime; refetching is essentially free
    // and never triggers a re-authorization).
    try {
      const intent = await stripe().paymentIntents.retrieve(existing.providerPaymentId);
      // If the intent has already succeeded or been canceled server-side,
      // reflect that in our DB and refuse to hand back a client_secret.
      if (intent.status === 'succeeded' || intent.status === 'canceled') {
        await prisma.payment.updateMany({
          where: { providerPaymentId: intent.id },
          data: {
            status: intent.status === 'succeeded' ? 'captured' : 'failed',
          },
        });
        throw new BadRequestError('Payment already finalized');
      }
      return {
        clientSecret: intent.client_secret,
        paymentIntentId: intent.id,
        reused: true,
      };
    } catch (e) {
      // If Stripe forgot the intent (very rare — Stripe stores forever),
      // fall through and create a new one under the same key. Stripe
      // treats that as a NEW resource because the old idempotency window
      // (24h) has expired.
      logger.warn(
        { err: e, orderId, providerPaymentId: existing.providerPaymentId },
        'Failed to retrieve existing PaymentIntent, will recreate',
      );
    }
  }

  const destination = order.seller.sellerProfile?.stripeAccountId;
  const platformFeeCents = Math.round(Number(order.platformFee) * 100);
  const amountCents = Math.round(Number(order.totalAmount) * 100);

  // ─── Step B: draft-first upsert. If Stripe 5xx or the process dies
  //     between the two calls, the next client retry finds this row via
  //     idempotencyKey and Step A above handles the rest.
  await prisma.payment.upsert({
    where: { idempotencyKey },
    create: {
      orderId: order.id,
      payerId: order.buyerId,
      sellerId: order.sellerId,
      provider: 'stripe',
      amount: order.totalAmount,
      platformFee: order.platformFee,
      sellerAmount: Number(order.totalAmount) - Number(order.platformFee),
      currency: order.currency,
      status: 'created',
      escrowStatus: 'held',
      idempotencyKey,
    },
    update: {}, // draft already exists — leave as-is
  });

  // ─── Step C: create (or reuse) the intent on Stripe. `idempotencyKey`
  //     is Stripe's server-side dedupe token: two concurrent calls with
  //     the same key return the SAME intent, never two.
  let intent: Stripe.PaymentIntent;
  try {
    intent = await stripe().paymentIntents.create(
      {
        amount: amountCents,
        currency: order.currency.toLowerCase(),
        capture_method: 'manual',
        metadata: {
          orderId: order.id,
          orderNumber: order.orderNumber,
          buyerId: order.buyerId,
          sellerId: order.sellerId,
        },
        application_fee_amount: platformFeeCents,
        transfer_data: destination ? { destination } : undefined,
      },
      { idempotencyKey },
    );
  } catch (e) {
    // Stripe network / 5xx exhausted retries. The draft row stays put
    // so the next client retry will find it in Step A and try again
    // under the same key — Stripe will return the same intent if it
    // was ever created server-side.
    logger.error(
      { err: e, orderId, idempotencyKey },
      'Stripe paymentIntents.create failed after retries',
    );
    throw e;
  }

  // ─── Step D: attach the provider id to the draft.
  await prisma.payment.update({
    where: { idempotencyKey },
    data: { providerPaymentId: intent.id },
  });

  return {
    clientSecret: intent.client_secret,
    paymentIntentId: intent.id,
    reused: false,
  };
}

/**
 * Stripe webhook — every handler must be idempotent because Stripe
 * WILL redeliver events (after 5xx, after admin replay, on network
 * blips). We enforce that at the DB layer via `ProcessedWebhookEvent`:
 * we INSERT the event id inside the same transaction as the side
 * effect, so a re-delivery gets a unique-constraint hit and we return
 * 200 without doing anything.
 */
export async function handleStripeWebhook(rawBody: Buffer, signature: string) {
  if (!env.STRIPE_WEBHOOK_SECRET) throw new BadRequestError('Webhook not configured');
  const event = stripe().webhooks.constructEvent(rawBody, signature, env.STRIPE_WEBHOOK_SECRET);

  // Idempotent short-circuit: if we've already seen this event.id, skip.
  const seen = await prisma.processedWebhookEvent.findUnique({ where: { id: event.id } });
  if (seen) {
    logger.info(
      { eventId: event.id, type: event.type },
      'Stripe webhook duplicate — no-op',
    );
    return { received: true, duplicate: true };
  }

  try {
    await prisma.$transaction(async (tx) => {
      // Record the event FIRST inside the transaction. If the side effect
      // below throws, the whole tx rolls back and Stripe redelivers —
      // but the retry finds no processed row and runs cleanly. If the
      // side effect commits, this row commits with it, blocking future
      // redeliveries.
      await tx.processedWebhookEvent.create({
        data: { id: event.id, provider: 'stripe', type: event.type },
      });

      switch (event.type) {
        case 'payment_intent.amount_capturable_updated':
        case 'payment_intent.succeeded': {
          const intent = event.data.object as Stripe.PaymentIntent;
          const orderId = intent.metadata?.orderId;
          if (!orderId) break;

          // Only forward-transition. If the order is already `paid` or
          // beyond, we don't clobber it — this prevents an out-of-order
          // redelivery from resurrecting a canceled order.
          const order = await tx.order.findUnique({ where: { id: orderId } });
          if (!order) break;
          if (['completed', 'refunded', 'canceled'].includes(order.status)) break;

          await tx.order.update({
            where: { id: orderId },
            data: {
              status: 'paid',
              paymentStatus: intent.status === 'succeeded' ? 'captured' : 'authorized',
            },
          });
          await tx.payment.updateMany({
            where: { providerPaymentId: intent.id },
            data: {
              status: intent.status === 'succeeded' ? 'captured' : 'authorized',
              escrowStatus: 'held',
            },
          });
          break;
        }
        case 'payment_intent.payment_failed': {
          const intent = event.data.object as Stripe.PaymentIntent;
          await tx.payment.updateMany({
            where: { providerPaymentId: intent.id },
            data: { status: 'failed' },
          });
          break;
        }
        case 'charge.refunded':
        case 'payment_intent.canceled': {
          const obj = event.data.object as Stripe.PaymentIntent | Stripe.Charge;
          const providerId = 'payment_intent' in obj && typeof obj.payment_intent === 'string'
            ? obj.payment_intent
            : obj.id;
          await tx.payment.updateMany({
            where: { providerPaymentId: providerId },
            data: { status: 'refunded', escrowStatus: 'refunded' },
          });
          break;
        }
        default:
          // Unhandled event types still get recorded so we don't reprocess
          // them on redelivery.
          break;
      }
    });
  } catch (e) {
    // A unique-constraint violation on ProcessedWebhookEvent means a
    // concurrent worker beat us to it. Safe to ack.
    if ((e as { code?: string }).code === 'P2002') {
      logger.info({ eventId: event.id }, 'Stripe webhook race — dedup');
      return { received: true, duplicate: true };
    }
    throw e;
  }

  return { received: true };
}

/**
 * Called when an order transitions to `completed` — release escrow and
 * mark payout eligible.
 *
 * Idempotent: early-returns if the escrow is already released. Concurrent
 * callers race safely because the DB update runs inside its own tx.
 */
export async function releaseEscrow(orderId: string) {
  const payment = await prisma.payment.findFirst({
    where: { orderId, provider: 'stripe' },
  });
  if (!payment || !payment.providerPaymentId) return;
  if (payment.escrowStatus === 'released') return;   // already done
  if (payment.status === 'refunded') return;         // never release refunded funds

  // If we still hold an authorization, capture it now. Stripe's capture is
  // idempotent by nature — capturing an already-captured intent returns
  // the same intent, not an error. Still, we gate on payment.status to
  // avoid an unnecessary API round-trip.
  if (payment.status === 'authorized') {
    try {
      await stripe().paymentIntents.capture(payment.providerPaymentId);
    } catch (e) {
      // Only rethrow if the intent isn't already captured. `already_captured`
      // → treat as success (someone else raced us).
      const code = (e as Stripe.errors.StripeError).code;
      if (code !== 'payment_intent_unexpected_state') {
        logger.error({ err: e, orderId }, 'Stripe capture failed');
        throw e;
      }
    }
  }

  await prisma.payment.update({
    where: { id: payment.id },
    data: { status: 'captured', escrowStatus: 'released' },
  });
}
