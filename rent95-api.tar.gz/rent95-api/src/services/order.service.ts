import { Prisma } from '@prisma/client';
import { prisma } from '../config/prisma';
import { BadRequestError, ForbiddenError, NotFoundError } from '../utils/errors';
import { generateOrderNumber } from '../utils/slug';
import { env } from '../config/env';

type CreateOrderInput = {
  buyerId: string;
  productId: string;
  orderType: 'rental' | 'purchase' | 'service';
  quantity?: number;
  startDatetime?: Date;
  endDatetime?: Date;
  deliveryMethod?: string;
  deliveryAddress?: Prisma.InputJsonValue;
};

/**
 * Create a booking / order. All monetary math happens *here* on the server —
 * never trust prices sent from the client.
 *
 * For MVP we use a Postgres SERIALIZABLE transaction to prevent double-booking
 * when quantity > 1. Under real load, add a Redis lock on
 * `(product_id, date_range)` before the transaction.
 */
export async function createOrder(input: CreateOrderInput) {
  return prisma.$transaction(
    async (tx) => {
      const product = await tx.product.findUnique({ where: { id: input.productId } });
      if (!product) throw new NotFoundError('Listing not found');
      if (product.status !== 'active') throw new BadRequestError('Listing is not available for booking');
      if (product.ownerId === input.buyerId) {
        throw new BadRequestError("You can't book your own listing");
      }

      const quantity = input.quantity ?? 1;
      if (quantity < 1 || quantity > product.quantity) {
        throw new BadRequestError(`Only ${product.quantity} available`);
      }

      // --- Duration ---
      let days = 1;
      if (input.orderType === 'rental' && input.startDatetime && input.endDatetime) {
        if (input.endDatetime <= input.startDatetime) {
          throw new BadRequestError('End date must be after start date');
        }
        const ms = input.endDatetime.getTime() - input.startDatetime.getTime();
        days = Math.max(1, Math.ceil(ms / (24 * 60 * 60 * 1000)));

        // Check for overlapping bookings that already consume quantity.
        const overlapping = await tx.order.count({
          where: {
            productId: product.id,
            status: { in: ['accepted', 'awaiting_payment', 'paid', 'active'] },
            AND: [
              { startDatetime: { lte: input.endDatetime } },
              { endDatetime: { gte: input.startDatetime } },
            ],
          },
        });
        if (overlapping + quantity > product.quantity) {
          throw new BadRequestError('Those dates are not available');
        }
      }

      // --- Price math ---
      const priceUnit = product.priceUnit;
      const durationMultiplier = priceUnit === 'fixed' || input.orderType !== 'rental' ? 1 : days;
      const subtotal = Number(product.price) * quantity * durationMultiplier;
      const platformFee = (subtotal * env.PLATFORM_COMMISSION_PERCENT) / 100;
      const taxAmount = Math.round(subtotal * 0.08 * 100) / 100; // TODO: region-aware tax
      const deliveryFee = 0;
      const securityDeposit = Number(product.securityDeposit);
      const totalAmount = subtotal + platformFee + taxAmount + deliveryFee + securityDeposit;

      const order = await tx.order.create({
        data: {
          orderNumber: generateOrderNumber(),
          buyerId: input.buyerId,
          sellerId: product.ownerId,
          productId: product.id,
          orderType: input.orderType,
          quantity,
          startDatetime: input.startDatetime,
          endDatetime: input.endDatetime,
          status: 'pending',
          subtotal,
          securityDeposit,
          platformFee,
          taxAmount,
          deliveryFee,
          totalAmount,
          currency: product.currency,
          deliveryMethod: input.deliveryMethod ?? 'pickup',
          deliveryAddress: input.deliveryAddress,
        },
      });

      return order;
    },
    { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
  );
}

export async function updateOrderStatus(
  orderId: string,
  actorId: string,
  actorRole: string,
  status: 'accepted' | 'rejected' | 'cancelled' | 'active' | 'completed',
) {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) throw new NotFoundError('Order not found');

  const isBuyer = order.buyerId === actorId;
  const isSeller = order.sellerId === actorId;
  const isStaff = actorRole === 'admin' || actorRole === 'support';
  if (!isBuyer && !isSeller && !isStaff) throw new ForbiddenError();

  // Allowed transitions
  const allowed: Record<string, string[]> = {
    pending: ['accepted', 'rejected', 'cancelled'],
    accepted: ['awaiting_payment', 'cancelled'],
    awaiting_payment: ['cancelled'],
    paid: ['active', 'cancelled', 'refunded'],
    active: ['completed', 'disputed'],
    completed: [],
  };
  const nextAllowed = allowed[order.status] ?? [];
  if (!nextAllowed.includes(status) && !isStaff) {
    throw new BadRequestError(`Cannot transition ${order.status} → ${status}`);
  }

  // Only sellers may accept/reject; only buyers/staff may cancel.
  if ((status === 'accepted' || status === 'rejected') && !isSeller && !isStaff) {
    throw new ForbiddenError('Only the seller can accept or reject this booking.');
  }

  return prisma.order.update({ where: { id: orderId }, data: { status } });
}

export function listMyOrders(userId: string, role: 'buyer' | 'seller') {
  return prisma.order.findMany({
    where: role === 'buyer' ? { buyerId: userId } : { sellerId: userId },
    include: {
      product: { include: { media: { take: 1, orderBy: { sortOrder: 'asc' } } } },
      buyer: { select: { id: true, fullName: true, profileImageUrl: true } },
      seller: { select: { id: true, fullName: true, profileImageUrl: true } },
    },
    orderBy: { createdAt: 'desc' },
  });
}
