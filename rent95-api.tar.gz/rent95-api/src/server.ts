import http from 'node:http';
import { createApp } from './app';
import { initSockets } from './sockets';
import { env } from './config/env';
import { logger } from './config/logger';
import { prisma } from './config/prisma';

async function main() {
  const app = createApp();
  const httpServer = http.createServer(app);
  const io = initSockets(httpServer);
  app.set('io', io);

  await prisma.$connect();
  logger.info('Database connected');

  httpServer.listen(env.PORT, () => {
    logger.info(`🚀 Rent95 API listening on http://localhost:${env.PORT}`);
    logger.info(`   Env: ${env.NODE_ENV}`);
  });

  const shutdown = async (signal: string) => {
    logger.info({ signal }, 'Shutting down…');
    io.close();
    httpServer.close();
    await prisma.$disconnect();
    process.exit(0);
  };
  process.on('SIGINT', () => void shutdown('SIGINT'));
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
}

main().catch((err) => {
  logger.error({ err }, 'Fatal error on startup');
  process.exit(1);
});
