import http from 'node:http';
import { createApp } from './app';
import { initSockets } from './sockets';
import { env } from './config/env';
import { logger } from './config/logger';
import { prisma } from './config/prisma';
import { initSentry, captureException } from './config/sentry';

/**
 * Rent95 API entrypoint.
 *
 * Graceful shutdown sequence (triggered by SIGTERM from Fly / Docker):
 *
 *   1. Stop accepting NEW HTTP connections.
 *   2. Wait for in-flight requests to finish (up to SHUTDOWN_GRACE_MS).
 *   3. Close socket.io — that fires `disconnect` on every open client so
 *      they reconnect against the new machine.
 *   4. Disconnect Prisma so the DB connections don't linger.
 *   5. process.exit(0). Fly gives us up to 30s (kill_timeout in fly.toml)
 *      before it SIGKILLs, so keep SHUTDOWN_GRACE_MS well under that.
 */

const SHUTDOWN_GRACE_MS = 20_000;

async function main() {
  initSentry();

  const app = createApp();
  const httpServer = http.createServer(app);
  const io = initSockets(httpServer);
  app.set('io', io);

  await prisma.$connect();
  logger.info('Database connected');

  httpServer.listen(env.PORT, () => {
    logger.info(`🚀 Rent95 API listening on http://localhost:${env.PORT}`);
    logger.info(`   Env: ${env.NODE_ENV}`);
  });

  let shuttingDown = false;
  const shutdown = async (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.info({ signal }, 'Shutting down…');

    // Bump the timer so a hung DB or socket close doesn't wedge the process
    // — we'd rather log "forced exit" than never terminate.
    const killTimer = setTimeout(() => {
      logger.error('Shutdown grace exceeded, forcing exit.');
      process.exit(1);
    }, SHUTDOWN_GRACE_MS);
    killTimer.unref();

    try {
      // Stop accepting new HTTP connections, wait for in-flight to finish.
      await new Promise<void>((resolve) => httpServer.close(() => resolve()));
      // Tear down sockets AFTER HTTP so an /api/... handler that fires a
      // socket emit doesn't crash on a disposed io instance.
      io.close();
      await prisma.$disconnect();
      logger.info('Shutdown complete');
      process.exit(0);
    } catch (err) {
      logger.error({ err }, 'Error during shutdown');
      process.exit(1);
    }
  };

  process.on('SIGINT', () => void shutdown('SIGINT'));
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  // Uncaught errors — log with structured context, then exit so the
  // orchestrator restarts us into a clean state.
  process.on('uncaughtException', (err) => {
    logger.fatal({ err }, 'uncaughtException');
    captureException(err);
    void shutdown('uncaughtException');
  });
  process.on('unhandledRejection', (reason) => {
    logger.fatal({ reason }, 'unhandledRejection');
    captureException(reason);
    void shutdown('unhandledRejection');
  });
}

main().catch((err) => {
  logger.error({ err }, 'Fatal error on startup');
  process.exit(1);
});
