import type { Request, Response, NextFunction } from 'express';
import * as authService from '../services/auth.service';
import { ok, created } from '../utils/response';

export async function register(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await authService.register(req.body);
    return created(res, result);
  } catch (e) { next(e); }
}

export async function login(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await authService.login({
      ...req.body,
      userAgent: req.get('user-agent') ?? undefined,
      ip: req.ip,
    });
    return ok(res, result);
  } catch (e) { next(e); }
}

export async function refresh(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await authService.refresh(req.body.refreshToken);
    return ok(res, result);
  } catch (e) { next(e); }
}

export async function logout(req: Request, res: Response, next: NextFunction) {
  try {
    await authService.logout(req.body.refreshToken);
    return ok(res, { success: true });
  } catch (e) { next(e); }
}

export async function me(req: Request, res: Response, next: NextFunction) {
  try {
    return ok(res, { id: req.auth!.sub, role: req.auth!.role, email: req.auth!.email });
  } catch (e) { next(e); }
}

export async function changePassword(req: Request, res: Response, next: NextFunction) {
  try {
    await authService.changePassword(req.auth!.sub, req.body.currentPassword, req.body.newPassword);
    return ok(res, { success: true });
  } catch (e) { next(e); }
}
