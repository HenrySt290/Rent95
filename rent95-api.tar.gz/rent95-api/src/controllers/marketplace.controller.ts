import type { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/prisma';
import { BadRequestError, ForbiddenError, NotFoundError } from '../utils/errors';
import { ok, created } from '../utils/response';

export async function listCategories(_req: Request, res: Response, next: NextFunction) {
  try {
    const cats = await prisma.category.findMany({
      where: { isActive: true },
      orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    });
    return ok(res, cats);
  } catch (e) { next(e); }
}

export async function categoryTree(_req: Request, res: Response, next: NextFunction) {
  try {
    const all = await prisma.category.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' } });
    const byParent = new Map<string | null, typeof all>();
    all.forEach((c) => {
      const key = c.parentId ?? null;
      if (!byParent.has(key)) byParent.set(key, []);
      byParent.get(key)!.push(c);
    });
    const build = (parentId: string | null): unknown[] =>
      (byParent.get(parentId) ?? []).map((c) => ({ ...c, children: build(c.id) }));
    return ok(res, build(null));
  } catch (e) { next(e); }
}

export async function listConversations(req: Request, res: Response, next: NextFunction) {
  try {
    const uid = req.auth!.sub;
    const conversations = await prisma.conversation.findMany({
      where: { OR: [{ buyerId: uid }, { sellerId: uid }] },
      orderBy: [{ lastMessageAt: 'desc' }, { createdAt: 'desc' }],
      include: {
        buyer: { select: { id: true, fullName: true, profileImageUrl: true } },
        seller: { select: { id: true, fullName: true, profileImageUrl: true } },
        product: { select: { id: true, title: true, media: { take: 1 } } },
      },
    });
    return ok(res, conversations);
  } catch (e) { next(e); }
}

export async function getConversation(req: Request, res: Response, next: NextFunction) {
  try {
    const uid = req.auth!.sub;
    const conv = await prisma.conversation.findUnique({
      where: { id: req.params.id },
      include: {
        buyer: { select: { id: true, fullName: true, profileImageUrl: true } },
        seller: { select: { id: true, fullName: true, profileImageUrl: true } },
      },
    });
    if (!conv) throw new NotFoundError('Conversation not found');
    if (conv.buyerId !== uid && conv.sellerId !== uid) throw new ForbiddenError();
    return ok(res, conv);
  } catch (e) { next(e); }
}

export async function createConversation(req: Request, res: Response, next: NextFunction) {
  try {
    const uid = req.auth!.sub;
    const { productId, orderId, sellerId } = req.body;
    if (sellerId === uid) throw new BadRequestError("You can't message yourself");
    const existing = await prisma.conversation.findFirst({
      where: { buyerId: uid, sellerId, productId: productId ?? null },
    });
    if (existing) return ok(res, existing);
    const conv = await prisma.conversation.create({
      data: { buyerId: uid, sellerId, productId, orderId },
    });
    return created(res, conv);
  } catch (e) { next(e); }
}

export async function listMessages(req: Request, res: Response, next: NextFunction) {
  try {
    const uid = req.auth!.sub;
    const conv = await prisma.conversation.findUnique({ where: { id: req.params.id } });
    if (!conv) throw new NotFoundError();
    if (conv.buyerId !== uid && conv.sellerId !== uid) throw new ForbiddenError();
    const messages = await prisma.message.findMany({
      where: { conversationId: conv.id },
      orderBy: { createdAt: 'asc' },
      take: 200,
    });
    return ok(res, messages);
  } catch (e) { next(e); }
}

export async function sendMessage(req: Request, res: Response, next: NextFunction) {
  try {
    const uid = req.auth!.sub;
    const conv = await prisma.conversation.findUnique({ where: { id: req.params.id } });
    if (!conv) throw new NotFoundError();
    if (conv.buyerId !== uid && conv.sellerId !== uid) throw new ForbiddenError();
    const receiverId = conv.buyerId === uid ? conv.sellerId : conv.buyerId;

    const msg = await prisma.$transaction(async (tx) => {
      const m = await tx.message.create({
        data: {
          conversationId: conv.id,
          senderId: uid,
          receiverId,
          messageType: req.body.type ?? 'text',
          content: req.body.content,
          mediaUrl: req.body.mediaUrl,
        },
      });
      await tx.conversation.update({
        where: { id: conv.id },
        data: {
          lastMessage: req.body.content ?? '[media]',
          lastMessageAt: new Date(),
        },
      });
      return m;
    });

    // Broadcast to sockets (best effort — the socket layer subscribes to this event).
    req.app.get('io')?.to(`conversation:${conv.id}`).emit('message_received', msg);
    req.app.get('io')?.to(`user:${receiverId}`).emit('notification_received', {
      type: 'message_received',
      conversationId: conv.id,
      messageId: msg.id,
    });

    return created(res, msg);
  } catch (e) { next(e); }
}
