import type { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/prisma';
import { ok, created } from '../utils/response';
import { BadRequestError, ForbiddenError, NotFoundError } from '../utils/errors';

export async function createReview(req: Request, res: Response, next: NextFunction) {
  try {
    const { orderId, rating, comment, mediaUrls } = req.body;
    const order = await prisma.order.findUnique({ where: { id: orderId } });
    if (!order) throw new NotFoundError('Order not found');
    if (order.buyerId !== req.auth!.sub) throw new ForbiddenError('Only the buyer can review this order.');
    if (order.status !== 'completed') throw new BadRequestError('You can only review completed orders.');

    const existing = await prisma.review.findFirst({ where: { orderId, reviewerId: req.auth!.sub } });
    if (existing) throw new BadRequestError('You have already reviewed this order.');

    const review = await prisma.$transaction(async (tx) => {
      const r = await tx.review.create({
        data: {
          orderId,
          productId: order.productId,
          reviewerId: order.buyerId,
          revieweeId: order.sellerId,
          rating,
          comment,
          mediaUrls: mediaUrls ?? [],
        },
      });
      // recompute product rating
      const agg = await tx.review.aggregate({
        where: { productId: order.productId, status: 'approved' },
        _avg: { rating: true },
        _count: true,
      });
      await tx.product.update({
        where: { id: order.productId },
        data: {
          ratingAverage: agg._avg.rating ?? 0,
          reviewCount: agg._count,
        },
      });
      return r;
    });
    return created(res, review);
  } catch (e) { next(e); }
}

export async function listForProduct(req: Request, res: Response, next: NextFunction) {
  try {
    const reviews = await prisma.review.findMany({
      where: { productId: req.params.id, status: 'approved' },
      orderBy: { createdAt: 'desc' },
      include: { reviewer: { select: { id: true, fullName: true, profileImageUrl: true } } },
    });
    return ok(res, reviews);
  } catch (e) { next(e); }
}
