import type { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/prisma';
import { ok, paginated } from '../utils/response';

export async function dashboardMetrics(_req: Request, res: Response, next: NextFunction) {
  try {
    const [users, sellers, listings, pending, orders, disputes] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { role: 'seller' } }),
      prisma.product.count(),
      prisma.product.count({ where: { moderationStatus: 'pending' } }),
      prisma.order.count(),
      prisma.dispute.count({ where: { status: { in: ['open', 'under_review'] } } }),
    ]);
    const gmvAgg = await prisma.order.aggregate({
      _sum: { totalAmount: true },
      where: { status: { in: ['paid', 'active', 'completed'] } },
    });
    return ok(res, {
      users,
      sellers,
      listings,
      pendingListings: pending,
      orders,
      openDisputes: disputes,
      gmv: gmvAgg._sum.totalAmount ?? 0,
    });
  } catch (e) { next(e); }
}

export async function listUsers(req: Request, res: Response, next: NextFunction) {
  try {
    const page = Number(req.query.page ?? 1);
    const pageSize = Math.min(50, Number(req.query.pageSize ?? 20));
    const [items, total] = await Promise.all([
      prisma.user.findMany({
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        select: {
          id: true, fullName: true, email: true, role: true, accountStatus: true,
          kycStatus: true, ratingAverage: true, reviewCount: true, createdAt: true,
        },
      }),
      prisma.user.count(),
    ]);
    return paginated(res, items, total, page, pageSize);
  } catch (e) { next(e); }
}

export async function moderateListing(req: Request, res: Response, next: NextFunction) {
  try {
    const { decision, reason } = req.body as { decision: 'approve' | 'reject'; reason?: string };
    const product = await prisma.product.update({
      where: { id: req.params.id },
      data: {
        moderationStatus: decision === 'approve' ? 'approved' : 'rejected',
        status: decision === 'approve' ? 'active' : 'rejected',
        rejectionReason: decision === 'reject' ? reason ?? null : null,
      },
    });
    return ok(res, product);
  } catch (e) { next(e); }
}

export async function suspendUser(req: Request, res: Response, next: NextFunction) {
  try {
    const { action } = req.body as { action: 'suspend' | 'activate' | 'ban' };
    const status = action === 'activate' ? 'active' : action === 'ban' ? 'banned' : 'suspended';
    const user = await prisma.user.update({
      where: { id: req.params.id },
      data: { accountStatus: status },
    });
    return ok(res, user);
  } catch (e) { next(e); }
}
