import type { Request, Response, NextFunction } from 'express';
import type { Prisma } from '@prisma/client';
import { prisma } from '../config/prisma';
import { ok, paginated } from '../utils/response';
import { BadRequestError, NotFoundError } from '../utils/errors';
import { releaseEscrow } from '../services/payment.service';
import { getDashboardAnalytics } from '../services/analytics.service';
import { analyticsQuerySchema, daysFromRange } from '../validators/analytics.validators';

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------

export async function dashboardMetrics(_req: Request, res: Response, next: NextFunction) {
  try {
    const [users, sellers, listings, pending, orders, disputes] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { role: 'seller' } }),
      prisma.product.count(),
      prisma.product.count({ where: { moderationStatus: 'pending' } }),
      prisma.order.count(),
      prisma.dispute.count({ where: { status: { in: ['open', 'under_review'] } } }),
    ]);
    const gmvAgg = await prisma.order.aggregate({
      _sum: { totalAmount: true },
      where: { status: { in: ['paid', 'active', 'completed'] } },
    });
    return ok(res, {
      users,
      sellers,
      listings,
      pendingListings: pending,
      orders,
      openDisputes: disputes,
      gmv: gmvAgg._sum.totalAmount ?? 0,
    });
  } catch (e) { next(e); }
}

/**
 * Time-series + rollup metrics for the admin dashboard.
 *
 * Query: `?range=7d|14d|30d|90d`  (default `14d`)
 *
 * Response includes:
 *   - `gmv`             day-bucketed sum of paid/active/completed order totals
 *   - `newUsers`        day-bucketed count of users created
 *   - `newListings`     day-bucketed count of products created
 *   - `orders`          day-bucketed count + `byStatus` breakdown
 *   - `paymentSuccessRate`, `refundRate`, `disputeRate`   percentages over the window
 *   - `topCategories`   top-5 categories by GMV in the window
 *   - each PeriodMetric carries a `delta` vs. the previous equal-length window
 *
 * Every series is zero-filled by Postgres via `generate_series`, so the
 * frontend can plot the response as-is.
 */
export async function analytics(req: Request, res: Response, next: NextFunction) {
  try {
    const parsed = analyticsQuerySchema.safeParse(req.query);
    if (!parsed.success) {
      // Silent fallback rather than 422 — bad query strings on a dashboard
      // URL shouldn't blank the page. Ops team will get whatever `14d`
      // returns.
      const data = await getDashboardAnalytics(daysFromRange('14d'));
      return ok(res, data);
    }
    const data = await getDashboardAnalytics(daysFromRange(parsed.data.range));
    return ok(res, data);
  } catch (e) { next(e); }
}

// ---------------------------------------------------------------------------
// Users
// ---------------------------------------------------------------------------

export async function listUsers(req: Request, res: Response, next: NextFunction) {
  try {
    const { page, pageSize, skip, take } = _paginate(req);
    const [items, total] = await Promise.all([
      prisma.user.findMany({
        orderBy: { createdAt: 'desc' },
        skip, take,
        select: {
          id: true, fullName: true, email: true, role: true, accountStatus: true,
          kycStatus: true, ratingAverage: true, reviewCount: true, createdAt: true,
        },
      }),
      prisma.user.count(),
    ]);
    return paginated(res, items, total, page, pageSize);
  } catch (e) { next(e); }
}

export async function suspendUser(req: Request, res: Response, next: NextFunction) {
  try {
    const { action } = req.body as { action: 'suspend' | 'activate' | 'ban' };
    if (!['suspend', 'activate', 'ban'].includes(action)) {
      throw new BadRequestError('Unknown action');
    }
    const status = action === 'activate' ? 'active' : action === 'ban' ? 'banned' : 'suspended';
    const user = await prisma.user.update({
      where: { id: req.params.id },
      data: { accountStatus: status },
    });
    return ok(res, user);
  } catch (e) { next(e); }
}

// ---------------------------------------------------------------------------
// Products (moderation queue)
// ---------------------------------------------------------------------------

export async function listAdminProducts(req: Request, res: Response, next: NextFunction) {
  try {
    const { page, pageSize, skip, take } = _paginate(req);

    // The admin panel wants to see EVERY listing, including rejected,
    // paused, archived. Unlike `/api/products` we do NOT filter on status
    // or moderationStatus by default.
    const moderationStatus = _enumParam(req.query.moderationStatus, ['pending', 'approved', 'rejected']);
    const status = _enumParam(req.query.status, ['draft', 'pending', 'active', 'rejected', 'paused', 'sold', 'archived']);
    const listingType = _enumParam(req.query.listingType, ['rent', 'sale', 'service', 'hybrid']);
    const keyword = _stringParam(req.query.keyword);

    const where: Prisma.ProductWhereInput = {
      ...(moderationStatus ? { moderationStatus } : {}),
      ...(status ? { status } : {}),
      ...(listingType ? { listingType } : {}),
      ...(keyword
        ? {
            OR: [
              { title: { contains: keyword, mode: 'insensitive' } },
              { description: { contains: keyword, mode: 'insensitive' } },
            ],
          }
        : {}),
    };

    const [items, total] = await Promise.all([
      prisma.product.findMany({
        where,
        include: {
          media: { orderBy: { sortOrder: 'asc' }, take: 1 },
          location: true,
          owner: { select: { id: true, fullName: true, email: true } },
          category: { select: { id: true, name: true, slug: true } },
        },
        // Oldest-pending-first so the moderation queue actually behaves
        // like a queue. For non-pending listings, newest first.
        orderBy:
          moderationStatus === 'pending'
            ? [{ createdAt: 'asc' }]
            : [{ createdAt: 'desc' }],
        skip, take,
      }),
      prisma.product.count({ where }),
    ]);
    return paginated(res, items, total, page, pageSize);
  } catch (e) { next(e); }
}

export async function moderateListing(req: Request, res: Response, next: NextFunction) {
  try {
    const { decision, reason } = req.body as { decision: 'approve' | 'reject'; reason?: string };
    if (decision !== 'approve' && decision !== 'reject') {
      throw new BadRequestError('decision must be "approve" or "reject"');
    }
    if (decision === 'reject' && !reason?.trim()) {
      throw new BadRequestError('A reason is required to reject a listing.');
    }

    const product = await prisma.product.update({
      where: { id: req.params.id },
      data: {
        moderationStatus: decision === 'approve' ? 'approved' : 'rejected',
        status: decision === 'approve' ? 'active' : 'rejected',
        rejectionReason: decision === 'reject' ? (reason ?? null) : null,
      },
    });
    return ok(res, product);
  } catch (e) { next(e); }
}

// ---------------------------------------------------------------------------
// Orders
// ---------------------------------------------------------------------------

/**
 * Paginated list of every order in the system, with buyer/seller/product
 * relations expanded. Powers `/dashboard/orders` in the admin panel.
 *
 * Optional filters:
 *   ?status=paid           — one of the OrderStatus enum values
 *   ?orderType=rental      — rental | purchase | service
 *   ?buyerId=<uuid>
 *   ?sellerId=<uuid>
 *   ?keyword=…             — matches on orderNumber prefix
 */
export async function listAdminOrders(req: Request, res: Response, next: NextFunction) {
  try {
    const { page, pageSize, skip, take } = _paginate(req);

    const status = _enumParam(req.query.status, [
      'pending', 'accepted', 'rejected', 'awaiting_payment', 'paid',
      'active', 'completed', 'cancelled', 'refunded', 'disputed',
    ]);
    const orderType = _enumParam(req.query.orderType, ['rental', 'purchase', 'service']);
    const buyerId = _uuidParam(req.query.buyerId);
    const sellerId = _uuidParam(req.query.sellerId);
    const keyword = _stringParam(req.query.keyword);

    const where: Prisma.OrderWhereInput = {
      ...(status ? { status } : {}),
      ...(orderType ? { orderType } : {}),
      ...(buyerId ? { buyerId } : {}),
      ...(sellerId ? { sellerId } : {}),
      ...(keyword ? { orderNumber: { contains: keyword, mode: 'insensitive' } } : {}),
    };

    const [items, total] = await Promise.all([
      prisma.order.findMany({
        where,
        include: {
          buyer: { select: { id: true, fullName: true, email: true } },
          seller: { select: { id: true, fullName: true, email: true } },
          product: { select: { id: true, title: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip, take,
      }),
      prisma.order.count({ where }),
    ]);
    return paginated(res, items, total, page, pageSize);
  } catch (e) { next(e); }
}

// ---------------------------------------------------------------------------
// Payments
// ---------------------------------------------------------------------------

/**
 * Paginated list of every Stripe/Razorpay payment. Powers the escrow-status
 * table in the admin panel — buyers who paid but whose funds are still
 * held, refunds in flight, etc.
 */
export async function listAdminPayments(req: Request, res: Response, next: NextFunction) {
  try {
    const { page, pageSize, skip, take } = _paginate(req);

    const status = _enumParam(req.query.status, [
      'created', 'authorized', 'captured', 'failed', 'refunded', 'partially_refunded',
    ]);
    const escrowStatus = _enumParam(req.query.escrowStatus, [
      'held', 'release_pending', 'released', 'refund_pending', 'refunded', 'disputed',
    ]);
    const provider = _enumParam(req.query.provider, ['stripe', 'razorpay']);

    const where: Prisma.PaymentWhereInput = {
      ...(status ? { status } : {}),
      ...(escrowStatus ? { escrowStatus } : {}),
      ...(provider ? { provider } : {}),
    };

    const [items, total] = await Promise.all([
      prisma.payment.findMany({
        where,
        include: {
          order: { select: { id: true, orderNumber: true, status: true } },
          payer: { select: { id: true, fullName: true, email: true } },
          seller: { select: { id: true, fullName: true, email: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip, take,
      }),
      prisma.payment.count({ where }),
    ]);
    return paginated(res, items, total, page, pageSize);
  } catch (e) { next(e); }
}

// ---------------------------------------------------------------------------
// Disputes
// ---------------------------------------------------------------------------

/**
 * Every dispute in the system. Called from the admin panel's dispute page,
 * which then splits them client-side into open vs closed sections.
 */
export async function listAdminDisputes(req: Request, res: Response, next: NextFunction) {
  try {
    const status = _enumParam(req.query.status, ['open', 'under_review', 'resolved', 'rejected']);

    const disputes = await prisma.dispute.findMany({
      where: status ? { status } : undefined,
      include: {
        order: {
          select: {
            id: true, orderNumber: true, totalAmount: true, currency: true, status: true,
          },
        },
        raisedByUser: { select: { id: true, fullName: true, email: true } },
        againstUser: { select: { id: true, fullName: true, email: true } },
      },
      // Open disputes go first, then most recently updated.
      orderBy: [{ status: 'asc' }, { updatedAt: 'desc' }],
      take: 200,
    });
    return ok(res, disputes);
  } catch (e) { next(e); }
}

/**
 * Resolve a dispute in favour of buyer or seller — or split it. This is the
 * top of the escrow refund/release funnel: the same call that closes the
 * dispute also flips the underlying order + payment into the right state.
 *
 * Body:
 *   {
 *     resolution: 'refund_buyer' | 'release_seller' | 'partial_refund' | 'reject',
 *     note: string,
 *     partialRefundAmount?: number   // required when resolution === 'partial_refund'
 *   }
 *
 * Side effects, per resolution:
 *   refund_buyer   → order.status = 'refunded', payment.escrowStatus = 'refunded'
 *   release_seller → order.status = 'completed', releaseEscrow() (captures + payout)
 *   partial_refund → order.status = 'refunded', payment.escrowStatus = 'refunded'
 *                    (partial-amount handling wired via Stripe's Refunds API is v1.1)
 *   reject         → dispute.status = 'rejected', order untouched
 */
export async function resolveDispute(req: Request, res: Response, next: NextFunction) {
  try {
    const { resolution, note, partialRefundAmount } = req.body as {
      resolution: 'refund_buyer' | 'release_seller' | 'partial_refund' | 'reject';
      note?: string;
      partialRefundAmount?: number;
    };

    if (!['refund_buyer', 'release_seller', 'partial_refund', 'reject'].includes(resolution)) {
      throw new BadRequestError('Unknown resolution');
    }
    if (resolution === 'partial_refund' && (!partialRefundAmount || partialRefundAmount <= 0)) {
      throw new BadRequestError('partialRefundAmount is required for partial_refund');
    }

    const dispute = await prisma.dispute.findUnique({
      where: { id: req.params.id },
      include: { order: true },
    });
    if (!dispute) throw new NotFoundError('Dispute not found');
    if (dispute.status === 'resolved' || dispute.status === 'rejected') {
      throw new BadRequestError('This dispute is already closed.');
    }

    // Perform every DB change in a single transaction so we can never leave
    // a dispute half-resolved. If the escrow release fails, the transaction
    // rolls back and the admin sees a 500 they can retry.
    const updated = await prisma.$transaction(async (tx) => {
      const resolutionText = [
        resolution === 'refund_buyer' && 'Refunded buyer in full.',
        resolution === 'release_seller' && 'Released funds to seller.',
        resolution === 'partial_refund' && `Partial refund of ${partialRefundAmount} to buyer.`,
        resolution === 'reject' && 'Dispute rejected as unfounded.',
        note ? `Note: ${note}` : null,
      ].filter(Boolean).join(' ');

      const nextDisputeStatus = resolution === 'reject' ? 'rejected' : 'resolved';

      const disputeAfter = await tx.dispute.update({
        where: { id: dispute.id },
        data: {
          status: nextDisputeStatus,
          resolution: resolutionText,
        },
      });

      if (resolution === 'refund_buyer' || resolution === 'partial_refund') {
        await tx.order.update({
          where: { id: dispute.orderId },
          data: { status: 'refunded' },
        });
        await tx.payment.updateMany({
          where: { orderId: dispute.orderId },
          data: {
            status: resolution === 'partial_refund' ? 'partially_refunded' : 'refunded',
            escrowStatus: 'refunded',
          },
        });
      } else if (resolution === 'release_seller') {
        await tx.order.update({
          where: { id: dispute.orderId },
          data: { status: 'completed' },
        });
        // The actual Stripe capture happens outside the transaction; see below.
      }

      return disputeAfter;
    });

    // Release escrow after the transaction so we don't hold a DB lock while
    // waiting on Stripe. Errors are logged (via releaseEscrow's internals)
    // but don't roll back the dispute resolution — a stuck payout is an
    // ops problem, not a "revert the admin's decision" problem.
    if (resolution === 'release_seller') {
      try {
        await releaseEscrow(dispute.orderId);
      } catch {
        // Swallow — dispute is already resolved, retry the release via a
        // manual "release escrow" admin action if it stays stuck.
      }
    }

    return ok(res, updated);
  } catch (e) { next(e); }
}

// ---------------------------------------------------------------------------
// Query-parsing helpers
//
// Small on purpose — Zod would be nicer, but query parsing is a hot path
// hit by every admin table load, and inline validators keep it fast and
// obvious. If the shape grows past 5-6 params per endpoint, switch to Zod
// and the `validate` middleware.
// ---------------------------------------------------------------------------

function _paginate(req: Request): { page: number; pageSize: number; skip: number; take: number } {
  const page = Math.max(1, Number(req.query.page ?? 1) || 1);
  const pageSize = Math.min(100, Math.max(1, Number(req.query.pageSize ?? 20) || 20));
  return { page, pageSize, skip: (page - 1) * pageSize, take: pageSize };
}

function _stringParam(v: unknown): string | undefined {
  if (typeof v !== 'string') return undefined;
  const t = v.trim();
  return t.length === 0 ? undefined : t;
}

function _enumParam<T extends string>(v: unknown, allowed: readonly T[]): T | undefined {
  if (typeof v !== 'string') return undefined;
  return (allowed as readonly string[]).includes(v) ? (v as T) : undefined;
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function _uuidParam(v: unknown): string | undefined {
  if (typeof v !== 'string') return undefined;
  return UUID_RE.test(v) ? v : undefined;
}
