import type { Request, Response, NextFunction } from 'express';
import * as orderService from '../services/order.service';
import * as paymentService from '../services/payment.service';
import { prisma } from '../config/prisma';
import { NotFoundError, ForbiddenError } from '../utils/errors';
import { ok, created } from '../utils/response';

export async function create(req: Request, res: Response, next: NextFunction) {
  try {
    const order = await orderService.createOrder({ ...req.body, buyerId: req.auth!.sub });
    return created(res, order);
  } catch (e) { next(e); }
}

export async function get(req: Request, res: Response, next: NextFunction) {
  try {
    const order = await prisma.order.findUnique({
      where: { id: req.params.id },
      include: {
        product: { include: { media: true, location: true } },
        buyer: { select: { id: true, fullName: true, profileImageUrl: true } },
        seller: { select: { id: true, fullName: true, profileImageUrl: true } },
        payments: true,
      },
    });
    if (!order) throw new NotFoundError('Order not found');
    if (order.buyerId !== req.auth!.sub && order.sellerId !== req.auth!.sub && req.auth!.role !== 'admin') {
      throw new ForbiddenError();
    }
    return ok(res, order);
  } catch (e) { next(e); }
}

export async function updateStatus(req: Request, res: Response, next: NextFunction) {
  try {
    const order = await orderService.updateOrderStatus(
      req.params.id,
      req.auth!.sub,
      req.auth!.role,
      req.body.status,
    );
    if (order.status === 'completed') {
      await paymentService.releaseEscrow(order.id).catch(() => undefined);
    }
    return ok(res, order);
  } catch (e) { next(e); }
}

export async function myBuyerOrders(req: Request, res: Response, next: NextFunction) {
  try {
    const list = await orderService.listMyOrders(req.auth!.sub, 'buyer');
    return ok(res, list);
  } catch (e) { next(e); }
}

export async function mySellerOrders(req: Request, res: Response, next: NextFunction) {
  try {
    const list = await orderService.listMyOrders(req.auth!.sub, 'seller');
    return ok(res, list);
  } catch (e) { next(e); }
}
