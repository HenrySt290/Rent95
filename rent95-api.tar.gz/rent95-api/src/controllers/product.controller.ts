import type { Request, Response, NextFunction } from 'express';
import * as productService from '../services/product.service';
import { prisma } from '../config/prisma';
import { ok, created, paginated } from '../utils/response';

export async function search(req: Request, res: Response, next: NextFunction) {
  try {
    const params = req.query as unknown as Parameters<typeof productService.searchProducts>[0];
    const { items, total, page, pageSize } = await productService.searchProducts(params);
    return paginated(res, items, total, page, pageSize);
  } catch (e) { next(e); }
}

export async function getById(req: Request, res: Response, next: NextFunction) {
  try {
    const product = await productService.getProduct(req.params.id);
    await prisma.product.update({ where: { id: product.id }, data: { viewCount: { increment: 1 } } });
    return ok(res, product);
  } catch (e) { next(e); }
}

export async function create(req: Request, res: Response, next: NextFunction) {
  try {
    const product = await productService.createProduct({ ...req.body, ownerId: req.auth!.sub });
    return created(res, product);
  } catch (e) { next(e); }
}

export async function update(req: Request, res: Response, next: NextFunction) {
  try {
    const product = await productService.updateProduct(req.params.id, req.auth!.sub, req.auth!.role, req.body);
    return ok(res, product);
  } catch (e) { next(e); }
}

export async function setStatus(req: Request, res: Response, next: NextFunction) {
  try {
    const product = await productService.setProductStatus(
      req.params.id,
      req.auth!.sub,
      req.auth!.role,
      req.body.status,
    );
    return ok(res, product);
  } catch (e) { next(e); }
}

export async function toggleFavorite(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await productService.toggleFavorite(req.auth!.sub, req.params.productId);
    return ok(res, result);
  } catch (e) { next(e); }
}

export async function listFavorites(req: Request, res: Response, next: NextFunction) {
  try {
    const list = await productService.listFavorites(req.auth!.sub);
    return ok(res, list);
  } catch (e) { next(e); }
}
