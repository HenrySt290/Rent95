import type { Request, Response, NextFunction } from 'express';
import * as paymentService from '../services/payment.service';
import { ok } from '../utils/response';

export async function createIntent(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await paymentService.createPaymentIntent(req.body.orderId, req.auth!.sub);
    return ok(res, result);
  } catch (e) { next(e); }
}

export async function stripeWebhook(req: Request, res: Response, next: NextFunction) {
  try {
    const signature = req.headers['stripe-signature'] as string;
    const result = await paymentService.handleStripeWebhook(req.body as Buffer, signature);
    return res.json(result);
  } catch (e) { next(e); }
}
