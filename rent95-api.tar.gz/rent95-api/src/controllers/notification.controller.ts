import type { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/prisma';
import { ok } from '../utils/response';
import { ForbiddenError, NotFoundError } from '../utils/errors';

/**
 * User-scoped notification inbox.
 *
 * The mobile app calls these endpoints from `ApiNotificationRepository`;
 * the socket layer separately pushes `notification_received` events into
 * the same list so the inbox stays live.
 *
 * All handlers scope by `req.auth.sub` — a user can never read or modify
 * another user's inbox even if they guess an id.
 */

export async function list(req: Request, res: Response, next: NextFunction) {
  try {
    const items = await prisma.notification.findMany({
      where: { userId: req.auth!.sub },
      orderBy: { createdAt: 'desc' },
      // Prevent unbounded inboxes from wedging the request. Older items
      // are still available via a future paginated endpoint if needed.
      take: 100,
    });
    return ok(res, items);
  } catch (e) { next(e); }
}

export async function markRead(req: Request, res: Response, next: NextFunction) {
  try {
    const notification = await prisma.notification.findUnique({
      where: { id: req.params.id },
    });
    if (!notification) throw new NotFoundError('Notification not found');
    // Ownership check — never trust the id alone.
    if (notification.userId !== req.auth!.sub) throw new ForbiddenError();

    await prisma.notification.update({
      where: { id: req.params.id },
      data: { isRead: true },
    });
    return ok(res, { success: true });
  } catch (e) { next(e); }
}

export async function markAllRead(req: Request, res: Response, next: NextFunction) {
  try {
    await prisma.notification.updateMany({
      where: { userId: req.auth!.sub, isRead: false },
      data: { isRead: true },
    });
    return ok(res, { success: true });
  } catch (e) { next(e); }
}

export async function remove(req: Request, res: Response, next: NextFunction) {
  try {
    const notification = await prisma.notification.findUnique({
      where: { id: req.params.id },
    });
    if (!notification) throw new NotFoundError('Notification not found');
    if (notification.userId !== req.auth!.sub) throw new ForbiddenError();

    await prisma.notification.delete({ where: { id: req.params.id } });
    return ok(res, { success: true });
  } catch (e) { next(e); }
}
