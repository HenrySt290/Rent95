import { z } from 'zod';

export const createOrderSchema = z.object({
  productId: z.string().uuid(),
  orderType: z.enum(['rental', 'purchase', 'service']),
  quantity: z.number().int().positive().optional(),
  startDatetime: z.coerce.date().optional(),
  endDatetime: z.coerce.date().optional(),
  deliveryMethod: z.enum(['pickup', 'delivery', 'shipping', 'on_site']).optional(),
  deliveryAddress: z.record(z.any()).optional(),
});

export const orderStatusSchema = z.object({
  status: z.enum(['accepted', 'rejected', 'cancelled', 'active', 'completed']),
});

export const createReviewSchema = z.object({
  orderId: z.string().uuid(),
  rating: z.number().int().min(1).max(5),
  comment: z.string().max(2000).optional(),
  mediaUrls: z.array(z.string().url()).max(5).optional(),
});

export const sendMessageSchema = z.object({
  content: z.string().min(1).max(4000).optional(),
  mediaUrl: z.string().url().optional(),
  type: z.enum(['text', 'image', 'file']).default('text'),
}).refine((v) => !!v.content || !!v.mediaUrl, { message: 'content or mediaUrl is required' });

export const createConversationSchema = z.object({
  productId: z.string().uuid().optional(),
  orderId: z.string().uuid().optional(),
  sellerId: z.string().uuid(),
});
