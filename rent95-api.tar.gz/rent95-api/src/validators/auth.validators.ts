import { z } from 'zod';

export const registerSchema = z.object({
  fullName: z.string().min(2).max(150),
  email: z.string().email().max(255),
  phone: z.string().min(6).max(30).optional(),
  password: z.string().min(8).max(200),
  role: z.enum(['buyer', 'seller']).optional(),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export const refreshSchema = z.object({
  refreshToken: z.string().min(10),
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8).max(200),
});
