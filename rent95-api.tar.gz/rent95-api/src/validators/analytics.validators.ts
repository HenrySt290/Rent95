import { z } from 'zod';

/**
 * `?range=14d` — the number of days to include, ending at "now". We support
 * a handful of preset windows plus a custom `?from=&to=` pair.
 *
 * Kept as an enum of strings rather than a raw number so we can accept
 * "3mo" without wiring calendar-month math later. For MVP everything just
 * resolves to a day count.
 */
export const analyticsQuerySchema = z.object({
  range: z
    .enum(['7d', '14d', '30d', '90d'])
    .default('14d'),
});

export type AnalyticsQuery = z.infer<typeof analyticsQuerySchema>;

/**
 * Convert `range` to a concrete day count. Adding a new preset means adding
 * the string above and one line here.
 */
export function daysFromRange(range: AnalyticsQuery['range']): number {
  switch (range) {
    case '7d':
      return 7;
    case '14d':
      return 14;
    case '30d':
      return 30;
    case '90d':
      return 90;
  }
}
