import { z } from 'zod';

export const productSearchSchema = z.object({
  keyword: z.string().max(200).optional(),
  categoryId: z.string().uuid().optional(),
  listingType: z.enum(['rent', 'sale', 'service', 'hybrid']).optional(),
  minPrice: z.coerce.number().nonnegative().optional(),
  maxPrice: z.coerce.number().nonnegative().optional(),
  city: z.string().max(120).optional(),
  sort: z.enum(['relevance', 'newest', 'price_asc', 'price_desc', 'rating']).optional(),
  page: z.coerce.number().int().positive().optional(),
  pageSize: z.coerce.number().int().positive().max(50).optional(),
});

export const locationSchema = z.object({
  address: z.string().min(1),
  city: z.string().min(1),
  state: z.string().optional(),
  country: z.string().min(1),
  postalCode: z.string().optional(),
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
});

export const createProductSchema = z.object({
  title: z.string().min(3).max(180),
  description: z.string().min(10),
  categoryId: z.string().uuid(),
  subcategoryId: z.string().uuid().optional(),
  listingType: z.enum(['rent', 'sale', 'service', 'hybrid']),
  price: z.number().positive(),
  priceUnit: z.enum(['hour', 'day', 'week', 'month', 'fixed']),
  securityDeposit: z.number().nonnegative().optional(),
  currency: z.string().min(3).max(10),
  quantity: z.number().int().positive().max(9999),
  condition: z.enum(['new_item', 'like_new', 'good', 'fair', 'used']).optional(),
  customAttributes: z.record(z.any()).optional(),
  deliveryOptions: z.array(z.string()).optional(),
  images: z.array(z.string().url()).max(8).optional(),
  location: locationSchema,
});

export const updateProductSchema = createProductSchema.partial();

export const idParamSchema = z.object({ id: z.string().uuid() });
