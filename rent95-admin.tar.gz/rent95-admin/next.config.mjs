/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Build a self-contained server bundle in .next/standalone. Trims the
  // production Docker image from ~1 GB to ~150 MB by dropping unused
  // node_modules. See Dockerfile for how we consume it.
  output: 'standalone',
  images: { unoptimized: true },
  env: {
    NEXT_PUBLIC_API_URL: process.env.API_URL || 'http://localhost:4000',
  },
  // Standalone build needs to know the project root when the repo lives
  // in a monorepo — safe to set unconditionally.
  outputFileTracingRoot: process.cwd(),
};

export default nextConfig;
