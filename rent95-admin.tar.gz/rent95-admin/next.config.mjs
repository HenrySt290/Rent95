/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Admin traffic is low volume; we don't need the image optimizer complexity.
  images: { unoptimized: true },
  // Expose the API URL so client-side rendering can hit it too.
  env: {
    NEXT_PUBLIC_API_URL: process.env.API_URL || 'http://localhost:4000',
  },
};

export default nextConfig;
