'use client';

import { ChevronLeft, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';

export function Pagination({
  page,
  totalPages,
  total,
}: {
  page: number;
  totalPages: number;
  total: number;
}) {
  const pathname = usePathname();
  const params = useSearchParams();

  const link = (p: number) => {
    const sp = new URLSearchParams(params);
    sp.set('page', String(p));
    return `${pathname}?${sp.toString()}`;
  };

  const canPrev = page > 1;
  const canNext = page < totalPages;

  return (
    <div className="flex items-center justify-between px-4 py-3">
      <p className="text-sm text-ink-muted">
        Showing page {page} of {totalPages} ({total} total)
      </p>
      <div className="flex items-center gap-2">
        {canPrev ? (
          <Link href={link(page - 1)} className="btn-outline">
            <ChevronLeft size={16} /> Prev
          </Link>
        ) : (
          <button className="btn-outline" disabled>
            <ChevronLeft size={16} /> Prev
          </button>
        )}
        {canNext ? (
          <Link href={link(page + 1)} className="btn-outline">
            Next <ChevronRight size={16} />
          </Link>
        ) : (
          <button className="btn-outline" disabled>
            Next <ChevronRight size={16} />
          </button>
        )}
      </div>
    </div>
  );
}
