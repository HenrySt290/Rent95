import { ArrowDown, ArrowUp, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';

export function Card({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return <div className={cn('card p-5', className)}>{children}</div>;
}

export function StatCard({
  label,
  value,
  hint,
  icon,
  intent = 'primary',
  delta,
}: {
  label: string;
  value: string;
  hint?: string;
  icon?: React.ReactNode;
  intent?: 'primary' | 'success' | 'warning' | 'danger';
  delta?: { percent: number; vs: 'previous_period' } | null;
}) {
  const iconBg = {
    primary: 'bg-primary/10 text-primary',
    success: 'bg-success/10 text-success',
    warning: 'bg-warning/10 text-warning',
    danger: 'bg-danger/10 text-danger',
  }[intent];

  return (
    <div className="card p-5 flex items-start gap-4">
      {icon && (
        <div className={cn('h-10 w-10 rounded-lg grid place-items-center shrink-0', iconBg)}>
          {icon}
        </div>
      )}
      <div className="min-w-0 flex-1">
        <p className="text-sm text-ink-muted">{label}</p>
        <div className="flex items-baseline gap-2 mt-0.5">
          <p className="text-2xl font-bold tracking-tight truncate">{value}</p>
          {delta && <DeltaChip percent={delta.percent} />}
        </div>
        {hint && <p className="text-xs text-ink-muted mt-0.5">{hint}</p>}
      </div>
    </div>
  );
}

/**
 * Small pill showing "▲ 12.4%" / "▼ 3.1%" — colours flip on sign.
 *
 * We render "—" for exactly-zero deltas because "0%" isn't quite right
 * (the value could be identical, or the two windows could just both have
 * been zero and cancelled out).
 */
function DeltaChip({ percent }: { percent: number }) {
  const up = percent > 0;
  const flat = percent === 0;
  const cls = flat
    ? 'text-ink-muted bg-ink/5'
    : up
      ? 'text-success bg-success/10'
      : 'text-danger bg-danger/10';
  const Icon = flat ? Minus : up ? ArrowUp : ArrowDown;
  return (
    <span
      className={cn('inline-flex items-center gap-0.5 rounded-full px-1.5 py-0.5 text-[10px] font-semibold', cls)}
    >
      <Icon size={10} />
      {flat ? '—' : `${Math.abs(percent).toFixed(1)}%`}
    </span>
  );
}
