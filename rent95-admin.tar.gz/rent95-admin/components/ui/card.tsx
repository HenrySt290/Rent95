import { cn } from '@/lib/utils';

export function Card({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return <div className={cn('card p-5', className)}>{children}</div>;
}

export function StatCard({
  label,
  value,
  hint,
  icon,
  intent = 'primary',
}: {
  label: string;
  value: string;
  hint?: string;
  icon?: React.ReactNode;
  intent?: 'primary' | 'success' | 'warning' | 'danger';
}) {
  const iconBg = {
    primary: 'bg-primary/10 text-primary',
    success: 'bg-success/10 text-success',
    warning: 'bg-warning/10 text-warning',
    danger: 'bg-danger/10 text-danger',
  }[intent];

  return (
    <div className="card p-5 flex items-start gap-4">
      {icon && (
        <div className={cn('h-10 w-10 rounded-lg grid place-items-center shrink-0', iconBg)}>
          {icon}
        </div>
      )}
      <div className="min-w-0">
        <p className="text-sm text-ink-muted">{label}</p>
        <p className="text-2xl font-bold tracking-tight mt-0.5 truncate">{value}</p>
        {hint && <p className="text-xs text-ink-muted mt-0.5">{hint}</p>}
      </div>
    </div>
  );
}
