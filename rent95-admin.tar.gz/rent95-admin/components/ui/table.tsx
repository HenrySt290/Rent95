import { cn } from '@/lib/utils';

export function Table({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('card overflow-hidden', className)}>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">{children}</table>
      </div>
    </div>
  );
}

export function TH({ children, className }: { children?: React.ReactNode; className?: string }) {
  return (
    <th
      className={cn(
        'text-left px-4 py-3 text-xs font-semibold uppercase tracking-wide text-ink-muted bg-surface border-b border-border',
        className,
      )}
    >
      {children}
    </th>
  );
}

export function TD({ children, className }: { children?: React.ReactNode; className?: string }) {
  return <td className={cn('px-4 py-3 border-b border-border/70 align-middle', className)}>{children}</td>;
}

export function TR({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return <tr className={cn('hover:bg-surface/60 transition-colors', className)}>{children}</tr>;
}

export function EmptyState({ message = 'Nothing to show yet.' }: { message?: string }) {
  return (
    <tr>
      <td colSpan={99} className="px-4 py-16 text-center text-ink-muted">
        {message}
      </td>
    </tr>
  );
}
