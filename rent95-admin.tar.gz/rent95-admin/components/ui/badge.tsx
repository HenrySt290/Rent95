import { cn } from '@/lib/utils';

type Variant = 'primary' | 'success' | 'warning' | 'danger' | 'neutral';

const VARIANT_CLASS: Record<Variant, string> = {
  primary: 'badge-primary',
  success: 'badge-success',
  warning: 'badge-warning',
  danger: 'badge-danger',
  neutral: 'badge-neutral',
};

export function Badge({
  variant = 'neutral',
  children,
  className,
}: {
  variant?: Variant;
  children: React.ReactNode;
  className?: string;
}) {
  return <span className={cn(VARIANT_CLASS[variant], className)}>{children}</span>;
}

/**
 * Maps arbitrary backend status strings (order/listing/payment/dispute)
 * to a consistent visual variant. Kept in one file so we can't have a
 * dispute be "success"-green in one screen and "danger"-red in another.
 */
export function statusVariant(status: string): Variant {
  switch (status) {
    case 'active':
    case 'paid':
    case 'completed':
    case 'approved':
    case 'released':
    case 'captured':
    case 'resolved':
      return 'success';
    case 'pending':
    case 'awaiting_payment':
    case 'under_review':
    case 'release_pending':
    case 'authorized':
    case 'held':
      return 'warning';
    case 'rejected':
    case 'cancelled':
    case 'failed':
    case 'refunded':
    case 'disputed':
    case 'banned':
    case 'suspended':
      return 'danger';
    case 'draft':
    case 'archived':
    case 'paused':
    case 'not_submitted':
      return 'neutral';
    default:
      return 'primary';
  }
}
