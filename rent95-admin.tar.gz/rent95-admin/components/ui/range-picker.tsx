import Link from 'next/link';
import { cn } from '@/lib/utils';

const OPTIONS = ['7d', '14d', '30d', '90d'] as const;

/**
 * Server-rendered range picker. Uses a `<Link>` per option so the URL is
 * shareable — anyone with the link sees the same window. Also means the
 * data fetch happens as part of the normal server-render, no client state.
 */
export function RangePicker({ selected }: { selected: string }) {
  return (
    <div className="inline-flex rounded-lg border border-border bg-white p-1 shadow-card">
      {OPTIONS.map((opt) => (
        <Link
          key={opt}
          href={`/dashboard?range=${opt}`}
          className={cn(
            'px-3 py-1.5 text-xs font-medium rounded-md transition-colors',
            selected === opt
              ? 'bg-primary text-white'
              : 'text-ink-muted hover:text-ink hover:bg-surface',
          )}
        >
          {opt}
        </Link>
      ))}
    </div>
  );
}
