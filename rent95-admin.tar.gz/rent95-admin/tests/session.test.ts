/**
 * Unit tests for the AES-256-GCM admin session cookie.
 *
 * The threat model these tests defend:
 *   1. Attacker plants a cookie without knowing ADMIN_SESSION_SECRET.
 *   2. Attacker modifies an intercepted cookie (bit-flip, byte swap,
 *      segment truncation).
 *   3. Attacker crafts a syntactically-valid but old/expired cookie.
 *   4. Operator rotates the secret (all in-flight sessions must fail cleanly).
 *
 * Every assertion below either:
 *   - Verifies the happy path (encrypt → decrypt round-trips).
 *   - Verifies that tampering produces `null`, NEVER a partial or spoofed
 *     Session object.
 *
 * We test the underscore-prefixed `_encryptSession` / `_decryptSession`
 * primitives directly. That skirts `next/headers.cookies()` which needs
 * a Next runtime — the ciphertext logic is the same code path
 * writeSession/readSession use.
 */

import { describe, expect, it } from 'vitest';

import {
  SESSION_MAX_AGE_SECONDS,
  _decryptSession,
  _encryptSession,
  type Session,
} from '@/lib/session';

// A shape we can reuse across the suite.
function sample(overrides: Partial<Session> = {}): Session {
  return {
    accessToken: 'access-token-XYZ',
    userId: 'usr_abc123',
    role: 'admin',
    email: 'admin@rent95.dev',
    fullName: 'Rent95 Admin',
    iat: Date.now(),
    ...overrides,
  };
}

// -----------------------------------------------------------------------------

describe('Session cookie — happy path', () => {
  it('round-trips a valid session', () => {
    const original = sample();
    const wire = _encryptSession(original);
    const back = _decryptSession(wire);
    expect(back).not.toBeNull();
    expect(back!.userId).toBe(original.userId);
    expect(back!.role).toBe(original.role);
    expect(back!.email).toBe(original.email);
    expect(back!.accessToken).toBe(original.accessToken);
  });

  it('emits three base64url segments separated by dots', () => {
    const wire = _encryptSession(sample());
    const parts = wire.split('.');
    expect(parts).toHaveLength(3);
    for (const p of parts) {
      // base64url alphabet only — never padding, never plus/slash.
      expect(p).toMatch(/^[A-Za-z0-9_-]+$/);
    }
  });

  it('produces a different ciphertext for the same payload on each call (fresh IV)', () => {
    // AES-GCM without a unique IV per encryption is catastrophically broken.
    // We assert here that two consecutive encrypts of identical payloads
    // yield different wire strings — proves randomBytes(iv) is on.
    const p = sample();
    const a = _encryptSession(p);
    const b = _encryptSession(p);
    expect(a).not.toBe(b);

    // Both must still decrypt to the same logical session.
    expect(_decryptSession(a)!.userId).toBe(p.userId);
    expect(_decryptSession(b)!.userId).toBe(p.userId);
  });
});

// -----------------------------------------------------------------------------

describe('Session cookie — tamper resistance (GCM auth tag)', () => {
  it('rejects a cookie with a single flipped bit in the auth tag', () => {
    const wire = _encryptSession(sample());
    const parts = wire.split('.');
    const tampered = flipFirstByteBase64Url(parts[2]);
    // Sanity check we actually mutated the segment.
    expect(tampered).not.toBe(parts[2]);
    const bad = [parts[0], parts[1], tampered].join('.');
    expect(_decryptSession(bad)).toBeNull();
  });

  it('rejects a cookie with tampered ciphertext', () => {
    const wire = _encryptSession(sample());
    const parts = wire.split('.');
    const badBody = flipFirstByteBase64Url(parts[1]);
    const bad = [parts[0], badBody, parts[2]].join('.');
    expect(_decryptSession(bad)).toBeNull();
  });

  it('rejects a cookie with a tampered IV', () => {
    // GCM will produce different plaintext with a different IV; the tag
    // validation catches it.
    const wire = _encryptSession(sample());
    const parts = wire.split('.');
    const badIv = flipFirstByteBase64Url(parts[0]);
    const bad = [badIv, parts[1], parts[2]].join('.');
    expect(_decryptSession(bad)).toBeNull();
  });

  it('rejects a truncated cookie (only 2 segments)', () => {
    const wire = _encryptSession(sample());
    const parts = wire.split('.');
    expect(_decryptSession(`${parts[0]}.${parts[1]}`)).toBeNull();
  });

  it('rejects a garbage cookie value', () => {
    expect(_decryptSession('not-a-cookie')).toBeNull();
    expect(_decryptSession('....')).toBeNull();
    expect(_decryptSession('')).toBeNull();
    // Structurally three segments but base64 nonsense.
    expect(_decryptSession('AAA.BBB.CCC')).toBeNull();
  });

  it('rejects a cookie signed with a DIFFERENT secret', async () => {
    // Encrypt under our test secret …
    const wire = _encryptSession(sample());

    // Then reimport the session module under a different secret and try
    // to decrypt. Fresh Vitest module cache guarantees the SECRET/KEY
    // constants are re-derived from process.env.
    const originalSecret = process.env.ADMIN_SESSION_SECRET;
    process.env.ADMIN_SESSION_SECRET =
      'a-completely-different-secret-that-is-32-chars-long';
    let decryptedUnderWrongKey: Session | null = null;
    try {
      // vitest.resetModules() is scoped to `vi` inside dynamic import.
      const { vi } = await import('vitest');
      vi.resetModules();
      const other = await import('@/lib/session');
      decryptedUnderWrongKey = other._decryptSession(wire);
    } finally {
      process.env.ADMIN_SESSION_SECRET = originalSecret;
      const { vi } = await import('vitest');
      vi.resetModules();
    }

    expect(decryptedUnderWrongKey).toBeNull();
  });
});

// -----------------------------------------------------------------------------

describe('Session cookie — staleness guard', () => {
  it('accepts a session with a fresh iat', () => {
    const wire = _encryptSession(sample({ iat: Date.now() - 1000 }));
    expect(_decryptSession(wire)).not.toBeNull();
  });

  it('rejects a session whose iat is older than SESSION_MAX_AGE_SECONDS', () => {
    // Craft a payload that is a signed valid GCM cookie but with an
    // artificially-old iat. The point: even if browser Max-Age was
    // bypassed (say by copying the raw cookie to a fresh browser),
    // server-side check refuses it.
    const staleIat = Date.now() - (SESSION_MAX_AGE_SECONDS + 60) * 1000;
    const wire = _encryptSession(sample({ iat: staleIat }));
    expect(_decryptSession(wire)).toBeNull();
  });
});

// -----------------------------------------------------------------------------
// Helpers
// -----------------------------------------------------------------------------

/**
 * Flip the low bit of the first byte of a base64url-encoded segment.
 * Returns a new base64url string of the same length. Used to prove GCM
 * catches single-bit tampering.
 */
function flipFirstByteBase64Url(segment: string): string {
  const raw = Buffer.from(segment, 'base64url');
  if (raw.length === 0) return segment;
  // Flip low bit of byte 0 — smallest possible perturbation.
  raw[0] = raw[0] ^ 0x01;
  return raw.toString('base64url');
}
