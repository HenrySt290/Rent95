/**
 * Global test setup. Runs BEFORE any test file imports lib/ or components/.
 *
 * We set ADMIN_SESSION_SECRET here — session.ts throws at import time if
 * this isn't present (that's the security-audit boot guard). Any test that
 * imports lib/session.ts would otherwise crash the whole run.
 */

// A deterministic, spec-compliant test secret. Never used in production.
process.env.ADMIN_SESSION_SECRET =
  'test-admin-session-secret-0123456789abcdef0123456789abcdef';

// `server-only` is a Next.js poison-pill module that throws in client
// bundles. Vitest running node-side loads it fine, but its own tests
// occasionally trip over it — patch it into a no-op so lib/session.ts
// imports cleanly.
import { vi } from 'vitest';
vi.mock('server-only', () => ({}));
