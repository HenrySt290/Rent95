/**
 * Session cookie constants shared between:
 *   - middleware.ts (Edge runtime — no Node APIs)
 *   - lib/session.ts (Node runtime — signs / verifies)
 *
 * Constants only. NO Node crypto, NO env reads, NO server-only.
 */

/**
 * `__Host-` prefix locks the cookie to secure=true + path=/ + no Domain,
 * per RFC 6265bis §4.1.3.2. Prevents subdomain cookie shadowing.
 */
export const SESSION_COOKIE = '__Host-rent95_admin_session';

/** Roles allowed into the admin panel at all. */
export const ADMIN_ROLES = ['admin', 'moderator', 'support'] as const;
export type AdminRole = (typeof ADMIN_ROLES)[number];
