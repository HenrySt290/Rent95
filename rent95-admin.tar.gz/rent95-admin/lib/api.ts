/**
 * Thin server-side fetch helper for talking to `rent95-api`.
 *
 * Used from:
 *   - Server Components (fetching on render)
 *   - Route Handlers (proxying admin actions)
 *
 * NOT for the browser — client components should call server actions or
 * route handlers instead, so the bearer token stays server-side.
 */

import { cookies } from 'next/headers';
import { SESSION_COOKIE } from './session';

const API_URL = process.env.API_URL ?? 'http://localhost:4000';

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public body?: unknown,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

type FetchOptions = {
  method?: string;
  body?: unknown;
  /**
   * Cache policy — Next.js default is aggressive caching. For admin data we
   * usually want fresh, so callers explicitly pass `noStore: true` on read
   * endpoints backing an admin table.
   */
  noStore?: boolean;
  /** Extra headers to send. Auth header is attached automatically. */
  headers?: Record<string, string>;
  /** For write operations that MUST NOT duplicate on retry. */
  idempotencyKey?: string;
};

async function readToken(): Promise<string | null> {
  // `cookies()` is async in Next 15.
  const jar = await cookies();
  const raw = jar.get(SESSION_COOKIE)?.value;
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as { accessToken?: string };
    return parsed.accessToken ?? null;
  } catch {
    return null;
  }
}

export async function api<T>(path: string, opts: FetchOptions = {}): Promise<T> {
  const token = await readToken();
  const headers: Record<string, string> = {
    Accept: 'application/json',
    ...(opts.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(opts.idempotencyKey ? { 'Idempotency-Key': opts.idempotencyKey } : {}),
    ...opts.headers,
  };

  const res = await fetch(`${API_URL}${path}`, {
    method: opts.method ?? 'GET',
    headers,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    // Next 15: opt out of the router cache for admin data by default.
    cache: opts.noStore === false ? 'default' : 'no-store',
  });

  if (!res.ok) {
    let bodyJson: unknown = null;
    try {
      bodyJson = await res.json();
    } catch {
      /* not JSON */
    }
    const message =
      (bodyJson as { message?: string } | null)?.message ??
      `Request failed with ${res.status}`;
    throw new ApiError(res.status, message, bodyJson);
  }

  // Some DELETE/PATCH endpoints return no body.
  const text = await res.text();
  if (!text) return undefined as T;

  const parsed = JSON.parse(text) as { data?: T } | T;
  // Backend envelopes as { success, data }; unwrap if present.
  if (
    typeof parsed === 'object' &&
    parsed !== null &&
    'data' in (parsed as Record<string, unknown>)
  ) {
    return (parsed as { data: T }).data;
  }
  return parsed as T;
}

/**
 * Same as `api` but returns the raw envelope, so callers can access
 * `pagination` alongside `data`.
 */
export async function apiEnvelope<T>(
  path: string,
  opts: FetchOptions = {},
): Promise<{ data: T; pagination?: { total: number; page: number; pageSize: number; totalPages: number } }> {
  const raw = await api<{ data: T; pagination?: Record<string, number> } | T>(path, opts);
  if (raw && typeof raw === 'object' && 'data' in (raw as Record<string, unknown>)) {
    return raw as { data: T; pagination?: { total: number; page: number; pageSize: number; totalPages: number } };
  }
  return { data: raw as T };
}
