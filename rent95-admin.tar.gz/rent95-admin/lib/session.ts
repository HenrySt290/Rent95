import { cookies } from 'next/headers';

/**
 * We persist the JWT the admin got from POST /api/auth/login in an
 * HttpOnly cookie so it never touches JS. The Node process reads it out
 * of `cookies()` and forwards it as a Bearer token to `rent95-api`.
 *
 * We deliberately DO NOT verify the JWT signature locally — we don't have
 * the secret in the admin process and re-verifying would add zero security
 * (the backend still authenticates every request). Instead we trust the
 * cookie's authenticity because it's:
 *   - httpOnly    (JS can't tamper with it)
 *   - secure      (in production, only over HTTPS)
 *   - sameSite=lax (no CSRF from other origins)
 */

export const SESSION_COOKIE = 'rent95_admin_session';

// Sixty days — matches the refresh token TTL server-side, so the cookie
// stops working around the same time the refresh does.
export const SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 60;

export type Session = {
  accessToken: string;
  refreshToken: string;
  userId: string;
  role: 'admin' | 'moderator' | 'support';
  email: string;
  fullName: string;
};

export async function readSession(): Promise<Session | null> {
  const jar = await cookies();
  const raw = jar.get(SESSION_COOKIE)?.value;
  if (!raw) return null;
  try {
    return JSON.parse(raw) as Session;
  } catch {
    return null;
  }
}

/**
 * Server-action only — the Next.js docs are explicit that setting cookies
 * from a plain Route Handler is fine, but a Server Component can't. Login
 * uses a Server Action so it's allowed to set/clear the cookie.
 */
export async function writeSession(session: Session): Promise<void> {
  const jar = await cookies();
  jar.set({
    name: SESSION_COOKIE,
    value: JSON.stringify(session),
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: SESSION_MAX_AGE_SECONDS,
  });
}

export async function clearSession(): Promise<void> {
  const jar = await cookies();
  jar.set({
    name: SESSION_COOKIE,
    value: '',
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 0,
  });
}

/** Roles allowed into the admin panel at all. */
export const ADMIN_ROLES: Session['role'][] = ['admin', 'moderator', 'support'];

/**
 * True if the session's role can perform the given capability.
 *
 * We keep this as a lookup table (not per-role classes) because admin
 * capabilities are cross-cutting: a moderator can approve listings but not
 * refund payments; a support agent can read everything but suspend nobody.
 */
export function can(session: Session | null, capability: Capability): boolean {
  if (!session) return false;
  return CAPABILITY_MATRIX[capability].includes(session.role);
}

export type Capability =
  | 'view_dashboard'
  | 'view_users'
  | 'suspend_user'
  | 'view_listings'
  | 'moderate_listing'
  | 'view_orders'
  | 'view_payments'
  | 'refund_payment'
  | 'view_disputes'
  | 'resolve_dispute'
  | 'manage_categories';

const CAPABILITY_MATRIX: Record<Capability, Session['role'][]> = {
  view_dashboard: ['admin', 'moderator', 'support'],
  view_users: ['admin', 'moderator', 'support'],
  suspend_user: ['admin'],
  view_listings: ['admin', 'moderator', 'support'],
  moderate_listing: ['admin', 'moderator'],
  view_orders: ['admin', 'moderator', 'support'],
  view_payments: ['admin'],
  refund_payment: ['admin'],
  view_disputes: ['admin', 'moderator', 'support'],
  resolve_dispute: ['admin', 'moderator'],
  manage_categories: ['admin'],
};
