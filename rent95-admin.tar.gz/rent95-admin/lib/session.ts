import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
} from 'node:crypto';
import { cookies } from 'next/headers';

import 'server-only';

import {
  ADMIN_ROLES as _ADMIN_ROLES,
  SESSION_COOKIE as _SESSION_COOKIE,
  type AdminRole,
} from './session-shared';

export const SESSION_COOKIE = _SESSION_COOKIE;
export const ADMIN_ROLES: AdminRole[] = [..._ADMIN_ROLES];

/**
 * Admin session — AES-256-GCM encrypted, HttpOnly, `__Host-` prefixed,
 * SameSite=Strict, Partitioned. See docs/SECURITY_AUDIT.md.
 *
 * ### Wire format
 *
 *   `<b64url(iv)>.<b64url(ciphertext)>.<b64url(authTag)>`
 *
 *   - iv        — 12 random bytes per write (GCM standard).
 *   - ciphertext — AES-256-GCM output over the JSON payload.
 *   - authTag   — 16-byte GCM authentication tag.
 *
 * Any tampering with any segment triggers a GCM auth-tag mismatch inside
 * `decipher.final()`, which throws. `readSession()` returns `null` on
 * any decrypt or shape-validation failure — never partial / corrupted
 * memory.
 *
 * ### Key derivation
 *
 * GCM requires exactly 32 bytes of key material. We derive it deterministically
 * with SHA-256 over `ADMIN_SESSION_SECRET`, so the operator can supply a
 * human-typed 32+ char secret (matching `env.ts` on the API side) and the
 * runtime handles the byte-length conversion.
 */

const SECRET = process.env.ADMIN_SESSION_SECRET;
if (!SECRET || SECRET.length < 32) {
  throw new Error(
    'ADMIN_SESSION_SECRET must be set to a ≥32 char random string. ' +
      'Generate with `openssl rand -hex 32`.',
  );
}
const KEY: Buffer = createHash('sha256').update(SECRET).digest();

// 60 days matches refresh-token TTL server-side.
export const SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 60;

export type Session = {
  accessToken: string;
  userId: string;
  role: AdminRole;
  email: string;
  fullName: string;
  /** Issued-at (ms). Belt-and-braces vs browser Max-Age. */
  iat: number;
};

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export async function readSession(): Promise<Session | null> {
  const jar = await cookies();
  const raw = jar.get(SESSION_COOKIE)?.value;
  if (!raw) return null;
  return _decryptSession(raw);
}

export async function writeSession(session: Omit<Session, 'iat'>): Promise<void> {
  const payload: Session = { ...session, iat: Date.now() };
  const cookieValue = _encryptSession(payload);
  const jar = await cookies();
  jar.set({
    name: SESSION_COOKIE,
    value: cookieValue,
    httpOnly: true,
    secure: true, // hard-locked; __Host- prefix requires it
    sameSite: 'strict',
    path: '/',
    maxAge: SESSION_MAX_AGE_SECONDS,
    // Chrome CHIPS: opt into partitioned cookies for third-party contexts.
    // @ts-expect-error - `partitioned` not yet in Next's cookie type defs
    partitioned: true,
  });
}

export async function clearSession(): Promise<void> {
  const jar = await cookies();
  jar.set({
    name: SESSION_COOKIE,
    value: '',
    httpOnly: true,
    secure: true,
    sameSite: 'strict',
    path: '/',
    maxAge: 0,
    // @ts-expect-error - see writeSession above
    partitioned: true,
  });
}

// ---------------------------------------------------------------------------
// Cipher primitives
//
// Encrypt/decrypt are exported for test purposes ONLY; consumers must go
// through readSession/writeSession so we can't accidentally forget to
// wrap with the cookies() jar.
// ---------------------------------------------------------------------------

export function _encryptSession(payload: Session): string {
  const plaintext = Buffer.from(JSON.stringify(payload), 'utf-8');
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', KEY, iv);
  const ct = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const authTag = cipher.getAuthTag(); // 16 bytes
  return [
    iv.toString('base64url'),
    ct.toString('base64url'),
    authTag.toString('base64url'),
  ].join('.');
}

export function _decryptSession(raw: string): Session | null {
  const parts = raw.split('.');
  if (parts.length !== 3) return null;
  try {
    const iv = Buffer.from(parts[0], 'base64url');
    const ciphertext = Buffer.from(parts[1], 'base64url');
    const authTag = Buffer.from(parts[2], 'base64url');
    // GCM contract: 12-byte IV, 16-byte tag. Reject early if malformed —
    // Node throws with a less-informative error otherwise.
    if (iv.length !== 12 || authTag.length !== 16) return null;

    const decipher = createDecipheriv('aes-256-gcm', KEY, iv);
    decipher.setAuthTag(authTag);
    // `.final()` is where the auth tag is verified. On mismatch it
    // throws `ERR_OSSL_EVP_BAD_DECRYPT` — the whole point of GCM.
    const plaintext = Buffer.concat([
      decipher.update(ciphertext),
      decipher.final(),
    ]).toString('utf-8');

    const parsed = JSON.parse(plaintext) as Session;
    if (
      typeof parsed.accessToken !== 'string' ||
      typeof parsed.userId !== 'string' ||
      typeof parsed.role !== 'string' ||
      typeof parsed.iat !== 'number'
    ) {
      return null;
    }
    // Defence-in-depth vs. browser Max-Age.
    if (Date.now() - parsed.iat > SESSION_MAX_AGE_SECONDS * 1000) return null;
    return parsed;
  } catch {
    // ANY exception (tag mismatch, malformed base64, invalid JSON,
    // truncated input) collapses to a null session.
    return null;
  }
}

// ---------------------------------------------------------------------------
// RBAC
// ---------------------------------------------------------------------------

export function can(session: Session | null, capability: Capability): boolean {
  if (!session) return false;
  return CAPABILITY_MATRIX[capability].includes(session.role);
}

export type Capability =
  | 'view_dashboard'
  | 'view_users'
  | 'suspend_user'
  | 'view_listings'
  | 'moderate_listing'
  | 'view_orders'
  | 'view_payments'
  | 'refund_payment'
  | 'view_disputes'
  | 'resolve_dispute'
  | 'manage_categories';

const CAPABILITY_MATRIX: Record<Capability, AdminRole[]> = {
  view_dashboard: ['admin', 'moderator', 'support'],
  view_users: ['admin', 'moderator', 'support'],
  suspend_user: ['admin'],
  view_listings: ['admin', 'moderator', 'support'],
  moderate_listing: ['admin', 'moderator'],
  view_orders: ['admin', 'moderator', 'support'],
  view_payments: ['admin'],
  refund_payment: ['admin'],
  view_disputes: ['admin', 'moderator', 'support'],
  resolve_dispute: ['admin', 'moderator'],
  manage_categories: ['admin'],
};
