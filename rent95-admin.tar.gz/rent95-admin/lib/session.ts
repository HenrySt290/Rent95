import { createHmac, timingSafeEqual } from 'node:crypto';
import { cookies } from 'next/headers';

import 'server-only';

import {
  ADMIN_ROLES as _ADMIN_ROLES,
  SESSION_COOKIE as _SESSION_COOKIE,
  type AdminRole,
} from './session-shared';

export const SESSION_COOKIE = _SESSION_COOKIE;
export const ADMIN_ROLES: AdminRole[] = [..._ADMIN_ROLES];

const SECRET = process.env.ADMIN_SESSION_SECRET;
if (!SECRET || SECRET.length < 32) {
  throw new Error(
    'ADMIN_SESSION_SECRET must be set to a ≥32 char random string. ' +
      'Generate with `openssl rand -hex 32`.',
  );
}

// 60 days matches refresh-token TTL server-side.
export const SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 60;

export type Session = {
  accessToken: string;
  userId: string;
  role: AdminRole;
  email: string;
  fullName: string;
  /** Issued-at (ms). Used to detect stale sessions after secret rotation. */
  iat: number;
};

export async function readSession(): Promise<Session | null> {
  const jar = await cookies();
  const raw = jar.get(SESSION_COOKIE)?.value;
  if (!raw) return null;
  return _verifyAndParse(raw);
}

export async function writeSession(session: Omit<Session, 'iat'>): Promise<void> {
  const payload: Session = { ...session, iat: Date.now() };
  const cookieValue = _sign(payload);
  const jar = await cookies();
  jar.set({
    name: SESSION_COOKIE,
    value: cookieValue,
    httpOnly: true,
    secure: true, // hard-locked; the __Host- prefix requires this
    sameSite: 'strict',
    path: '/',
    maxAge: SESSION_MAX_AGE_SECONDS,
    // Chrome CHIPS: opt into partitioned cookies so we work in third-party
    // contexts (e.g. an audit tool embedded in an iframe).
    // @ts-expect-error - `partitioned` is not yet in Next's cookie type defs
    // but the underlying Set-Cookie header is emitted correctly.
    partitioned: true,
  });
}

export async function clearSession(): Promise<void> {
  const jar = await cookies();
  jar.set({
    name: SESSION_COOKIE,
    value: '',
    httpOnly: true,
    secure: true,
    sameSite: 'strict',
    path: '/',
    maxAge: 0,
    // @ts-expect-error - see writeSession above
    partitioned: true,
  });
}

// -----------------------------------------------------------------------------
// Signing / verification
// -----------------------------------------------------------------------------

function _sign(payload: Session): string {
  const body = _b64url(JSON.stringify(payload));
  const mac = _hmac(body);
  return `${body}.${mac}`;
}

function _verifyAndParse(raw: string): Session | null {
  const dot = raw.lastIndexOf('.');
  if (dot < 0) return null;
  const body = raw.slice(0, dot);
  const mac = raw.slice(dot + 1);
  const expected = _hmac(body);
  // Constant-time compare — SUB-CRITICAL: `mac === expected` would leak
  // MAC bytes to a timing attack.
  const macBuf = Buffer.from(mac, 'hex');
  const expBuf = Buffer.from(expected, 'hex');
  if (macBuf.length !== expBuf.length) return null;
  if (!timingSafeEqual(macBuf, expBuf)) return null;

  try {
    const json = Buffer.from(body, 'base64url').toString('utf-8');
    const parsed = JSON.parse(json) as Session;
    // Sanity check the shape — a signed but malformed cookie should still fail.
    if (
      typeof parsed.accessToken !== 'string' ||
      typeof parsed.userId !== 'string' ||
      typeof parsed.role !== 'string'
    ) {
      return null;
    }
    // Reject sessions older than the max age. Even though the cookie's
    // Max-Age handles this browser-side, a stale cookie replayed by an
    // attacker with the raw string bypasses that expiry.
    if (Date.now() - parsed.iat > SESSION_MAX_AGE_SECONDS * 1000) return null;
    return parsed;
  } catch {
    return null;
  }
}

function _hmac(data: string): string {
  return createHmac('sha256', SECRET!).update(data).digest('hex');
}

function _b64url(s: string): string {
  return Buffer.from(s, 'utf-8').toString('base64url');
}

// -----------------------------------------------------------------------------
// RBAC
// -----------------------------------------------------------------------------

/** Roles allowed into the admin panel at all. */
export const ADMIN_ROLES: Session['role'][] = ['admin', 'moderator', 'support'];

export function can(session: Session | null, capability: Capability): boolean {
  if (!session) return false;
  return CAPABILITY_MATRIX[capability].includes(session.role);
}

export type Capability =
  | 'view_dashboard'
  | 'view_users'
  | 'suspend_user'
  | 'view_listings'
  | 'moderate_listing'
  | 'view_orders'
  | 'view_payments'
  | 'refund_payment'
  | 'view_disputes'
  | 'resolve_dispute'
  | 'manage_categories';

const CAPABILITY_MATRIX: Record<Capability, AdminRole[]> = {
  view_dashboard: ['admin', 'moderator', 'support'],
  view_users: ['admin', 'moderator', 'support'],
  suspend_user: ['admin'],
  view_listings: ['admin', 'moderator', 'support'],
  moderate_listing: ['admin', 'moderator'],
  view_orders: ['admin', 'moderator', 'support'],
  view_payments: ['admin'],
  refund_payment: ['admin'],
  view_disputes: ['admin', 'moderator', 'support'],
  resolve_dispute: ['admin', 'moderator'],
  manage_categories: ['admin'],
};
