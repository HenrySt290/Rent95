'use server';

import { revalidatePath } from 'next/cache';
import { readSession } from '@/lib/session';

const API_URL = process.env.API_URL ?? 'http://localhost:4000';

async function bearer(): Promise<string> {
  const s = await readSession();
  return s ? `Bearer ${s.accessToken}` : '';
}

export async function setUserStatus(userId: string, action: 'suspend' | 'activate' | 'ban') {
  const res = await fetch(`${API_URL}/api/admin/users/${userId}/status`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      Authorization: await bearer(),
    },
    body: JSON.stringify({ action }),
    cache: 'no-store',
  });
  if (!res.ok) throw new Error(`Failed with status ${res.status}`);
  // Any table row could have changed — invalidate the users list.
  revalidatePath('/dashboard/users');
}
