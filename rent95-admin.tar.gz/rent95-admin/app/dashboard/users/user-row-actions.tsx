'use client';

import { useState, useTransition } from 'react';
import { setUserStatus } from './actions';
import { Ban, CheckCircle2, Pause, Loader2 } from 'lucide-react';

/**
 * The row-level action menu. Kept as a client component because it uses
 * `useTransition` + confirm dialogs.
 *
 * The suspend/ban actions are gated by capability on the server too — we
 * hide the UI here for a smoother experience, but the backend refuses
 * unauthorized calls regardless.
 */
export function UserRowActions({
  userId,
  currentStatus,
  canMutate,
}: {
  userId: string;
  currentStatus: string;
  canMutate: boolean;
}) {
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  if (!canMutate) {
    return <span className="text-xs text-ink-muted">view only</span>;
  }

  const run = (action: 'suspend' | 'activate' | 'ban', label: string) => {
    if (action === 'ban' && !window.confirm(`Ban this user? ${label} is permanent-feeling.`)) return;
    setError(null);
    startTransition(async () => {
      try {
        await setUserStatus(userId, action);
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e));
      }
    });
  };

  return (
    <div className="flex items-center gap-1">
      {pending && <Loader2 size={14} className="animate-spin text-ink-muted" />}
      {currentStatus !== 'active' && (
        <button
          className="btn-ghost text-success"
          onClick={() => run('activate', 'Reactivate')}
          disabled={pending}
          title="Reactivate"
        >
          <CheckCircle2 size={16} />
        </button>
      )}
      {currentStatus !== 'suspended' && (
        <button
          className="btn-ghost text-warning"
          onClick={() => run('suspend', 'Suspend')}
          disabled={pending}
          title="Suspend"
        >
          <Pause size={16} />
        </button>
      )}
      {currentStatus !== 'banned' && (
        <button
          className="btn-ghost text-danger"
          onClick={() => run('ban', 'Ban')}
          disabled={pending}
          title="Ban"
        >
          <Ban size={16} />
        </button>
      )}
      {error && (
        <span className="text-xs text-danger ml-2" role="alert">
          {error}
        </span>
      )}
    </div>
  );
}
