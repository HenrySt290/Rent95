import { apiEnvelope, ApiError } from '@/lib/api';
import { can, readSession } from '@/lib/session';
import { TopBar } from '@/components/topbar';
import { Table, TH, TD, TR, EmptyState } from '@/components/ui/table';
import { Badge, statusVariant } from '@/components/ui/badge';
import { Pagination } from '@/components/ui/pagination';
import { formatDate } from '@/lib/utils';
import { UserRowActions } from './user-row-actions';

type AdminUser = {
  id: string;
  fullName: string;
  email: string;
  role: string;
  accountStatus: string;
  kycStatus: string;
  ratingAverage: number | string;
  reviewCount: number;
  createdAt: string;
};

async function loadUsers(page: number): Promise<{
  users: AdminUser[];
  pagination: { total: number; page: number; pageSize: number; totalPages: number };
  error?: string;
}> {
  try {
    const env = await apiEnvelope<AdminUser[]>(`/api/admin/users?page=${page}&pageSize=20`);
    return {
      users: env.data,
      pagination: env.pagination ?? { total: env.data.length, page, pageSize: 20, totalPages: 1 },
    };
  } catch (e) {
    const message = e instanceof ApiError ? e.message : 'Could not load users';
    return {
      users: [],
      pagination: { total: 0, page: 1, pageSize: 20, totalPages: 1 },
      error: message,
    };
  }
}

export default async function UsersPage({
  searchParams,
}: {
  searchParams: Promise<{ page?: string }>;
}) {
  const params = await searchParams;
  const page = Math.max(1, Number.parseInt(params.page ?? '1', 10) || 1);

  const session = await readSession();
  const canSuspend = can(session, 'suspend_user');

  const { users, pagination, error } = await loadUsers(page);

  return (
    <>
      <TopBar
        title="Users"
        subtitle={`${pagination.total.toLocaleString()} total accounts`}
      />

      <div className="max-w-7xl mx-auto w-full p-6 space-y-4">
        {error && (
          <div className="rounded-lg bg-danger/10 border border-danger/30 px-4 py-3 text-sm text-danger">
            {error}
          </div>
        )}

        <Table>
          <thead>
            <tr>
              <TH>Name</TH>
              <TH>Email</TH>
              <TH>Role</TH>
              <TH>Status</TH>
              <TH>KYC</TH>
              <TH>Joined</TH>
              <TH className="text-right">Actions</TH>
            </tr>
          </thead>
          <tbody>
            {users.length === 0 ? (
              <EmptyState message="No users yet." />
            ) : (
              users.map((u) => (
                <TR key={u.id}>
                  <TD>
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-primary/10 text-primary grid place-items-center font-semibold text-xs">
                        {u.fullName.charAt(0).toUpperCase()}
                      </div>
                      <span className="font-medium">{u.fullName}</span>
                    </div>
                  </TD>
                  <TD className="font-mono text-xs text-ink-muted">{u.email}</TD>
                  <TD>
                    <Badge variant="primary">{u.role}</Badge>
                  </TD>
                  <TD>
                    <Badge variant={statusVariant(u.accountStatus)}>{u.accountStatus}</Badge>
                  </TD>
                  <TD>
                    <Badge variant={statusVariant(u.kycStatus)}>
                      {u.kycStatus.replace(/_/g, ' ')}
                    </Badge>
                  </TD>
                  <TD className="text-ink-muted">{formatDate(u.createdAt)}</TD>
                  <TD className="text-right">
                    <UserRowActions
                      userId={u.id}
                      currentStatus={u.accountStatus}
                      canMutate={canSuspend}
                    />
                  </TD>
                </TR>
              ))
            )}
          </tbody>
        </Table>

        {users.length > 0 && (
          <Pagination
            page={pagination.page}
            totalPages={pagination.totalPages}
            total={pagination.total}
          />
        )}
      </div>
    </>
  );
}
