import { redirect } from 'next/navigation';
import { readSession } from '@/lib/session';
import { Sidebar } from '@/components/sidebar';

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await readSession();
  // Middleware should have redirected already, but this is our
  // defence-in-depth: no session -> no dashboard.
  if (!session) redirect('/login');

  return (
    <div className="min-h-screen flex">
      <Sidebar userName={session.fullName} userRole={session.role} />
      <main className="flex-1 min-w-0 flex flex-col">{children}</main>
    </div>
  );
}
