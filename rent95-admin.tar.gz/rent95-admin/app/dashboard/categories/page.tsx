import { api, ApiError } from '@/lib/api';
import { TopBar } from '@/components/topbar';
import { Table, TH, TD, TR, EmptyState } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

type AdminCategory = {
  id: string;
  name: string;
  slug: string;
  iconName: string | null;
  allowedModes: string[];
  isActive: boolean;
  sortOrder: number;
  parentId: string | null;
  commissionRate: number | string | null;
};

async function loadCategories() {
  try {
    const cats = await api<AdminCategory[]>('/api/categories');
    return { categories: cats };
  } catch (e) {
    return {
      categories: [] as AdminCategory[],
      error: e instanceof ApiError ? e.message : String(e),
    };
  }
}

export default async function CategoriesPage() {
  const { categories, error } = await loadCategories();

  return (
    <>
      <TopBar
        title="Categories"
        subtitle="Marketplace taxonomy — currently read-only in v1"
      />
      <div className="max-w-7xl mx-auto w-full p-6 space-y-4">
        {error && (
          <div className="rounded-lg bg-danger/10 border border-danger/30 px-4 py-3 text-sm text-danger">
            {error}
          </div>
        )}

        <div className="rounded-lg bg-primary-light border border-primary/20 px-4 py-3 text-sm text-primary">
          v1 seeds categories via <span className="font-mono">prisma/seed.ts</span>. Full admin CRUD +
          per-category commission rates land in v1.1 per the revised MVP.
        </div>

        <Table>
          <thead>
            <tr>
              <TH>Order</TH>
              <TH>Name</TH>
              <TH>Slug</TH>
              <TH>Modes</TH>
              <TH>Commission</TH>
              <TH>Status</TH>
            </tr>
          </thead>
          <tbody>
            {categories.length === 0 ? (
              <EmptyState message="No categories yet." />
            ) : (
              categories.map((c) => (
                <TR key={c.id}>
                  <TD className="text-ink-muted">{c.sortOrder}</TD>
                  <TD className="font-medium">{c.name}</TD>
                  <TD className="font-mono text-xs text-ink-muted">{c.slug}</TD>
                  <TD>
                    <div className="flex flex-wrap gap-1">
                      {c.allowedModes.map((m) => (
                        <Badge key={m} variant="primary">
                          {m}
                        </Badge>
                      ))}
                    </div>
                  </TD>
                  <TD>{c.commissionRate ? `${c.commissionRate}%` : 'default'}</TD>
                  <TD>
                    <Badge variant={c.isActive ? 'success' : 'neutral'}>
                      {c.isActive ? 'active' : 'inactive'}
                    </Badge>
                  </TD>
                </TR>
              ))
            )}
          </tbody>
        </Table>
      </div>
    </>
  );
}
