import { apiEnvelope, ApiError } from '@/lib/api';
import { TopBar } from '@/components/topbar';
import { Table, TH, TD, TR, EmptyState } from '@/components/ui/table';
import { Badge, statusVariant } from '@/components/ui/badge';
import { Pagination } from '@/components/ui/pagination';
import { formatCurrency, formatDate } from '@/lib/utils';

type AdminPayment = {
  id: string;
  provider: string;
  providerPaymentId: string | null;
  amount: number | string;
  platformFee: number | string;
  sellerAmount: number | string;
  currency: string;
  status: string;
  escrowStatus: string;
  createdAt: string;
  order?: { orderNumber: string };
};

async function loadPayments(page: number) {
  try {
    const env = await apiEnvelope<AdminPayment[]>(`/api/admin/payments?page=${page}&pageSize=20`);
    return {
      payments: env.data,
      pagination: env.pagination ?? { total: env.data.length, page, pageSize: 20, totalPages: 1 },
    };
  } catch (e) {
    return {
      payments: [] as AdminPayment[],
      pagination: { total: 0, page: 1, pageSize: 20, totalPages: 1 },
      error: e instanceof ApiError ? e.message : String(e),
    };
  }
}

export default async function PaymentsPage({
  searchParams,
}: {
  searchParams: Promise<{ page?: string }>;
}) {
  const params = await searchParams;
  const page = Math.max(1, Number.parseInt(params.page ?? '1', 10) || 1);
  const { payments, pagination, error } = await loadPayments(page);

  return (
    <>
      <TopBar title="Payments" subtitle="Every charge, escrow state, and refund" />
      <div className="max-w-7xl mx-auto w-full p-6 space-y-4">
        {error && (
          <div className="rounded-lg bg-danger/10 border border-danger/30 px-4 py-3 text-sm text-danger">
            {error} — the <span className="font-mono">/api/admin/payments</span> endpoint may not be
            wired yet on your backend build. See the initial rent95-api scaffold.
          </div>
        )}
        <Table>
          <thead>
            <tr>
              <TH>Provider ID</TH>
              <TH>Order</TH>
              <TH>Amount</TH>
              <TH>Platform fee</TH>
              <TH>Seller amount</TH>
              <TH>Status</TH>
              <TH>Escrow</TH>
              <TH>Created</TH>
            </tr>
          </thead>
          <tbody>
            {payments.length === 0 ? (
              <EmptyState message="No payments yet." />
            ) : (
              payments.map((p) => (
                <TR key={p.id}>
                  <TD className="font-mono text-xs">
                    {p.providerPaymentId?.slice(0, 20) ?? '—'}
                  </TD>
                  <TD className="font-mono text-xs">{p.order?.orderNumber ?? '—'}</TD>
                  <TD className="font-medium">{formatCurrency(p.amount, p.currency)}</TD>
                  <TD className="text-ink-muted">{formatCurrency(p.platformFee, p.currency)}</TD>
                  <TD>{formatCurrency(p.sellerAmount, p.currency)}</TD>
                  <TD>
                    <Badge variant={statusVariant(p.status)}>{p.status}</Badge>
                  </TD>
                  <TD>
                    <Badge variant={statusVariant(p.escrowStatus)}>{p.escrowStatus}</Badge>
                  </TD>
                  <TD className="text-ink-muted">{formatDate(p.createdAt)}</TD>
                </TR>
              ))
            )}
          </tbody>
        </Table>
        {payments.length > 0 && (
          <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} />
        )}
      </div>
    </>
  );
}
