'use client';

import { useState, useTransition } from 'react';
import { CheckCircle2, XCircle, Loader2, RotateCcw } from 'lucide-react';
import { resolveDispute, type Resolution } from './actions';

type Props = {
  disputeId: string;
  canResolve: boolean;
};

/**
 * Row-level dispute resolution UI. Expands into an inline panel when the
 * admin picks a resolution, so no modal state to manage.
 */
export function DisputeActions({ disputeId, canResolve }: Props) {
  const [expanded, setExpanded] = useState<Resolution | null>(null);
  const [note, setNote] = useState('');
  const [partialAmount, setPartialAmount] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  if (!canResolve) {
    return <span className="text-xs text-ink-muted">view only</span>;
  }

  const submit = () => {
    if (!expanded) return;
    setError(null);
    const amount = expanded === 'partial_refund' ? Number.parseFloat(partialAmount) : undefined;
    if (expanded === 'partial_refund' && (!amount || amount <= 0)) {
      setError('Enter a positive refund amount.');
      return;
    }
    startTransition(async () => {
      try {
        await resolveDispute(disputeId, expanded, note, amount);
        setExpanded(null);
        setNote('');
        setPartialAmount('');
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e));
      }
    });
  };

  if (expanded) {
    return (
      <div className="flex flex-col gap-2 items-end min-w-[280px]">
        <div className="text-xs font-semibold text-ink">
          {expanded === 'refund_buyer' && 'Refund buyer in full'}
          {expanded === 'release_seller' && 'Release funds to seller'}
          {expanded === 'partial_refund' && 'Partial refund to buyer'}
          {expanded === 'reject' && 'Reject dispute'}
        </div>
        {expanded === 'partial_refund' && (
          <input
            type="number"
            step="0.01"
            min="0.01"
            value={partialAmount}
            onChange={(e) => setPartialAmount(e.target.value)}
            placeholder="Refund amount"
            className="input py-1 text-xs w-full"
            disabled={pending}
          />
        )}
        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Note (visible in the audit log)"
          className="input py-1 text-xs w-full"
          rows={2}
          disabled={pending}
        />
        <div className="flex gap-2">
          <button
            className="btn-outline text-xs"
            onClick={() => {
              setExpanded(null);
              setError(null);
            }}
            disabled={pending}
          >
            Cancel
          </button>
          <button
            className={expanded === 'reject' ? 'btn-outline text-xs' : 'btn-primary text-xs'}
            onClick={submit}
            disabled={pending}
          >
            {pending && <Loader2 size={12} className="animate-spin" />}
            Confirm
          </button>
        </div>
        {error && <span className="text-xs text-danger">{error}</span>}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1 justify-end flex-wrap">
      <button
        className="btn-outline text-xs text-success"
        onClick={() => setExpanded('release_seller')}
        title="Release funds to seller"
      >
        <CheckCircle2 size={14} /> Release
      </button>
      <button
        className="btn-outline text-xs text-danger"
        onClick={() => setExpanded('refund_buyer')}
        title="Refund buyer in full"
      >
        <RotateCcw size={14} /> Refund
      </button>
      <button
        className="btn-outline text-xs"
        onClick={() => setExpanded('partial_refund')}
        title="Partial refund"
      >
        Partial
      </button>
      <button
        className="btn-ghost text-xs"
        onClick={() => setExpanded('reject')}
        title="Reject dispute"
      >
        <XCircle size={14} /> Reject
      </button>
    </div>
  );
}
