'use server';

import { revalidatePath } from 'next/cache';
import { readSession } from '@/lib/session';

const API_URL = process.env.API_URL ?? 'http://localhost:4000';

async function bearer(): Promise<string> {
  const s = await readSession();
  return s ? `Bearer ${s.accessToken}` : '';
}

export type Resolution = 'refund_buyer' | 'release_seller' | 'partial_refund' | 'reject';

/**
 * Resolve a dispute. The backend does the escrow math + payment update in
 * one transaction so the panel just needs to send the intent + a note.
 */
export async function resolveDispute(
  disputeId: string,
  resolution: Resolution,
  note: string,
  partialRefundAmount?: number,
) {
  const res = await fetch(`${API_URL}/api/admin/disputes/${disputeId}/resolve`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      Authorization: await bearer(),
    },
    body: JSON.stringify({ resolution, note, partialRefundAmount }),
    cache: 'no-store',
  });
  if (!res.ok) {
    let message = `Failed with ${res.status}`;
    try {
      const body = (await res.json()) as { message?: string };
      if (body.message) message = body.message;
    } catch {
      /* not JSON */
    }
    throw new Error(message);
  }
  revalidatePath('/dashboard/disputes');
}
