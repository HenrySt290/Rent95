import { apiEnvelope, ApiError } from '@/lib/api';
import { TopBar } from '@/components/topbar';
import { Table, TH, TD, TR, EmptyState } from '@/components/ui/table';
import { Badge, statusVariant } from '@/components/ui/badge';
import { formatCurrency, formatDate } from '@/lib/utils';
import { can, readSession } from '@/lib/session';
import { DisputeActions } from './dispute-actions';

type AdminDispute = {
  id: string;
  reason: string;
  description: string;
  status: string;
  resolution?: string | null;
  createdAt: string;
  raisedByUser?: { fullName: string; email: string };
  againstUser?: { fullName: string; email: string };
  order?: { orderNumber: string; totalAmount: number | string; currency: string };
};

async function loadDisputes() {
  try {
    const env = await apiEnvelope<AdminDispute[]>('/api/admin/disputes');
    return { disputes: env.data };
  } catch (e) {
    return { disputes: [] as AdminDispute[], error: e instanceof ApiError ? e.message : String(e) };
  }
}

export default async function DisputesPage() {
  const { disputes, error } = await loadDisputes();
  const session = await readSession();
  const canResolve = can(session, 'resolve_dispute');

  const open = disputes.filter((d) => d.status === 'open' || d.status === 'under_review');
  const closed = disputes.filter((d) => d.status === 'resolved' || d.status === 'rejected');

  return (
    <>
      <TopBar title="Disputes" subtitle={`${open.length} open, ${closed.length} closed`} />
      <div className="max-w-7xl mx-auto w-full p-6 space-y-6">
        {error && (
          <div className="rounded-lg bg-danger/10 border border-danger/30 px-4 py-3 text-sm text-danger">
            {error}
          </div>
        )}

        <section>
          <h2 className="font-semibold mb-3">Open</h2>
          <Table>
            <thead>
              <tr>
                <TH>Order</TH>
                <TH>Raised by</TH>
                <TH>Against</TH>
                <TH>Reason</TH>
                <TH>Amount</TH>
                <TH>Status</TH>
                <TH>Opened</TH>
                <TH className="text-right">Actions</TH>
              </tr>
            </thead>
            <tbody>
              {open.length === 0 ? (
                <EmptyState message="No open disputes 🎉" />
              ) : (
                open.map((d) => (
                  <DisputeRow key={d.id} d={d} canResolve={canResolve} showActions />
                ))
              )}
            </tbody>
          </Table>
        </section>

        <section>
          <h2 className="font-semibold mb-3">Closed</h2>
          <Table>
            <thead>
              <tr>
                <TH>Order</TH>
                <TH>Raised by</TH>
                <TH>Against</TH>
                <TH>Reason</TH>
                <TH>Amount</TH>
                <TH>Status</TH>
                <TH>Resolution</TH>
              </tr>
            </thead>
            <tbody>
              {closed.length === 0 ? (
                <EmptyState message="No closed disputes." />
              ) : (
                closed.map((d) => (
                  <DisputeRow key={d.id} d={d} canResolve={canResolve} showResolution />
                ))
              )}
            </tbody>
          </Table>
        </section>
      </div>
    </>
  );
}

function DisputeRow({
  d,
  canResolve,
  showActions = false,
  showResolution = false,
}: {
  d: AdminDispute;
  canResolve: boolean;
  showActions?: boolean;
  showResolution?: boolean;
}) {
  return (
    <TR>
      <TD className="font-mono text-xs">{d.order?.orderNumber ?? '—'}</TD>
      <TD>
        {d.raisedByUser?.fullName ?? '—'}
        <div className="text-xs text-ink-muted">{d.raisedByUser?.email ?? ''}</div>
      </TD>
      <TD>
        {d.againstUser?.fullName ?? '—'}
        <div className="text-xs text-ink-muted">{d.againstUser?.email ?? ''}</div>
      </TD>
      <TD>
        <div className="font-medium">{d.reason}</div>
        <div className="text-xs text-ink-muted line-clamp-2 max-w-[300px]">{d.description}</div>
      </TD>
      <TD className="font-medium">
        {d.order ? formatCurrency(d.order.totalAmount, d.order.currency) : '—'}
      </TD>
      <TD>
        <Badge variant={statusVariant(d.status)}>{d.status.replace(/_/g, ' ')}</Badge>
      </TD>
      {showActions ? (
        <>
          <TD className="text-ink-muted">{formatDate(d.createdAt)}</TD>
          <TD>
            <DisputeActions disputeId={d.id} canResolve={canResolve} />
          </TD>
        </>
      ) : null}
      {showResolution ? (
        <TD className="max-w-[280px] text-xs">
          {d.resolution ?? <span className="text-ink-muted">—</span>}
        </TD>
      ) : null}
    </TR>
  );
}
