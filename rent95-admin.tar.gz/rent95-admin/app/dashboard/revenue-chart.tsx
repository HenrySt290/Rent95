'use client';

import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

/**
 * Minimal placeholder chart until the API surfaces a real time-series
 * endpoint (e.g. GET /api/admin/analytics?range=30d). Kept as a client
 * component because Recharts uses `window` under the hood.
 */
export function RevenueChart({ data }: { data: { day: string; gmv: number }[] }) {
  return (
    <div className="card p-5 h-72">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="font-semibold">GMV — last 14 days</h3>
          <p className="text-xs text-ink-muted">Gross merchandise value across paid orders</p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height="80%">
        <LineChart data={data} margin={{ top: 5, right: 12, left: -8, bottom: 0 }}>
          <CartesianGrid stroke="#E2E8F0" strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="day" stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} />
          <Tooltip
            contentStyle={{
              borderRadius: 8,
              border: '1px solid #E2E8F0',
              fontSize: 12,
              boxShadow: '0 4px 12px rgba(0,0,0,0.04)',
            }}
          />
          <Line
            type="monotone"
            dataKey="gmv"
            stroke="#3B49DF"
            strokeWidth={2}
            dot={{ r: 3, fill: '#3B49DF' }}
            activeDot={{ r: 5 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
