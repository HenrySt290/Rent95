'use client';

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  BarChart,
  Bar,
  Legend,
} from 'recharts';

type Series = { day: string; value: number }[];

/**
 * Renders the day-by-day GMV chart. Data comes straight from
 * `GET /api/admin/analytics` — the backend zero-fills every day, so no
 * client-side gap filling is needed.
 */
export function RevenueChart({
  data,
  title,
  subtitle,
  formatter,
}: {
  data: Series;
  title: string;
  subtitle: string;
  formatter?: (v: number) => string;
}) {
  const display = data.map((d) => ({
    ...d,
    // "Mon 12" style label — enough for a 30-day window without crowding.
    label: new Date(d.day).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
  }));

  return (
    <div className="card p-5 h-72">
      <div className="mb-3">
        <h3 className="font-semibold">{title}</h3>
        <p className="text-xs text-ink-muted">{subtitle}</p>
      </div>
      <ResponsiveContainer width="100%" height="80%">
        <LineChart data={display} margin={{ top: 5, right: 12, left: -8, bottom: 0 }}>
          <CartesianGrid stroke="#E2E8F0" strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="label" stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#64748B"
            fontSize={11}
            tickLine={false}
            axisLine={false}
            tickFormatter={formatter}
          />
          <Tooltip
            contentStyle={{
              borderRadius: 8,
              border: '1px solid #E2E8F0',
              fontSize: 12,
              boxShadow: '0 4px 12px rgba(0,0,0,0.04)',
            }}
            formatter={(v: number) => (formatter ? formatter(v) : v)}
          />
          <Line
            type="monotone"
            dataKey="value"
            stroke="#3B49DF"
            strokeWidth={2}
            dot={{ r: 3, fill: '#3B49DF' }}
            activeDot={{ r: 5 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

/**
 * "Orders by status" bar chart — pulled from the same analytics response
 * so it's always in sync with the range picker at the top.
 */
export function OrdersByStatusChart({ byStatus }: { byStatus: Record<string, number> }) {
  const data = Object.entries(byStatus)
    .map(([status, count]) => ({ status, count }))
    .sort((a, b) => b.count - a.count);

  if (data.length === 0) {
    return (
      <div className="card p-5 h-72 grid place-items-center">
        <p className="text-ink-muted text-sm">No orders in this window yet.</p>
      </div>
    );
  }

  return (
    <div className="card p-5 h-72">
      <div className="mb-3">
        <h3 className="font-semibold">Orders by status</h3>
        <p className="text-xs text-ink-muted">In the selected window</p>
      </div>
      <ResponsiveContainer width="100%" height="80%">
        <BarChart data={data} margin={{ top: 5, right: 12, left: -8, bottom: 0 }}>
          <CartesianGrid stroke="#E2E8F0" strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="status" stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
          <Tooltip
            contentStyle={{
              borderRadius: 8,
              border: '1px solid #E2E8F0',
              fontSize: 12,
              boxShadow: '0 4px 12px rgba(0,0,0,0.04)',
            }}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Bar dataKey="count" name="Orders" fill="#3B49DF" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
