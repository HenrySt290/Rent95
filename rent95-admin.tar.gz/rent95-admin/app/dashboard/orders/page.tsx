import { apiEnvelope, ApiError } from '@/lib/api';
import { TopBar } from '@/components/topbar';
import { Table, TH, TD, TR, EmptyState } from '@/components/ui/table';
import { Badge, statusVariant } from '@/components/ui/badge';
import { Pagination } from '@/components/ui/pagination';
import { formatCurrency, formatDate } from '@/lib/utils';

type AdminOrder = {
  id: string;
  orderNumber: string;
  orderType: string;
  status: string;
  totalAmount: number | string;
  currency: string;
  createdAt: string;
  startDatetime?: string;
  endDatetime?: string;
  buyer?: { fullName: string; email: string };
  seller?: { fullName: string; email: string };
  product?: { title: string };
};

async function loadOrders(page: number) {
  try {
    const env = await apiEnvelope<AdminOrder[]>(`/api/admin/orders?page=${page}&pageSize=20`);
    return {
      orders: env.data,
      pagination: env.pagination ?? { total: env.data.length, page, pageSize: 20, totalPages: 1 },
    };
  } catch (e) {
    return {
      orders: [] as AdminOrder[],
      pagination: { total: 0, page: 1, pageSize: 20, totalPages: 1 },
      error: e instanceof ApiError ? e.message : String(e),
    };
  }
}

export default async function OrdersPage({
  searchParams,
}: {
  searchParams: Promise<{ page?: string }>;
}) {
  const params = await searchParams;
  const page = Math.max(1, Number.parseInt(params.page ?? '1', 10) || 1);
  const { orders, pagination, error } = await loadOrders(page);

  return (
    <>
      <TopBar title="Orders" subtitle={`${pagination.total.toLocaleString()} total`} />
      <div className="max-w-7xl mx-auto w-full p-6 space-y-4">
        {error && (
          <div className="rounded-lg bg-danger/10 border border-danger/30 px-4 py-3 text-sm text-danger">
            {error}
          </div>
        )}
        <Table>
          <thead>
            <tr>
              <TH>Order</TH>
              <TH>Buyer</TH>
              <TH>Seller</TH>
              <TH>Product</TH>
              <TH>Type</TH>
              <TH>Status</TH>
              <TH>Total</TH>
              <TH>Created</TH>
            </tr>
          </thead>
          <tbody>
            {orders.length === 0 ? (
              <EmptyState message="No orders yet." />
            ) : (
              orders.map((o) => (
                <TR key={o.id}>
                  <TD className="font-mono text-xs">{o.orderNumber}</TD>
                  <TD className="text-sm">
                    {o.buyer?.fullName ?? '—'}
                    <div className="text-xs text-ink-muted">{o.buyer?.email ?? ''}</div>
                  </TD>
                  <TD className="text-sm">
                    {o.seller?.fullName ?? '—'}
                    <div className="text-xs text-ink-muted">{o.seller?.email ?? ''}</div>
                  </TD>
                  <TD className="max-w-[200px] truncate">{o.product?.title ?? '—'}</TD>
                  <TD>
                    <Badge variant="primary">{o.orderType}</Badge>
                  </TD>
                  <TD>
                    <Badge variant={statusVariant(o.status)}>{o.status}</Badge>
                  </TD>
                  <TD className="font-medium">{formatCurrency(o.totalAmount, o.currency)}</TD>
                  <TD className="text-ink-muted">{formatDate(o.createdAt)}</TD>
                </TR>
              ))
            )}
          </tbody>
        </Table>
        {orders.length > 0 && (
          <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} />
        )}
      </div>
    </>
  );
}
