import { api, ApiError } from '@/lib/api';
import { TopBar } from '@/components/topbar';
import { StatCard } from '@/components/ui/card';
import { RangePicker } from '@/components/ui/range-picker';
import { formatCompact, formatCurrency } from '@/lib/utils';
import {
  Users,
  Package,
  ShoppingBag,
  ShieldAlert,
  DollarSign,
  ListChecks,
  CreditCard,
  RotateCcw,
  Flag,
} from 'lucide-react';
import { OrdersByStatusChart, RevenueChart } from './revenue-chart';
import { Table, TH, TD, TR, EmptyState } from '@/components/ui/table';

// ---------------------------------------------------------------------------
// Types mirror what /api/admin/analytics returns.
// ---------------------------------------------------------------------------

type Bucket = { day: string; value: number };
type Delta = { percent: number; vs: 'previous_period' } | null;

type Analytics = {
  range: { from: string; to: string; days: number };
  gmv: { total: number; currency: string; series: Bucket[]; delta: Delta };
  newUsers: { total: number; series: Bucket[]; delta: Delta };
  newListings: { total: number; series: Bucket[]; delta: Delta };
  orders: { total: number; series: Bucket[]; byStatus: Record<string, number>; delta: Delta };
  paymentSuccessRate: number | null;
  refundRate: number | null;
  disputeRate: number | null;
  topCategories: Array<{ id: string; name: string; gmv: number; orderCount: number }>;
};

type DashboardMetrics = {
  users: number;
  sellers: number;
  listings: number;
  pendingListings: number;
  orders: number;
  openDisputes: number;
  gmv: number | string;
};

// ---------------------------------------------------------------------------
// Loaders — each returns { data, error } so a partial failure never blanks
// the whole page.
// ---------------------------------------------------------------------------

async function loadAll(range: string): Promise<{
  analytics: Analytics | null;
  metrics: DashboardMetrics | null;
  error?: string;
}> {
  try {
    const [analytics, metrics] = await Promise.all([
      api<Analytics>(`/api/admin/analytics?range=${range}`),
      api<DashboardMetrics>('/api/admin/dashboard'),
    ]);
    return { analytics, metrics };
  } catch (e) {
    return {
      analytics: null,
      metrics: null,
      error: e instanceof ApiError ? e.message : 'Could not load analytics.',
    };
  }
}

function formatPercent(rate: number | null): string {
  if (rate === null) return '—';
  return `${(rate * 100).toFixed(1)}%`;
}

// ---------------------------------------------------------------------------

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ range?: string }>;
}) {
  const { range: rawRange } = await searchParams;
  const range = ['7d', '14d', '30d', '90d'].includes(rawRange ?? '') ? (rawRange as string) : '14d';

  const { analytics, metrics, error } = await loadAll(range);

  return (
    <>
      <TopBar
        title="Overview"
        subtitle="Live marketplace health"
        actions={<RangePicker selected={range} />}
      />

      <div className="max-w-7xl mx-auto w-full p-6 space-y-6">
        {error && (
          <div className="rounded-lg bg-danger/10 border border-danger/30 px-4 py-3 text-sm text-danger">
            {error} — is <span className="font-mono">rent95-api</span> running?
          </div>
        )}

        {/* Rollup counters at the top — non-windowed totals from /dashboard. */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <StatCard
            label="Gross merchandise value"
            value={formatCurrency(analytics?.gmv.total ?? 0)}
            hint={`Last ${range} · paid + active + completed`}
            icon={<DollarSign size={20} />}
            intent="success"
            delta={analytics?.gmv.delta ?? null}
          />
          <StatCard
            label="New users"
            value={formatCompact(analytics?.newUsers.total ?? 0)}
            hint={`Last ${range}`}
            icon={<Users size={20} />}
            delta={analytics?.newUsers.delta ?? null}
          />
          <StatCard
            label="New listings"
            value={formatCompact(analytics?.newListings.total ?? 0)}
            hint={`Last ${range}`}
            icon={<Package size={20} />}
            delta={analytics?.newListings.delta ?? null}
          />
          <StatCard
            label="Orders"
            value={formatCompact(analytics?.orders.total ?? 0)}
            hint={`Last ${range}`}
            icon={<ShoppingBag size={20} />}
            delta={analytics?.orders.delta ?? null}
          />
          <StatCard
            label="Total users"
            value={formatCompact(metrics?.users ?? 0)}
            hint={`${formatCompact(metrics?.sellers ?? 0)} sellers`}
            icon={<Users size={20} />}
          />
          <StatCard
            label="Total listings"
            value={formatCompact(metrics?.listings ?? 0)}
            hint={
              metrics?.pendingListings
                ? `${metrics.pendingListings} pending moderation`
                : 'All approved'
            }
            icon={<ListChecks size={20} />}
            intent={metrics?.pendingListings ? 'warning' : 'primary'}
          />
        </div>

        {/* Marketplace-health rate cards. Each is a fraction over the window. */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            label="Payment success rate"
            value={formatPercent(analytics?.paymentSuccessRate ?? null)}
            hint={`Last ${range}`}
            icon={<CreditCard size={20} />}
            intent={
              analytics?.paymentSuccessRate == null
                ? 'primary'
                : analytics.paymentSuccessRate > 0.95
                  ? 'success'
                  : analytics.paymentSuccessRate < 0.9
                    ? 'danger'
                    : 'warning'
            }
          />
          <StatCard
            label="Refund rate"
            value={formatPercent(analytics?.refundRate ?? null)}
            hint={`Last ${range}`}
            icon={<RotateCcw size={20} />}
            intent={
              analytics?.refundRate == null
                ? 'primary'
                : analytics.refundRate < 0.05
                  ? 'success'
                  : analytics.refundRate > 0.15
                    ? 'danger'
                    : 'warning'
            }
          />
          <StatCard
            label="Dispute rate"
            value={formatPercent(analytics?.disputeRate ?? null)}
            hint={`Last ${range}`}
            icon={<Flag size={20} />}
            intent={
              analytics?.disputeRate == null
                ? 'primary'
                : analytics.disputeRate < 0.02
                  ? 'success'
                  : analytics.disputeRate > 0.05
                    ? 'danger'
                    : 'warning'
            }
          />
          <StatCard
            label="Open disputes"
            value={formatCompact(metrics?.openDisputes ?? 0)}
            hint="All time"
            icon={<ShieldAlert size={20} />}
            intent={metrics?.openDisputes ? 'danger' : 'success'}
          />
        </div>

        {/* Charts. Time-series data flows straight from the API; zero-filled
            server-side so we don't have to gap-fill on the client. */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <RevenueChart
            data={analytics?.gmv.series ?? []}
            title={`GMV — last ${range}`}
            subtitle="Gross merchandise value per day (paid + active + completed)"
            formatter={(v) => formatCurrency(v)}
          />
          <RevenueChart
            data={analytics?.newUsers.series ?? []}
            title={`New users — last ${range}`}
            subtitle="Sign-ups per day"
          />
          <RevenueChart
            data={analytics?.newListings.series ?? []}
            title={`New listings — last ${range}`}
            subtitle="Listings created per day"
          />
          <OrdersByStatusChart byStatus={analytics?.orders.byStatus ?? {}} />
        </div>

        {/* Top categories table. Only shows something after real orders exist. */}
        <div>
          <h3 className="font-semibold mb-3">Top categories by GMV</h3>
          <Table>
            <thead>
              <tr>
                <TH>Category</TH>
                <TH className="text-right">Orders</TH>
                <TH className="text-right">GMV</TH>
              </tr>
            </thead>
            <tbody>
              {(analytics?.topCategories?.length ?? 0) === 0 ? (
                <EmptyState message="No paid orders in this window yet." />
              ) : (
                analytics!.topCategories.map((c) => (
                  <TR key={c.id}>
                    <TD className="font-medium">{c.name}</TD>
                    <TD className="text-right">{formatCompact(c.orderCount)}</TD>
                    <TD className="text-right font-medium">{formatCurrency(c.gmv)}</TD>
                  </TR>
                ))
              )}
            </tbody>
          </Table>
        </div>
      </div>
    </>
  );
}
