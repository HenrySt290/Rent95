import { api, ApiError } from '@/lib/api';
import { TopBar } from '@/components/topbar';
import { StatCard } from '@/components/ui/card';
import { formatCompact, formatCurrency } from '@/lib/utils';
import { Users, Package, ShoppingBag, ShieldAlert, DollarSign, ListChecks } from 'lucide-react';
import { RevenueChart } from './revenue-chart';

type DashboardMetrics = {
  users: number;
  sellers: number;
  listings: number;
  pendingListings: number;
  orders: number;
  openDisputes: number;
  gmv: number | string;
};

async function loadMetrics(): Promise<{ metrics: DashboardMetrics | null; error?: string }> {
  try {
    const metrics = await api<DashboardMetrics>('/api/admin/dashboard');
    return { metrics };
  } catch (e) {
    const message = e instanceof ApiError ? e.message : 'Could not load dashboard metrics.';
    return { metrics: null, error: message };
  }
}

/**
 * Fake time-series data until the API exposes one. Kept beside the loader
 * so replacing it with a real fetch is a one-line change.
 */
function fakeChartData(): { day: string; gmv: number }[] {
  const days = Array.from({ length: 14 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (13 - i));
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  });
  const base = 4200;
  return days.map((day, i) => ({
    day,
    gmv: Math.round(base + i * 250 + Math.sin(i / 1.5) * 900),
  }));
}

export default async function DashboardPage() {
  const { metrics, error } = await loadMetrics();

  return (
    <>
      <TopBar
        title="Overview"
        subtitle="Live marketplace health at a glance"
      />

      <div className="max-w-7xl mx-auto w-full p-6 space-y-6">
        {error && (
          <div className="rounded-lg bg-danger/10 border border-danger/30 px-4 py-3 text-sm text-danger">
            {error} — is <span className="font-mono">rent95-api</span> running?
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <StatCard
            label="Gross merchandise value"
            value={formatCurrency(metrics?.gmv ?? 0)}
            hint="All orders in paid / active / completed"
            icon={<DollarSign size={20} />}
            intent="success"
          />
          <StatCard
            label="Users"
            value={formatCompact(metrics?.users ?? 0)}
            hint={`${formatCompact(metrics?.sellers ?? 0)} sellers`}
            icon={<Users size={20} />}
          />
          <StatCard
            label="Listings"
            value={formatCompact(metrics?.listings ?? 0)}
            hint={
              metrics?.pendingListings
                ? `${metrics.pendingListings} pending moderation`
                : 'All approved'
            }
            icon={<Package size={20} />}
          />
          <StatCard
            label="Total orders"
            value={formatCompact(metrics?.orders ?? 0)}
            icon={<ShoppingBag size={20} />}
          />
          <StatCard
            label="Pending listings"
            value={formatCompact(metrics?.pendingListings ?? 0)}
            hint={metrics?.pendingListings ? 'Needs a moderator' : 'Queue clear'}
            icon={<ListChecks size={20} />}
            intent={metrics?.pendingListings ? 'warning' : 'success'}
          />
          <StatCard
            label="Open disputes"
            value={formatCompact(metrics?.openDisputes ?? 0)}
            hint={metrics?.openDisputes ? 'Assign to a moderator' : 'Everything settled'}
            icon={<ShieldAlert size={20} />}
            intent={metrics?.openDisputes ? 'danger' : 'success'}
          />
        </div>

        <RevenueChart data={fakeChartData()} />
      </div>
    </>
  );
}
