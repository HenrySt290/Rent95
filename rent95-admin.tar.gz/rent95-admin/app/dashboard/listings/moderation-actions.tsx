'use client';

import { useState, useTransition } from 'react';
import { CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { moderateListing } from './actions';

const REJECTION_REASONS = [
  'Prohibited item',
  'Misleading title or description',
  'Poor image quality',
  'Wrong category',
  'Suspicious pricing',
  'Duplicate listing',
  'Verification required',
  'Policy violation',
] as const;

export function ModerationActions({ productId, canMutate }: { productId: string; canMutate: boolean }) {
  const [pending, startTransition] = useTransition();
  const [rejecting, setRejecting] = useState(false);
  const [reason, setReason] = useState<string>(REJECTION_REASONS[0]);
  const [customReason, setCustomReason] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!canMutate) {
    return <span className="text-xs text-ink-muted">view only</span>;
  }

  const approve = () => {
    setError(null);
    startTransition(async () => {
      try {
        await moderateListing(productId, 'approve');
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e));
      }
    });
  };

  const reject = () => {
    setError(null);
    const finalReason = customReason.trim() || reason;
    startTransition(async () => {
      try {
        await moderateListing(productId, 'reject', finalReason);
        setRejecting(false);
        setCustomReason('');
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e));
      }
    });
  };

  if (rejecting) {
    return (
      <div className="flex flex-col gap-2 items-end">
        <select
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          className="input py-1 text-xs w-56"
          disabled={pending}
        >
          {REJECTION_REASONS.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </select>
        <input
          value={customReason}
          onChange={(e) => setCustomReason(e.target.value)}
          placeholder="Or type a custom reason…"
          className="input py-1 text-xs w-56"
          disabled={pending}
        />
        <div className="flex gap-2">
          <button className="btn-outline text-xs" onClick={() => setRejecting(false)} disabled={pending}>
            Cancel
          </button>
          <button className="btn-danger text-xs" onClick={reject} disabled={pending}>
            {pending && <Loader2 size={12} className="animate-spin" />}
            Confirm reject
          </button>
        </div>
        {error && <span className="text-xs text-danger">{error}</span>}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1 justify-end">
      {pending && <Loader2 size={14} className="animate-spin text-ink-muted mr-1" />}
      <button className="btn-outline text-xs text-danger" onClick={() => setRejecting(true)} disabled={pending}>
        <XCircle size={14} /> Reject
      </button>
      <button className="btn-primary text-xs" onClick={approve} disabled={pending}>
        <CheckCircle2 size={14} /> Approve
      </button>
      {error && <span className="text-xs text-danger ml-2">{error}</span>}
    </div>
  );
}
