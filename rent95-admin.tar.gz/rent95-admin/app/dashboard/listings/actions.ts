'use server';

import { revalidatePath } from 'next/cache';
import { readSession } from '@/lib/session';

const API_URL = process.env.API_URL ?? 'http://localhost:4000';

async function bearer(): Promise<string> {
  const s = await readSession();
  return s ? `Bearer ${s.accessToken}` : '';
}

/**
 * Approve or reject a listing. Reason is stored on the product record and
 * shown to the seller in the mobile app, so it needs to be human-readable.
 */
export async function moderateListing(
  productId: string,
  decision: 'approve' | 'reject',
  reason?: string,
) {
  const res = await fetch(`${API_URL}/api/admin/products/${productId}/moderate`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      Authorization: await bearer(),
    },
    body: JSON.stringify({ decision, reason }),
    cache: 'no-store',
  });
  if (!res.ok) throw new Error(`Moderation failed: ${res.status}`);
  revalidatePath('/dashboard/listings');
}
