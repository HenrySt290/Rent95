import { apiEnvelope, ApiError } from '@/lib/api';
import { TopBar } from '@/components/topbar';
import { Table, TH, TD, TR, EmptyState } from '@/components/ui/table';
import { Badge, statusVariant } from '@/components/ui/badge';
import { Pagination } from '@/components/ui/pagination';
import { formatCurrency, formatDate } from '@/lib/utils';
import Link from 'next/link';
import { ModerationActions } from './moderation-actions';
import { can, readSession } from '@/lib/session';

type AdminListing = {
  id: string;
  title: string;
  price: number | string;
  currency: string;
  priceUnit: string;
  listingType: string;
  status: string;
  moderationStatus: string;
  createdAt: string;
  owner?: { id: string; fullName: string; email: string };
  category?: { name: string };
  media?: { url: string }[];
};

async function loadListings(
  page: number,
  filter: 'pending' | 'all',
): Promise<{
  listings: AdminListing[];
  pagination: { total: number; page: number; pageSize: number; totalPages: number };
  error?: string;
}> {
  const qs = new URLSearchParams({ page: String(page), pageSize: '20' });
  if (filter === 'pending') qs.set('moderationStatus', 'pending');
  try {
    // Admin endpoint returns the same shape as the public search but without
    // the moderationStatus=approved filter, so we can see rejected/paused too.
    const env = await apiEnvelope<AdminListing[]>(`/api/admin/products?${qs.toString()}`);
    return {
      listings: env.data,
      pagination: env.pagination ?? { total: env.data.length, page, pageSize: 20, totalPages: 1 },
    };
  } catch (e) {
    // Fall back to the public search endpoint if the admin one isn't wired yet
    // — lets the panel still render something useful on a partial backend.
    try {
      const env = await apiEnvelope<AdminListing[]>(`/api/products?${qs.toString()}`);
      return {
        listings: env.data,
        pagination: env.pagination ?? { total: env.data.length, page, pageSize: 20, totalPages: 1 },
      };
    } catch (e2) {
      return {
        listings: [],
        pagination: { total: 0, page: 1, pageSize: 20, totalPages: 1 },
        error: e instanceof ApiError ? e.message : String(e),
      };
    }
  }
}

export default async function ListingsPage({
  searchParams,
}: {
  searchParams: Promise<{ page?: string; filter?: string }>;
}) {
  const params = await searchParams;
  const page = Math.max(1, Number.parseInt(params.page ?? '1', 10) || 1);
  const filter = params.filter === 'pending' ? 'pending' : 'all';

  const session = await readSession();
  const canModerate = can(session, 'moderate_listing');

  const { listings, pagination, error } = await loadListings(page, filter);

  return (
    <>
      <TopBar
        title="Listings"
        subtitle={
          filter === 'pending'
            ? 'Queue awaiting moderation'
            : `${pagination.total.toLocaleString()} listings`
        }
        actions={
          <div className="flex gap-2">
            <Link
              href="/dashboard/listings?filter=pending"
              className={filter === 'pending' ? 'btn-primary' : 'btn-outline'}
            >
              Pending
            </Link>
            <Link
              href="/dashboard/listings"
              className={filter === 'all' ? 'btn-primary' : 'btn-outline'}
            >
              All
            </Link>
          </div>
        }
      />

      <div className="max-w-7xl mx-auto w-full p-6 space-y-4">
        {error && (
          <div className="rounded-lg bg-danger/10 border border-danger/30 px-4 py-3 text-sm text-danger">
            {error}
          </div>
        )}

        <Table>
          <thead>
            <tr>
              <TH>Listing</TH>
              <TH>Owner</TH>
              <TH>Category</TH>
              <TH>Price</TH>
              <TH>Type</TH>
              <TH>Status</TH>
              <TH>Moderation</TH>
              <TH>Submitted</TH>
              <TH className="text-right">Actions</TH>
            </tr>
          </thead>
          <tbody>
            {listings.length === 0 ? (
              <EmptyState message="Queue is clear 🎉" />
            ) : (
              listings.map((l) => (
                <TR key={l.id}>
                  <TD>
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="h-10 w-10 rounded-lg bg-surface overflow-hidden shrink-0">
                        {l.media?.[0]?.url && (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={l.media[0].url}
                            alt=""
                            className="h-full w-full object-cover"
                          />
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="font-medium truncate max-w-[280px]">{l.title}</p>
                        <p className="text-xs text-ink-muted font-mono">
                          {l.id.slice(0, 8)}…
                        </p>
                      </div>
                    </div>
                  </TD>
                  <TD className="text-xs">
                    {l.owner?.fullName ?? '—'}
                    <div className="text-ink-muted">{l.owner?.email ?? ''}</div>
                  </TD>
                  <TD>{l.category?.name ?? '—'}</TD>
                  <TD className="font-medium">
                    {formatCurrency(l.price, l.currency)}
                    <span className="text-xs text-ink-muted">
                      {l.priceUnit === 'fixed' ? '' : ` / ${l.priceUnit}`}
                    </span>
                  </TD>
                  <TD>
                    <Badge variant="primary">{l.listingType}</Badge>
                  </TD>
                  <TD>
                    <Badge variant={statusVariant(l.status)}>{l.status}</Badge>
                  </TD>
                  <TD>
                    <Badge variant={statusVariant(l.moderationStatus)}>{l.moderationStatus}</Badge>
                  </TD>
                  <TD className="text-ink-muted">{formatDate(l.createdAt)}</TD>
                  <TD>
                    <ModerationActions productId={l.id} canMutate={canModerate} />
                  </TD>
                </TR>
              ))
            )}
          </tbody>
        </Table>

        {listings.length > 0 && (
          <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} />
        )}
      </div>
    </>
  );
}
