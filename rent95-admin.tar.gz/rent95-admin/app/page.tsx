import { redirect } from 'next/navigation';

// Any hit to `/` bounces into the guarded dashboard tree — middleware then
// routes to /login if there's no session.
export default function Home() {
  redirect('/dashboard');
}
