import { NextRequest, NextResponse } from 'next/server';
import { clearSession, readSession } from '@/lib/session';

const API_URL = process.env.API_URL ?? 'http://localhost:4000';

/**
 * Best-effort revoke on the backend, then clear our cookie either way.
 * If the network call fails, we still log the admin out locally so the
 * session button on the sidebar can't get stuck.
 */
export async function POST(req: NextRequest) {
  const session = await readSession();
  if (session) {
    try {
      await fetch(`${API_URL}/api/auth/logout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: session.refreshToken }),
      });
    } catch {
      /* ignore — local clear is authoritative for the UI */
    }
  }
  await clearSession();
  return NextResponse.redirect(new URL('/login', req.url), 303);
}
