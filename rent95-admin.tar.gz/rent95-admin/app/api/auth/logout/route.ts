import { NextRequest, NextResponse } from 'next/server';
import { clearSession, readSession } from '@/lib/session';

const API_URL = process.env.API_URL ?? 'http://localhost:4000';

/**
 * Best-effort logout.
 *
 * Since the security audit (C4) removed the refresh token from the panel
 * cookie, we no longer have it to POST to /api/auth/logout. That's fine:
 *   - Access tokens expire on their own (~15 min) and can't be revoked
 *     without the refresh token by design.
 *   - Server-side refresh-token revocation should happen from the mobile
 *     app on user-initiated logout, or from the admin's "revoke all
 *     sessions" action (v1.1).
 *   - Local cookie clear is authoritative for the panel UI.
 *
 * Route accepts POST only (matches the sidebar form) to avoid GET-triggered
 * logout via `<img src>` mischief.
 */
export async function POST(req: NextRequest) {
  const session = await readSession();
  if (session) {
    // Tell the API the access token is being retired. It's a hint, not a
    // revocation — we no longer hold the refresh token here. If /api/auth/
    // logout requires the refresh token, this call is a friendly no-op.
    try {
      await fetch(`${API_URL}/api/auth/logout`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session.accessToken}`,
        },
        body: JSON.stringify({}),
      });
    } catch {
      /* ignore — local clear is authoritative for the UI */
    }
  }
  await clearSession();
  return NextResponse.redirect(new URL('/login', req.url), 303);
}
