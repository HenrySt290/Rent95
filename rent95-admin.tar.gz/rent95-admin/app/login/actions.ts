'use server';

import { redirect } from 'next/navigation';
import { ADMIN_ROLES, writeSession, type Session } from '@/lib/session';

const API_URL = process.env.API_URL ?? 'http://localhost:4000';

export type LoginState =
  | { ok: true }
  | { ok: false; error: string };

/**
 * Server action for the login form. Runs on the Node side so we can:
 *   1. Call the backend directly (no CORS pain)
 *   2. Set the HttpOnly session cookie (client JS can't do this)
 *   3. Reject non-admin roles before any UI ever renders
 */
export async function login(
  _prev: LoginState | undefined,
  formData: FormData,
): Promise<LoginState> {
  const email = String(formData.get('email') ?? '').trim();
  const password = String(formData.get('password') ?? '');
  const next = String(formData.get('next') ?? '/dashboard');

  if (!email || !password) {
    return { ok: false, error: 'Enter an email and password.' };
  }

  let res: Response;
  try {
    res = await fetch(`${API_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
      cache: 'no-store',
    });
  } catch {
    return { ok: false, error: 'Could not reach the API. Is rent95-api running?' };
  }

  if (!res.ok) {
    if (res.status === 401 || res.status === 400) {
      return { ok: false, error: 'Invalid email or password.' };
    }
    return { ok: false, error: `Login failed (${res.status}).` };
  }

  type LoginResponse = {
    data: {
      accessToken: string;
      refreshToken: string;
      user: {
        id: string;
        email: string;
        fullName: string;
        role: string;
      };
    };
  };

  const body = (await res.json()) as LoginResponse;
  const { accessToken, refreshToken, user } = body.data;

  // Hard gate — only admin-eligible roles can even hold an admin cookie.
  // A buyer/seller with correct credentials will still be rejected here.
  if (!ADMIN_ROLES.includes(user.role as Session['role'])) {
    return {
      ok: false,
      error: "This account doesn't have admin access. Contact your administrator.",
    };
  }

  await writeSession({
    accessToken,
    refreshToken,
    userId: user.id,
    role: user.role as Session['role'],
    email: user.email,
    fullName: user.fullName,
  });

  // `redirect` throws — never returns. Keep it as the last statement.
  redirect(next);
}
