'use client';

import { useFormState, useFormStatus } from 'react-dom';
import { login, type LoginState } from './actions';
import { Lock } from 'lucide-react';

export function LoginForm({ next }: { next: string }) {
  const [state, formAction] = useFormState<LoginState | undefined, FormData>(login, undefined);

  return (
    <form action={formAction} className="space-y-4">
      <input type="hidden" name="next" value={next} />

      <div>
        <label className="block text-sm font-medium mb-1.5" htmlFor="email">
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          required
          autoComplete="email"
          className="input"
          placeholder="admin@rent95.dev"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1.5" htmlFor="password">
          Password
        </label>
        <input
          id="password"
          name="password"
          type="password"
          required
          autoComplete="current-password"
          className="input"
        />
      </div>

      {state?.ok === false && (
        <div className="rounded-lg bg-danger/10 border border-danger/30 px-3 py-2 text-sm text-danger">
          {state.error}
        </div>
      )}

      <SubmitButton />
    </form>
  );
}

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className="btn-primary w-full" disabled={pending}>
      <Lock size={16} />
      {pending ? 'Signing in…' : 'Sign in'}
    </button>
  );
}
