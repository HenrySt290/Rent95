import { LoginForm } from './login-form';

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string }>;
}) {
  const { next } = await searchParams;

  return (
    <div className="min-h-screen grid place-items-center bg-surface p-6">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="inline-flex h-14 w-14 rounded-2xl bg-primary text-white items-center justify-center font-bold text-lg mb-4">
            R95
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Rent95 Admin</h1>
          <p className="text-sm text-ink-muted mt-1">Sign in with your admin account</p>
        </div>

        <div className="card p-6">
          <LoginForm next={next ?? '/dashboard'} />
        </div>

        <p className="mt-6 text-xs text-center text-ink-muted">
          Only accounts with role <span className="font-mono">admin</span>,{' '}
          <span className="font-mono">moderator</span>, or <span className="font-mono">support</span>{' '}
          can access this panel.
        </p>
      </div>
    </div>
  );
}
