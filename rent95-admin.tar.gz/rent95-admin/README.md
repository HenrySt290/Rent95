# Rent95 Admin 🎛️

Next.js 15 admin panel for the Rent95 marketplace. Third of the three-repo layout:

| Repo | Purpose |
|---|---|
| **`Rent95`** | Flutter mobile app (buyers / sellers) |
| **`rent95-api`** | Node/Express/Prisma backend |
| **`rent95-admin`** _(this repo)_ | Admin/moderator/support web panel |

## What's built

- **Auth**: server-action login → `POST /api/auth/login` → HttpOnly session cookie
- **Middleware guard**: every `/dashboard/*` route requires an admin-role cookie
- **Role-based capabilities**: admin/moderator/support each see a curated set of actions
  (config in `lib/session.ts#CAPABILITY_MATRIX`)
- **Dashboard**: GMV + user/listing/order/dispute counts, 14-day revenue chart
- **Users**: paginated table + suspend/activate/ban actions (admin only)
- **Listings moderation**: approve / reject with reason picker, pending-filter view
- **Orders**: read-only paginated table with buyer/seller/product/status/total
- **Payments**: escrow status, platform fee vs seller amount breakdown
- **Disputes**: split into open vs closed sections
- **Categories**: read-only in v1 (full CRUD lands in v1.1 per the revised MVP)

All server rendered by default (Server Components), with client interactivity
kept surgically to the row-action menus. Data flows through `lib/api.ts`
which forwards the admin's bearer token to `rent95-api`.

## Getting started

```bash
# 1. Install
npm install

# 2. Point at your backend
cp .env.example .env
# Edit API_URL to your rent95-api instance.

# 3. Run
npm run dev
# → open http://localhost:3000
```

You'll be bounced to `/login`. Sign in with an account whose `role` is one of
`admin`, `moderator`, or `support`. The seed data in `rent95-api` creates
`admin@rent95.dev` / `demo1234`.

## Commands

| Command | Purpose |
|---|---|
| `npm run dev` | Dev server with HMR on :3000 |
| `npm run build` | Production build |
| `npm start` | Serve the production build |
| `npm run typecheck` | `tsc --noEmit` — must pass in CI |
| `npm run lint` | ESLint with `next/core-web-vitals` |

## Project layout

```
app/
├── layout.tsx                # <html>, fonts, global styles
├── page.tsx                  # → redirect to /dashboard
├── login/
│   ├── page.tsx              # login screen
│   ├── login-form.tsx        # 'use client' form with useFormState
│   └── actions.ts            # 'use server' action → sets HttpOnly cookie
├── api/auth/logout/route.ts  # POST from sidebar → clear session
└── dashboard/
    ├── layout.tsx            # Sidebar + defence-in-depth session check
    ├── page.tsx              # Overview + metrics
    ├── revenue-chart.tsx     # 'use client' Recharts card
    ├── users/                # Users table + suspend/activate/ban actions
    ├── listings/             # Moderation queue + approve/reject flow
    ├── orders/               # Order table
    ├── payments/             # Payment + escrow table
    ├── disputes/             # Open/closed dispute lists
    └── categories/           # Read-only category table

lib/
├── api.ts                    # Server-side fetch helper (attaches JWT)
├── session.ts                # readSession / writeSession / capability matrix
└── utils.ts                  # cn, formatCurrency, formatDate

components/
├── sidebar.tsx               # Left nav with role indicator + logout form
├── topbar.tsx                # Page title + subtitle + right-aligned actions
└── ui/
    ├── badge.tsx             # Status pills + shared statusVariant() mapping
    ├── card.tsx              # Card + StatCard
    ├── table.tsx             # Table / TH / TD / TR / EmptyState
    └── pagination.tsx        # ?page= querystring pagination

middleware.ts                 # Auth guard on every /dashboard/* request
tailwind.config.ts            # Marketplace-consistent design tokens
```

## Design system

Same tokens as the Flutter mobile app so the two products stay visually
coherent — indigo `#3B49DF` primary, amber `#FFB020` accent, Inter font,
identical status-badge colour language.

Everything is Tailwind utilities on top of a handful of `.btn-*`, `.badge-*`,
`.card`, `.input` primitives defined in `styles/globals.css`. No component
library, no CSS-in-JS.

## Adding a new admin capability

1. Add the string to `Capability` in `lib/session.ts`.
2. Add its role list to `CAPABILITY_MATRIX`.
3. Guard the UI: `const { canX } = { canX: can(session, 'x') }` in a page,
   render conditionally.
4. Guard the mutation: the row-action's `'use server'` action does the fetch
   with the admin's bearer, and the backend re-checks role.

## Adding a new page

1. Create `app/dashboard/<page>/page.tsx` as a Server Component.
2. Add `{ href: '/dashboard/<page>', label: 'X', icon: Foo }` to `NAV`
   in `components/sidebar.tsx`.
3. Fetch through `api()` / `apiEnvelope()` so the bearer token is attached
   consistently.

## Deployment

- **Node runtime**: any Node 20 host works (Vercel, Fly, Render, Railway,
  your own Docker).
- The included `Dockerfile` builds a minimal production image.
- `next.config.mjs` sets `images.unoptimized = true` because we currently
  render remote Cloudinary URLs and don't need Next's image optimizer.

## Sandbox / setup notes

If you're viewing this repo inside the Arena sandbox, `npm install` can't run
because `registry.npmjs.org` isn't reachable. Clone locally and run — every
package pinned in `package.json` is public and stable.
