import { defineConfig } from 'vitest/config';
import { resolve } from 'node:path';

/**
 * Vitest configuration for rent95-admin.
 *
 * Notes:
 *  - Tests run in `node` environment. The admin surface we care about
 *    (session cookie codec, capability matrix) is all server-side.
 *  - `tests/setup.ts` sets ADMIN_SESSION_SECRET BEFORE any lib/ import
 *    so the boot-time guard in session.ts is satisfied.
 *  - Aliases mirror tsconfig `@/` → project root so imports match runtime.
 */
export default defineConfig({
  test: {
    include: ['tests/**/*.test.ts'],
    environment: 'node',
    globals: false,
    setupFiles: ['tests/setup.ts'],
    // Session tests mock next/headers per-test and share no state, so
    // parallelism is fine here. If a future integration test needs a
    // shared fixture, switch to `singleFork`.
    pool: 'forks',
  },
  resolve: {
    alias: {
      '@': resolve(__dirname, '.'),
    },
  },
});
