/** @type {import('tailwindcss').Config} */
export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#3B49DF',
          dark: '#232FB0',
          light: '#EEF0FF',
        },
        surface: '#F7F8FA',
        border: '#E2E8F0',
        ink: {
          DEFAULT: '#0F172A',
          muted: '#64748B',
        },
        success: '#16A34A',
        warning: '#F59E0B',
        danger: '#DC2626',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 3px rgb(15 23 42 / 0.04), 0 1px 2px rgb(15 23 42 / 0.06)',
      },
    },
  },
  plugins: [],
};
