import { NextRequest, NextResponse } from 'next/server';
import { ADMIN_ROLES, SESSION_COOKIE, type AdminRole } from './lib/session-shared';

/**
 * Edge-runtime auth guard.
 *
 * Verifies the AES-256-GCM cookie on every request via Web Crypto
 * (`crypto.subtle.decrypt`). A tampered cookie fails GCM's built-in
 * authentication and this middleware sees `null` → redirect to /login.
 *
 * We can't `import 'node:crypto'` in Edge, so this file re-implements the
 * cipher path against WebCrypto. The session.ts equivalent (Node runtime,
 * used from Server Actions) is the source of truth for the wire format:
 *
 *   <b64url(iv)>.<b64url(ciphertext)>.<b64url(authTag)>
 *
 * WebCrypto merges the ciphertext and tag when decrypting AES-GCM, so we
 * concatenate the last two segments before passing to `subtle.decrypt`.
 */
export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  const cookie = req.cookies.get(SESSION_COOKIE)?.value;
  const session = cookie ? await verifyCookie(cookie) : null;
  const authed =
    !!session && (ADMIN_ROLES as readonly string[]).includes(session.role);

  const goingToLogin = pathname === '/login';

  if (!authed && !goingToLogin) {
    const url = req.nextUrl.clone();
    url.pathname = '/login';
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }

  if (authed && goingToLogin) {
    const url = req.nextUrl.clone();
    url.pathname = '/dashboard';
    url.searchParams.delete('next');
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

// -----------------------------------------------------------------------------
// AES-GCM decrypt (Web Crypto, Edge-safe)
// -----------------------------------------------------------------------------

type MinimalSession = { role: AdminRole; iat: number };
const SIXTY_DAYS_MS = 60 * 60 * 24 * 60 * 1000;

let _keyPromise: Promise<CryptoKey> | null = null;
async function getKey(): Promise<CryptoKey | null> {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret || secret.length < 32) return null;
  if (!_keyPromise) {
    // Match session.ts: derive 32-byte key via SHA-256 over the secret.
    _keyPromise = (async () => {
      const hash = await crypto.subtle.digest(
        'SHA-256',
        new TextEncoder().encode(secret),
      );
      return crypto.subtle.importKey(
        'raw',
        hash,
        { name: 'AES-GCM', length: 256 },
        false,
        ['decrypt'],
      );
    })();
  }
  return _keyPromise;
}

async function verifyCookie(raw: string): Promise<MinimalSession | null> {
  const parts = raw.split('.');
  if (parts.length !== 3) return null;

  try {
    const iv = base64UrlDecode(parts[0]);
    const ciphertext = base64UrlDecode(parts[1]);
    const authTag = base64UrlDecode(parts[2]);
    if (iv.length !== 12 || authTag.length !== 16) return null;

    const key = await getKey();
    if (!key) return null;

    // WebCrypto expects ciphertext||tag concatenated (not split like Node's).
    const combined = new Uint8Array(ciphertext.length + authTag.length);
    combined.set(ciphertext, 0);
    combined.set(authTag, ciphertext.length);

    // Throws on tag mismatch — GCM's authenticated-encryption guarantee.
    const plainBuf = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      combined,
    );
    const parsed = JSON.parse(
      new TextDecoder().decode(plainBuf),
    ) as MinimalSession;
    if (typeof parsed.role !== 'string' || typeof parsed.iat !== 'number') {
      return null;
    }
    if (Date.now() - parsed.iat > SIXTY_DAYS_MS) return null;
    return parsed;
  } catch {
    return null;
  }
}

function base64UrlDecode(s: string): Uint8Array {
  const b64 = s
    .replace(/-/g, '+')
    .replace(/_/g, '/')
    .padEnd(Math.ceil(s.length / 4) * 4, '=');
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
};
