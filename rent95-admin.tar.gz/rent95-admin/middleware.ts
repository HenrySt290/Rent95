import { NextRequest, NextResponse } from 'next/server';
import { ADMIN_ROLES, SESSION_COOKIE, type AdminRole } from './lib/session-shared';

/**
 * Route-level auth guard.
 *
 * Runs on the Edge for every request matched by `config.matcher`. The Edge
 * runtime doesn't expose Node's `crypto` module, so we use Web Crypto
 * (`crypto.subtle`) — hence the async middleware.
 *
 * We do a **full HMAC verification** here (fix H3 from the security audit):
 * previously the middleware `JSON.parse`d the cookie and trusted its
 * `role` claim. Now every request re-verifies the MAC signed by
 * `ADMIN_SESSION_SECRET`, so an attacker who plants a cookie without the
 * secret gets bounced to /login instead of being served the admin shell.
 */
export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  const cookie = req.cookies.get(SESSION_COOKIE)?.value;
  const session = cookie ? await verifyCookie(cookie) : null;
  const authed = !!session && (ADMIN_ROLES as readonly string[]).includes(session.role);

  const goingToLogin = pathname === '/login';

  if (!authed && !goingToLogin) {
    const url = req.nextUrl.clone();
    url.pathname = '/login';
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }

  if (authed && goingToLogin) {
    const url = req.nextUrl.clone();
    url.pathname = '/dashboard';
    url.searchParams.delete('next');
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

// -----------------------------------------------------------------------------
// Cookie verification (Edge-safe, Web Crypto only)
// -----------------------------------------------------------------------------

type MinimalSession = { role: AdminRole; iat: number };

/**
 * Loads `ADMIN_SESSION_SECRET` at first call, caches the CryptoKey.
 *
 * Edge doesn't guarantee module-level init order the way Node does,
 * so we defer key creation until the first middleware invocation.
 */
let _keyPromise: Promise<CryptoKey> | null = null;
async function getKey(): Promise<CryptoKey | null> {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret || secret.length < 32) return null;
  if (!_keyPromise) {
    _keyPromise = crypto.subtle.importKey(
      'raw',
      new TextEncoder().encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['verify'],
    );
  }
  return _keyPromise;
}

async function verifyCookie(raw: string): Promise<MinimalSession | null> {
  const dot = raw.lastIndexOf('.');
  if (dot < 0) return null;
  const body = raw.slice(0, dot);
  const macHex = raw.slice(dot + 1);
  if (!/^[0-9a-f]+$/i.test(macHex)) return null;

  const key = await getKey();
  if (!key) return null;

  // Verify HMAC over the base64url payload segment.
  const macBytes = hexToBytes(macHex);
  const ok = await crypto.subtle.verify(
    'HMAC',
    key,
    macBytes,
    new TextEncoder().encode(body),
  );
  if (!ok) return null;

  try {
    const jsonBytes = base64UrlDecode(body);
    const parsed = JSON.parse(new TextDecoder().decode(jsonBytes)) as MinimalSession;
    if (typeof parsed.role !== 'string' || typeof parsed.iat !== 'number') return null;
    // Reject stale cookies (defence-in-depth vs. browser Max-Age).
    const SIXTY_DAYS = 60 * 60 * 24 * 60 * 1000;
    if (Date.now() - parsed.iat > SIXTY_DAYS) return null;
    return parsed;
  } catch {
    return null;
  }
}

function hexToBytes(hex: string): Uint8Array {
  const len = hex.length / 2;
  const out = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    out[i] = parseInt(hex.substring(i * 2, i * 2 + 2), 16);
  }
  return out;
}

function base64UrlDecode(s: string): Uint8Array {
  // Convert base64url → base64, pad, then atob.
  const b64 = s.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(s.length / 4) * 4, '=');
  const binary = atob(b64);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
};
