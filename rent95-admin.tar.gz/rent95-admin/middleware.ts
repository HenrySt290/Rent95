import { NextRequest, NextResponse } from 'next/server';
import { ADMIN_ROLES, SESSION_COOKIE } from './lib/session';

/**
 * Route-level auth guard.
 *
 * Runs on every request that matches `config.matcher` below. We don't do a
 * full JWT verify here (we don't have the secret in this process) — instead:
 *
 *   1. Confirm the cookie is present.
 *   2. Confirm the role claim inside is admin-eligible.
 *
 * Any real capability check (e.g. "can this user actually suspend?") also
 * happens on the backend for every mutation, so this middleware is a fast
 * first line of defence, not the last one.
 *
 * We keep the parsing tiny — no JSON.parse of the raw JWT, we just look at
 * our own wrapper cookie, which is HttpOnly so a browser attacker can't
 * forge it anyway.
 */
export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  const cookie = req.cookies.get(SESSION_COOKIE)?.value;
  const session = cookie ? safeParse(cookie) : null;
  const authed = !!session && ADMIN_ROLES.includes(session.role as 'admin');

  const goingToLogin = pathname === '/login';

  if (!authed && !goingToLogin) {
    const url = req.nextUrl.clone();
    url.pathname = '/login';
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }

  if (authed && goingToLogin) {
    const url = req.nextUrl.clone();
    url.pathname = '/dashboard';
    url.searchParams.delete('next');
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

type ParsedSession = { role?: string };
function safeParse(raw: string): ParsedSession | null {
  try {
    return JSON.parse(raw) as ParsedSession;
  } catch {
    return null;
  }
}

/**
 * Only run the middleware on pages that matter. Skipping the static-file
 * matchers keeps hot navigation fast.
 */
export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
};
